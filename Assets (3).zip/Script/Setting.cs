using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

// 설정창 전체를 자동으로 만들고 관리하는 컴포넌트입니다.
//
// 이 스크립트의 큰 흐름:
// 1. Awake에서 설정창 UI가 없으면 런타임으로 직접 생성합니다.
// 2. 시작 버튼 역할을 하는 오브젝트에 Button 컴포넌트를 붙이고, 클릭 시 설정창이 열리게 연결합니다.
// 3. Start에서 품질/저장된 옵션을 읽어 UI 상태를 맞춥니다.
// 4. 슬라이더/토글/드롭다운 값이 바뀌면 Unity 설정과 PlayerPrefs 저장값을 같이 갱신합니다.
//
// PlayerPrefs는 Unity가 제공하는 간단한 로컬 저장소입니다.
// 옵션창처럼 작은 설정값을 저장할 때 자주 씁니다.
//
// 초심자용 핵심 개념:
// - Awake는 오브젝트가 준비될 때 가장 먼저 호출됩니다.
// - Start는 첫 프레임 전에 한 번 호출됩니다.
// - Slider/Toggle/Dropdown은 사용자가 값을 바꿀 수 있는 UI 컨트롤입니다.
// - AddListener는 "값이 바뀌거나 버튼이 눌렸을 때 실행할 함수"를 연결합니다.
// - PlayerPrefs.SetFloat/SetInt는 설정값을 저장하고, GetFloat/GetInt는 다시 불러옵니다.
public class Setting : MonoBehaviour
{
    [Header("Sound")]
    // AudioMixer를 연결하면 실제 게임 음량을 조절할 수 있습니다.
    // 연결되지 않아도 PlayerPrefs 저장은 되도록 코드가 방어적으로 작성되어 있습니다.
    public AudioMixer audioMixer;

    [Header("Runtime UI")]
    // 이미 씬에 만들어 둔 설정 패널이 있다면 여기에 연결합니다.
    // 비어 있으면 EnsureSettingsPanel이 Canvas 아래에 자동으로 만들어 줍니다.
    public GameObject settingsPanel;
    // 아래 세 변수는 런타임에 생성한 UI 컨트롤을 코드에서 다시 접근하기 위해 보관합니다.
    // private이므로 Inspector에는 보이지 않고, 이 클래스 내부에서만 사용됩니다.
    private Slider volumeSlider;
    private Toggle fullscreenToggle;
    private TMP_Dropdown qualityDropdown;
    private Text qualityValueText;

    private void Awake()
    {
        // SampleScene의 setting 이미지 버튼에 이 스크립트가 붙어 있으므로,
        // 시작할 때 버튼 클릭 이벤트와 설정창을 자동으로 준비합니다.
        EnsureSettingsPanel();
        ConnectOpenButton();
    }

    private void Start()
    {
        InitQuality();
        InitSavedOptions();
    }

    private void ConnectOpenButton()
    {
        // 이 스크립트가 붙은 GameObject 자체를 "설정 열기 버튼"으로 사용합니다.
        // Button 컴포넌트가 없다면 자동으로 추가해서 씬 세팅 실수를 줄입니다.
        Button button = GetComponent<Button>();
        if (button == null) button = gameObject.AddComponent<Button>();

        button.onClick.RemoveListener(OpenSettings);
        button.onClick.AddListener(OpenSettings);
    }

    private void EnsureSettingsPanel()
    {
        // 이미 Inspector에 연결된 패널이 있으면 새로 만들 필요가 없습니다.
        if (settingsPanel != null) return;

        // 설정창은 UI이므로 Canvas 아래에 있어야 화면에 렌더링됩니다.
        Canvas canvas = GetComponentInParent<Canvas>();
        if (canvas == null) canvas = FindFirstObjectByType<Canvas>();
        if (canvas == null) return;

        // 같은 이름의 패널이 이미 있다면 재사용합니다.
        // 중복 생성되면 버튼 클릭마다 여러 설정창이 생길 수 있기 때문입니다.
        Transform existing = canvas.transform.Find("Settings Panel");
        if (existing != null)
        {
            settingsPanel = existing.gameObject;
            settingsPanel.SetActive(false);
            return;
        }

        settingsPanel = CreatePanel(canvas.transform);
        settingsPanel.SetActive(false);
    }

    private GameObject CreatePanel(Transform canvasRoot)
    {
        // overlay는 화면 전체를 덮는 반투명 배경입니다.
        // 뒤쪽 게임 화면을 어둡게 만들어 설정창에 시선이 가게 합니다.
        GameObject overlay = CreateUIObject("Settings Panel", canvasRoot, typeof(Image));
        RectTransform overlayRect = overlay.GetComponent<RectTransform>();
        Stretch(overlayRect);
        overlay.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.62f);

        // window는 실제 옵션들이 들어가는 중앙 창입니다.
        GameObject window = CreateUIObject("Settings Window", overlay.transform, typeof(Image));
        RectTransform windowRect = window.GetComponent<RectTransform>();
        windowRect.anchorMin = new Vector2(0.5f, 0.5f);
        windowRect.anchorMax = new Vector2(0.5f, 0.5f);
        windowRect.pivot = new Vector2(0.5f, 0.5f);
        windowRect.anchoredPosition = Vector2.zero;
        windowRect.sizeDelta = new Vector2(620f, 440f);
        CelestialUiAssets.ApplyWindow(window.GetComponent<Image>());

        CreateText(window.transform, "Title", "성좌 설정", 34, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -48f), new Vector2(520f, 56f));
        CreateDivider(window.transform, "Title Divider", new Vector2(0f, -86f), new Vector2(500f, 42f));

        volumeSlider = CreateSlider(window.transform, "Volume Row", "별빛 음악", new Vector2(0f, 92f));
        volumeSlider.onValueChanged.AddListener(SetVolume);

        fullscreenToggle = CreateToggle(window.transform, "Fullscreen Toggle", "전체 화면", new Vector2(-130f, 28f));
        fullscreenToggle.onValueChanged.AddListener(SetFullscreen);

        CreateCycleButton(window.transform, "Quality Button Row", "그래픽", new Vector2(0f, -36f), out qualityValueText, OnClickNextQuality);

        CreateText(window.transform, "Guide", "별빛 음악과 화면의 선명도를 조율합니다.", 19, TextAnchor.MiddleCenter, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 106f), new Vector2(540f, 36f));

        GameObject closeButton = CreateButton(window.transform, "Close Button", "닫기", new Vector2(0f, 44f), new Vector2(170f, 54f));
        closeButton.GetComponent<Button>().onClick.AddListener(CloseSettings);

        return overlay;
    }

    public void OpenSettings()
    {
        if (settingsPanel != null)
        {
            settingsPanel.SetActive(true);
        }
    }

    public void CloseSettings()
    {
        if (settingsPanel != null)
        {
            settingsPanel.SetActive(false);
        }
    }

    public void SetVolume(float volume)
    {
        // AudioMixer가 아직 연결되지 않은 상태에서도 슬라이더는 저장되게 합니다.
        // AudioMixer의 dB 값은 0을 넣으면 Log10 계산이 불가능하므로 아주 작은 값으로 제한합니다.
        float safeVolume = Mathf.Clamp(volume, 0.0001f, 1f);
        if (audioMixer != null)
        {
            audioMixer.SetFloat("MasterVol", Mathf.Log10(safeVolume) * 20f);
        }

        PlayerPrefs.SetFloat("Volume", volume);
        GlobalBgmManager.SetVolume(volume);
    }

    public void SetFullscreen(bool isFullscreen)
    {
        Screen.fullScreen = isFullscreen;
        PlayerPrefs.SetInt("Fullscreen", isFullscreen ? 1 : 0);
    }

    public void SetQuality(int qualityIndex)
    {
        // QualitySettings 단계뿐 아니라 URP 렌더 스케일, MSAA, 그림자까지 함께 바꿉니다.
        int safeQualityIndex = RuntimeGraphicsQuality.Apply(qualityIndex);

        // 화면에 보이는 버튼 텍스트도 현재 품질 이름으로 갱신합니다.
        // 이 줄이 없으면 실제 품질은 바뀌었는데 버튼 글자는 예전 값으로 남을 수 있습니다.
        if (qualityValueText != null) qualityValueText.text = GetQualityLabel(safeQualityIndex);
    }

    private void InitQuality()
    {
        // 설정창이 처음 열릴 때 그래픽 품질 버튼의 글자를 현재 저장값에 맞춥니다.
        // 이전에 저장한 품질이 있으면 그 값을 사용하고, 없으면 현재 Unity 품질 값을 사용합니다.
        int savedQuality = RuntimeGraphicsQuality.GetSavedQualityIndex();
        int safeQuality = Mathf.Clamp(savedQuality, 0, GetQualityCount() - 1);

        // 버튼 표시만 맞추는 것이 아니라, 실제 게임 품질도 저장값에 맞춰 적용합니다.
        SetQuality(safeQuality);
    }

    private void InitSavedOptions()
    {
        if (volumeSlider != null)
        {
            volumeSlider.value = PlayerPrefs.GetFloat("Volume", 0.75f);
        }

        if (fullscreenToggle != null)
        {
            fullscreenToggle.isOn = PlayerPrefs.GetInt("Fullscreen", Screen.fullScreen ? 1 : 0) == 1;
        }
    }

    private void OnClickNextQuality()
    {
        // 그래픽 버튼을 누르면 현재 저장된 품질 번호에서 1을 더합니다.
        // 마지막 품질 단계 다음에는 다시 0번으로 돌아가서 계속 순환합니다.
        int currentQuality = RuntimeGraphicsQuality.GetSavedQualityIndex();
        int nextQuality = (currentQuality + 1) % GetQualityCount();
        SetQuality(nextQuality);
    }

    private int GetQualityCount()
    {
        // Unity의 품질 단계 개수입니다.
        // Project Settings > Quality에 등록된 항목 수와 같습니다.
        // 혹시 항목이 없더라도 나눗셈 오류가 나지 않게 최소 1을 반환합니다.
        return RuntimeGraphicsQuality.QualityCount;
    }

    private string GetQualityLabel(int qualityIndex)
    {
        // 버튼에 보여줄 그래픽 품질 이름입니다.
        // Unity 기본 품질 이름이 영어일 수 있어서 앞의 3단계는 한국어로 보여줍니다.
        return RuntimeGraphicsQuality.GetQualityLabel(qualityIndex);
    }

    private void CreateCycleButton(Transform parent, string objectName, string label, Vector2 position, out Text valueText, UnityEngine.Events.UnityAction onClick)
    {
        // "이름 + 현재 값 버튼" 형태의 한 줄 옵션 UI를 만듭니다.
        // 드롭다운보다 구조가 단순해서 런타임으로 만들기 쉽고,
        // 초보자가 보기에도 Button.onClick 흐름을 이해하기 좋습니다.
        GameObject row = CreateUIObject(objectName, parent);
        RectTransform rowRect = row.GetComponent<RectTransform>();
        rowRect.anchorMin = new Vector2(0.5f, 0.5f);
        rowRect.anchorMax = new Vector2(0.5f, 0.5f);
        rowRect.anchoredPosition = position;
        rowRect.sizeDelta = new Vector2(500f, 56f);

        CreateText(row.transform, "Label", label, 22, TextAnchor.MiddleLeft, new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(64f, 0f), new Vector2(120f, 48f));

        GameObject buttonObject = CreateUIObject("Value Button", row.transform, typeof(Image), typeof(Button));
        RectTransform buttonRect = buttonObject.GetComponent<RectTransform>();
        buttonRect.anchorMin = new Vector2(1f, 0.5f);
        buttonRect.anchorMax = new Vector2(1f, 0.5f);
        buttonRect.anchoredPosition = new Vector2(-125f, 0f);
        buttonRect.sizeDelta = new Vector2(220f, 44f);
        CelestialUiAssets.ApplyButton(buttonObject.GetComponent<Image>());

        Button button = buttonObject.GetComponent<Button>();
        CelestialUiAssets.ConfigureButton(button, buttonObject.GetComponent<Image>());
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(onClick);

        valueText = CreateText(buttonObject.transform, "Value", "-", 20, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        valueText.raycastTarget = false;
    }

    private Slider CreateSlider(Transform parent, string objectName, string label, Vector2 position)
    {
        // Unity UI Slider는 Background, Fill Area, Handle 같은 자식 구조를 필요로 합니다.
        // 여기서는 프리팹 없이 코드로 그 구조를 직접 만들어 재사용 가능한 슬라이더를 생성합니다.
        GameObject row = CreateUIObject(objectName, parent);
        RectTransform rowRect = row.GetComponent<RectTransform>();
        rowRect.anchorMin = new Vector2(0.5f, 0.5f);
        rowRect.anchorMax = new Vector2(0.5f, 0.5f);
        rowRect.anchoredPosition = position;
        rowRect.sizeDelta = new Vector2(500f, 54f);

        CreateText(row.transform, "Label", label, 22, TextAnchor.MiddleLeft, new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(64f, 0f), new Vector2(120f, 48f));

        GameObject sliderObject = CreateUIObject("Slider", row.transform, typeof(Slider), typeof(Image));
        RectTransform sliderRect = sliderObject.GetComponent<RectTransform>();
        sliderRect.anchorMin = new Vector2(0f, 0.5f);
        sliderRect.anchorMax = new Vector2(1f, 0.5f);
        sliderRect.anchoredPosition = new Vector2(110f, 0f);
        sliderRect.sizeDelta = new Vector2(-150f, 28f);
        CelestialUiAssets.ApplySliderTrack(sliderObject.GetComponent<Image>());

        Slider slider = sliderObject.GetComponent<Slider>();
        slider.minValue = 0f;
        slider.maxValue = 1f;
        slider.value = 0.75f;

        GameObject fillArea = CreateUIObject("Fill Area", sliderObject.transform);
        RectTransform fillAreaRect = fillArea.GetComponent<RectTransform>();
        Stretch(fillAreaRect);
        fillAreaRect.offsetMin = new Vector2(6f, 6f);
        fillAreaRect.offsetMax = new Vector2(-6f, -6f);

        GameObject fill = CreateUIObject("Fill", fillArea.transform, typeof(Image));
        Stretch(fill.GetComponent<RectTransform>());
        CelestialUiAssets.ApplySliderFill(fill.GetComponent<Image>());

        GameObject handleArea = CreateUIObject("Handle Slide Area", sliderObject.transform);
        Stretch(handleArea.GetComponent<RectTransform>());

        GameObject handle = CreateUIObject("Handle", handleArea.transform, typeof(Image));
        RectTransform handleRect = handle.GetComponent<RectTransform>();
        handleRect.anchorMin = new Vector2(0.5f, 0.5f);
        handleRect.anchorMax = new Vector2(0.5f, 0.5f);
        handleRect.sizeDelta = new Vector2(28f, 34f);
        CelestialUiAssets.ApplySliderHandle(handle.GetComponent<Image>());

        slider.fillRect = fill.GetComponent<RectTransform>();
        slider.handleRect = handleRect;
        slider.targetGraphic = handle.GetComponent<Image>();

        return slider;
    }

    private Toggle CreateToggle(Transform parent, string objectName, string label, Vector2 position)
    {
        // Toggle은 체크박스 역할을 합니다.
        // targetGraphic은 기본 박스, graphic은 체크 표시로 쓰입니다.
        GameObject toggleObject = CreateUIObject(objectName, parent, typeof(Toggle));
        RectTransform rect = toggleObject.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.5f, 0.5f);
        rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.anchoredPosition = position;
        rect.sizeDelta = new Vector2(220f, 46f);

        GameObject background = CreateUIObject("Background", toggleObject.transform, typeof(Image));
        RectTransform backgroundRect = background.GetComponent<RectTransform>();
        backgroundRect.anchorMin = new Vector2(0f, 0.5f);
        backgroundRect.anchorMax = new Vector2(0f, 0.5f);
        backgroundRect.anchoredPosition = new Vector2(24f, 0f);
        backgroundRect.sizeDelta = new Vector2(32f, 32f);
        CelestialUiAssets.ApplySliderTrack(background.GetComponent<Image>());

        GameObject checkmark = CreateUIObject("Checkmark", background.transform, typeof(Image));
        RectTransform checkRect = checkmark.GetComponent<RectTransform>();
        Stretch(checkRect);
        checkRect.offsetMin = new Vector2(6f, 6f);
        checkRect.offsetMax = new Vector2(-6f, -6f);
        CelestialUiAssets.ApplySliderFill(checkmark.GetComponent<Image>());

        CreateText(toggleObject.transform, "Label", label, 20, TextAnchor.MiddleLeft, new Vector2(0f, 0f), new Vector2(1f, 1f), new Vector2(72f, 0f), new Vector2(-74f, 0f));

        Toggle toggle = toggleObject.GetComponent<Toggle>();
        toggle.targetGraphic = background.GetComponent<Image>();
        toggle.graphic = checkmark.GetComponent<Image>();
        return toggle;
    }

    private TMP_Dropdown CreateDropdown(Transform parent, string objectName, string label, Vector2 position, List<string> options)
    {
        // TextMeshPro 드롭다운을 코드로 생성합니다.
        // captionText는 현재 선택된 항목을 보여주는 텍스트입니다.
        GameObject holder = CreateUIObject(objectName + " Row", parent);
        RectTransform holderRect = holder.GetComponent<RectTransform>();
        holderRect.anchorMin = new Vector2(0.5f, 0.5f);
        holderRect.anchorMax = new Vector2(0.5f, 0.5f);
        holderRect.anchoredPosition = position;
        holderRect.sizeDelta = new Vector2(250f, 56f);

        CreateText(holder.transform, "Label", label, 20, TextAnchor.MiddleLeft, new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(48f, 0f), new Vector2(92f, 46f));

        GameObject dropdownObject = CreateUIObject(objectName, holder.transform, typeof(Image), typeof(TMP_Dropdown));
        RectTransform dropdownRect = dropdownObject.GetComponent<RectTransform>();
        dropdownRect.anchorMin = new Vector2(1f, 0.5f);
        dropdownRect.anchorMax = new Vector2(1f, 0.5f);
        dropdownRect.anchoredPosition = new Vector2(-66f, 0f);
        dropdownRect.sizeDelta = new Vector2(130f, 40f);
        CelestialUiAssets.ApplyButton(dropdownObject.GetComponent<Image>());

        TMP_Dropdown dropdown = dropdownObject.GetComponent<TMP_Dropdown>();
        TMP_Text caption = CreateTMPText(dropdownObject.transform, "Label", options.Count > 0 ? options[0] : "", 16, TextAlignmentOptions.Center);
        Stretch(caption.GetComponent<RectTransform>());
        dropdown.captionText = caption;
        dropdown.options.Clear();
        dropdown.AddOptions(options);
        return dropdown;
    }

    private GameObject CreateButton(Transform parent, string objectName, string label, Vector2 position, Vector2 size)
    {
        GameObject buttonObject = CreateUIObject(objectName, parent, typeof(Image), typeof(Button));
        RectTransform rect = buttonObject.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.5f, 0f);
        rect.anchorMax = new Vector2(0.5f, 0f);
        rect.anchoredPosition = position;
        rect.sizeDelta = size;
        Image image = buttonObject.GetComponent<Image>();
        CelestialUiAssets.ApplyButton(image);
        CelestialUiAssets.ConfigureButton(buttonObject.GetComponent<Button>(), image);

        Text text = CreateText(buttonObject.transform, "Label", label, 24, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        text.raycastTarget = false;

        return buttonObject;
    }

    private void CreateDivider(Transform parent, string objectName, Vector2 position, Vector2 size)
    {
        GameObject dividerObject = CreateUIObject(objectName, parent, typeof(Image));
        RectTransform rect = dividerObject.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.5f, 1f);
        rect.anchorMax = new Vector2(0.5f, 1f);
        rect.anchoredPosition = position;
        rect.sizeDelta = size;

        Image image = dividerObject.GetComponent<Image>();
        CelestialUiAssets.ApplyDivider(image);
        image.raycastTarget = false;
    }

    private Text CreateText(Transform parent, string objectName, string value, int size, TextAnchor alignment, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
    {
        GameObject textObject = CreateUIObject(objectName, parent, typeof(Text));
        RectTransform rect = textObject.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = sizeDelta;

        Text text = textObject.GetComponent<Text>();
        text.text = value;
        text.font = GetBuiltinFont();
        text.fontSize = size;
        text.alignment = alignment;
        ReadableTextStyle.Apply(text);
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 12;
        text.resizeTextMaxSize = size;
        return text;
    }

    private TMP_Text CreateTMPText(Transform parent, string objectName, string value, int size, TextAlignmentOptions alignment)
    {
        GameObject textObject = CreateUIObject(objectName, parent, typeof(TextMeshProUGUI));
        TMP_Text text = textObject.GetComponent<TMP_Text>();
        text.text = value;
        text.fontSize = size;
        text.alignment = alignment;
        text.color = Color.white;
        ReadableTextStyle.Apply(text);
        return text;
    }

    private GameObject CreateUIObject(string objectName, Transform parent, params System.Type[] components)
    {
        // UI 오브젝트는 보통 RectTransform과 CanvasRenderer가 필요합니다.
        // 매번 반복해서 적지 않도록 이 helper가 기본 컴포넌트를 자동으로 붙입니다.
        List<System.Type> componentList = new List<System.Type> { typeof(RectTransform), typeof(CanvasRenderer) };
        componentList.AddRange(components);

        GameObject go = new GameObject(objectName, componentList.ToArray());
        go.transform.SetParent(parent, false);
        return go;
    }

    private void Stretch(RectTransform rect)
    {
        // Stretch는 부모 영역을 꽉 채우는 앵커 설정입니다.
        // anchorMin=(0,0), anchorMax=(1,1), offset=0이면 부모 크기에 맞춰 자동으로 늘어납니다.
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }

    private Font GetBuiltinFont()
    {
        return ReadableTextStyle.GetReadableFont();
    }
}
