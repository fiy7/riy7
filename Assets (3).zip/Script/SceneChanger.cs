using UnityEngine;
using UnityEngine.SceneManagement;

// 씬 이동 전용 컴포넌트입니다.
// 버튼의 OnClick 이벤트에 이 컴포넌트의 함수를 연결하면,
// 사용자가 버튼을 눌렀을 때 지정한 Unity 씬으로 이동할 수 있습니다.
//
// 주의:
// 클래스 이름이 UnityEngine.SceneManagement.SceneManager와 같아서,
// 아래에서는 Unity 내장 SceneManager를 전체 이름으로 적어 구분하고 있습니다.
//
// 초심자용 핵심 개념:
// - 씬은 Unity에서 하나의 화면 또는 단계라고 생각하면 됩니다.
// - LoadScene("씬이름")을 호출하면 그 이름의 씬으로 이동합니다.
// - 이동하려는 씬은 File > Build Settings의 Scenes In Build 목록에 들어 있어야 합니다.
public class SceneManager : MonoBehaviour
{
   // 버튼에 연결하거나 직접 호출할 함수입니다.
   // 현재 프로젝트의 시작 스토리 씬 이름이 "startstory"라서 고정 문자열로 이동합니다.
    public void GoToStartStory()
    {
        // intface의 시작 버튼을 눌렀을 때 호출됩니다.
        // 단순히 startstory 씬만 여는 것이 아니라,
        // StoryBattleFlow가 가진 진행도를 0부/첫 전투로 초기화한 뒤 스토리를 시작합니다.
        StoryBattleFlow.LoadIntroStory();
    }

    public void GoToStartStroy()
    {
        // startstroy처럼 철자를 잘못 적어 연결해도 같은 기능이 실행되도록 만든 별칭 함수입니다.
        // 실제 씬 파일 이름은 startstory이므로 내부에서는 GoToStartStory를 다시 호출합니다.
        GoToStartStory();
    }

    public void GoToFullStory()
    {
        StoryBattleFlow.LoadFullStory();
    }

    public void GoToFullStroy()
    {
        GoToFullStory();
    }

    // 다른 씬 이름을 매개변수로 받아 범용적으로 쓸 수 있는 함수입니다.
    // Unity 버튼 OnClick에서 문자열 인자를 넣으면 같은 함수로 여러 씬 이동 버튼을 만들 수 있습니다.
    public void ChangeScene(string sceneName)
    {
       UnityEngine.SceneManagement.SceneManager.LoadScene(sceneName);
    }
}
