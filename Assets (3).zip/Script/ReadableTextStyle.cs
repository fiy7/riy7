using TMPro;
using UnityEngine;
using UnityEngine.UI;

public static class ReadableTextStyle
{
    private const string ReadableFontResourcePath = "Fonts/Hakgyoansim Byeolbichhaneul TTF B";
    private static Font cachedFont;
    private static TMP_FontAsset cachedTmpFont;

    public static Font GetReadableFont()
    {
        if (cachedFont != null) return cachedFont;

        cachedFont = Resources.Load<Font>(ReadableFontResourcePath);
        if (cachedFont == null) cachedFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (cachedFont == null) cachedFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
        return cachedFont;
    }

    public static TMP_FontAsset GetReadableTMPFont()
    {
        if (cachedTmpFont != null) return cachedTmpFont;

        Font font = GetReadableFont();
        if (font != null)
        {
            cachedTmpFont = TMP_FontAsset.CreateFontAsset(font);
            if (cachedTmpFont != null)
            {
                cachedTmpFont.name = "Runtime Korean TMP Font";
                cachedTmpFont.atlasPopulationMode = AtlasPopulationMode.Dynamic;
                return cachedTmpFont;
            }
        }

        cachedTmpFont = TMP_Settings.defaultFontAsset;
        return cachedTmpFont;
    }

    public static void Apply(Text text)
    {
        if (text == null) return;

        Font font = GetReadableFont();
        if (font != null) text.font = font;

        text.fontStyle = FontStyle.Normal;
        text.color = new Color(0.94f, 0.98f, 1f, 1f);

        Outline outline = text.GetComponent<Outline>();
        if (outline == null) outline = text.gameObject.AddComponent<Outline>();
        outline.effectColor = new Color(0f, 0.02f, 0.055f, 0.95f);
        outline.effectDistance = new Vector2(0.9f, -0.9f);
        outline.useGraphicAlpha = false;
    }

    public static void Apply(TMP_Text text)
    {
        if (text == null) return;

        TMP_FontAsset font = GetReadableTMPFont();
        if (font != null) text.font = font;

        text.color = new Color(0.94f, 0.98f, 1f, 1f);
        text.textWrappingMode = TextWrappingModes.Normal;

        text.outlineWidth = Mathf.Max(text.outlineWidth, 0.12f);
        text.outlineColor = new Color(0f, 0.02f, 0.055f, 0.95f);
    }
}
