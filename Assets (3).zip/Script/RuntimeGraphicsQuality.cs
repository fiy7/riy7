using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.Rendering;

// 그래픽 품질 버튼이 실제 화면 품질까지 바꾸도록 모아둔 공통 컨트롤러입니다.
// QualitySettings.SetQualityLevel만 호출하면 프로젝트의 URP 렌더 스케일이나 MSAA가 그대로라
// 버튼을 눌러도 체감 변화가 적을 수 있으므로, 여기서 런타임 렌더 설정까지 함께 적용합니다.
public static class RuntimeGraphicsQuality
{
    private const string QualityPrefsKey = "Quality";

    private struct GraphicsProfile
    {
        public float renderScale;
        public int antiAliasing;
        public int textureLimit;
        public int targetFrameRate;
        public float lodBias;
        public float shadowDistance;
        public ShadowQuality shadowQuality;
        public ShadowResolution shadowResolution;
        public AnisotropicFiltering anisotropicFiltering;
        public int urpMsaa;
        public int urpShadowmapResolution;
        public int urpShadowCascadeCount;
        public bool hdr;
        public bool softShadows;
        public bool postProcessing;

        public GraphicsProfile(
            float renderScale,
            int antiAliasing,
            int textureLimit,
            int targetFrameRate,
            float lodBias,
            float shadowDistance,
            ShadowQuality shadowQuality,
            ShadowResolution shadowResolution,
            AnisotropicFiltering anisotropicFiltering,
            int urpMsaa,
            int urpShadowmapResolution,
            int urpShadowCascadeCount,
            bool hdr,
            bool softShadows,
            bool postProcessing)
        {
            this.renderScale = renderScale;
            this.antiAliasing = antiAliasing;
            this.textureLimit = textureLimit;
            this.targetFrameRate = targetFrameRate;
            this.lodBias = lodBias;
            this.shadowDistance = shadowDistance;
            this.shadowQuality = shadowQuality;
            this.shadowResolution = shadowResolution;
            this.anisotropicFiltering = anisotropicFiltering;
            this.urpMsaa = urpMsaa;
            this.urpShadowmapResolution = urpShadowmapResolution;
            this.urpShadowCascadeCount = urpShadowCascadeCount;
            this.hdr = hdr;
            this.softShadows = softShadows;
            this.postProcessing = postProcessing;
        }
    }

    public static int QualityCount => Mathf.Max(1, QualitySettings.names.Length);

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void ApplySavedQualityOnSceneLoad()
    {
        Apply(GetSavedQualityIndex(), false);
    }

    public static int GetSavedQualityIndex()
    {
        return Mathf.Clamp(PlayerPrefs.GetInt(QualityPrefsKey, QualitySettings.GetQualityLevel()), 0, QualityCount - 1);
    }

    public static string GetQualityLabel(int qualityIndex)
    {
        string[] koreanLabelsForSixSteps = { "매우 낮음", "낮음", "보통", "높음", "매우 높음", "울트라" };
        if (QualityCount == koreanLabelsForSixSteps.Length && qualityIndex >= 0 && qualityIndex < koreanLabelsForSixSteps.Length)
        {
            return koreanLabelsForSixSteps[qualityIndex];
        }

        string[] fallbackLabels = { "낮음", "보통", "높음" };
        if (qualityIndex >= 0 && qualityIndex < fallbackLabels.Length) return fallbackLabels[qualityIndex];
        if (qualityIndex >= 0 && qualityIndex < QualitySettings.names.Length) return QualitySettings.names[qualityIndex];
        return "그래픽";
    }

    public static int Apply(int qualityIndex, bool save = true)
    {
        int safeQualityIndex = Mathf.Clamp(qualityIndex, 0, QualityCount - 1);
        GraphicsProfile profile = GetProfile(safeQualityIndex);

        QualitySettings.SetQualityLevel(safeQualityIndex, true);
        ApplyBuiltInQuality(profile);
        ApplyRenderPipelineQuality(profile);
        ApplyCameraQuality(profile);

        if (save)
        {
            PlayerPrefs.SetInt(QualityPrefsKey, safeQualityIndex);
            PlayerPrefs.Save();
        }

        return safeQualityIndex;
    }

    private static GraphicsProfile GetProfile(int qualityIndex)
    {
        float normalizedQuality = QualityCount <= 1 ? 1f : qualityIndex / (float)(QualityCount - 1);

        if (normalizedQuality < 0.2f)
        {
            return new GraphicsProfile(0.72f, 0, 1, 45, 0.55f, 12f, ShadowQuality.Disable, ShadowResolution.Low, AnisotropicFiltering.Disable, 1, 512, 1, false, false, false);
        }

        if (normalizedQuality < 0.4f)
        {
            return new GraphicsProfile(0.86f, 0, 0, 60, 0.8f, 24f, ShadowQuality.HardOnly, ShadowResolution.Low, AnisotropicFiltering.Disable, 1, 1024, 1, false, false, false);
        }

        if (normalizedQuality < 0.6f)
        {
            return new GraphicsProfile(1f, 2, 0, 60, 1f, 40f, ShadowQuality.All, ShadowResolution.Medium, AnisotropicFiltering.Enable, 2, 2048, 1, true, false, true);
        }

        if (normalizedQuality < 0.8f)
        {
            return new GraphicsProfile(1.12f, 4, 0, 90, 1.25f, 70f, ShadowQuality.All, ShadowResolution.High, AnisotropicFiltering.ForceEnable, 4, 2048, 2, true, true, true);
        }

        if (normalizedQuality < 1f)
        {
            return new GraphicsProfile(1.22f, 4, 0, 120, 1.55f, 100f, ShadowQuality.All, ShadowResolution.VeryHigh, AnisotropicFiltering.ForceEnable, 4, 4096, 4, true, true, true);
        }

        return new GraphicsProfile(1.3f, 8, 0, 144, 1.85f, 130f, ShadowQuality.All, ShadowResolution.VeryHigh, AnisotropicFiltering.ForceEnable, 8, 4096, 4, true, true, true);
    }

    private static void ApplyBuiltInQuality(GraphicsProfile profile)
    {
        QualitySettings.antiAliasing = profile.antiAliasing;
        QualitySettings.shadows = profile.shadowQuality;
        QualitySettings.shadowResolution = profile.shadowResolution;
        QualitySettings.shadowDistance = profile.shadowDistance;
        QualitySettings.shadowCascades = profile.urpShadowCascadeCount;
        QualitySettings.anisotropicFiltering = profile.anisotropicFiltering;
        QualitySettings.lodBias = profile.lodBias;
        QualitySettings.realtimeReflectionProbes = profile.renderScale >= 1f;
        QualitySettings.softParticles = profile.softShadows;
        QualitySettings.vSyncCount = profile.targetFrameRate >= 90 ? 1 : 0;
        Application.targetFrameRate = profile.targetFrameRate;

        SetStaticMember(typeof(QualitySettings), "globalTextureMipmapLimit", profile.textureLimit);
        SetStaticMember(typeof(QualitySettings), "masterTextureLimit", profile.textureLimit);
    }

    private static void ApplyRenderPipelineQuality(GraphicsProfile profile)
    {
        RenderPipelineAsset pipelineAsset = QualitySettings.renderPipeline != null
            ? QualitySettings.renderPipeline
            : GraphicsSettings.currentRenderPipeline;

        if (pipelineAsset == null) return;

        SetMember(pipelineAsset, "renderScale", profile.renderScale);
        SetMember(pipelineAsset, "m_RenderScale", profile.renderScale);
        SetMember(pipelineAsset, "msaaSampleCount", profile.urpMsaa);
        SetMember(pipelineAsset, "m_MSAA", profile.urpMsaa);
        SetMember(pipelineAsset, "supportsHDR", profile.hdr);
        SetMember(pipelineAsset, "m_SupportsHDR", profile.hdr);
        SetMember(pipelineAsset, "supportsMainLightShadows", profile.shadowQuality != ShadowQuality.Disable);
        SetMember(pipelineAsset, "m_MainLightShadowsSupported", profile.shadowQuality != ShadowQuality.Disable);
        SetMember(pipelineAsset, "mainLightShadowmapResolution", profile.urpShadowmapResolution);
        SetMember(pipelineAsset, "m_MainLightShadowmapResolution", profile.urpShadowmapResolution);
        SetMember(pipelineAsset, "additionalLightsShadowmapResolution", profile.urpShadowmapResolution);
        SetMember(pipelineAsset, "m_AdditionalLightsShadowmapResolution", profile.urpShadowmapResolution);
        SetMember(pipelineAsset, "shadowDistance", profile.shadowDistance);
        SetMember(pipelineAsset, "m_ShadowDistance", profile.shadowDistance);
        SetMember(pipelineAsset, "shadowCascadeCount", profile.urpShadowCascadeCount);
        SetMember(pipelineAsset, "m_ShadowCascadeCount", profile.urpShadowCascadeCount);
        SetMember(pipelineAsset, "supportsSoftShadows", profile.softShadows);
        SetMember(pipelineAsset, "m_SoftShadowsSupported", profile.softShadows);
        SetMember(pipelineAsset, "softShadowQuality", profile.softShadows ? 3 : 0);
        SetMember(pipelineAsset, "m_SoftShadowQuality", profile.softShadows ? 3 : 0);
    }

    private static void ApplyCameraQuality(GraphicsProfile profile)
    {
        Camera[] cameras = UnityEngine.Object.FindObjectsByType<Camera>(FindObjectsSortMode.None);
        foreach (Camera camera in cameras)
        {
            if (camera == null) continue;

            camera.allowHDR = profile.hdr;
            camera.allowMSAA = profile.antiAliasing > 0;

            Component[] components = camera.GetComponents<Component>();
            for (int i = 0; i < components.Length; i++)
            {
                Component component = components[i];
                if (component == null) continue;
                if (!component.GetType().Name.Contains("UniversalAdditionalCameraData")) continue;

                SetMember(component, "renderPostProcessing", profile.postProcessing);
                SetMember(component, "renderShadows", profile.shadowQuality != ShadowQuality.Disable);
                SetMember(component, "antialiasing", profile.antiAliasing > 0 ? 2 : 0);
                SetMember(component, "antialiasingQuality", profile.renderScale >= 1.2f ? 2 : 1);
            }
        }
    }

    private static void SetStaticMember(Type type, string memberName, object value)
    {
        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;

        PropertyInfo property = type.GetProperty(memberName, flags);
        if (property != null && property.CanWrite)
        {
            property.SetValue(null, ConvertValue(value, property.PropertyType));
            return;
        }

        FieldInfo field = type.GetField(memberName, flags);
        if (field != null)
        {
            field.SetValue(null, ConvertValue(value, field.FieldType));
        }
    }

    private static void SetMember(object target, string memberName, object value)
    {
        if (target == null) return;

        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
        Type type = target.GetType();

        PropertyInfo property = type.GetProperty(memberName, flags);
        if (property != null && property.CanWrite)
        {
            property.SetValue(target, ConvertValue(value, property.PropertyType));
            return;
        }

        FieldInfo field = type.GetField(memberName, flags);
        if (field != null)
        {
            field.SetValue(target, ConvertValue(value, field.FieldType));
        }
    }

    private static object ConvertValue(object value, Type targetType)
    {
        if (targetType.IsEnum)
        {
            return Enum.ToObject(targetType, Mathf.RoundToInt(Convert.ToSingle(value)));
        }

        if (targetType == typeof(int)) return Mathf.RoundToInt(Convert.ToSingle(value));
        if (targetType == typeof(float)) return Convert.ToSingle(value);
        if (targetType == typeof(bool)) return Convert.ToBoolean(value);
        return value;
    }
}
