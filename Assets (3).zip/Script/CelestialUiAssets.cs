using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public static class CelestialUiAssets
{
    private const string ResourceRoot = "UI/";
    private static readonly Dictionary<string, Sprite> spriteCache = new Dictionary<string, Sprite>();

    public static void ApplyWindow(Image image)
    {
        ApplySliced(image, "CelestialPanel", new Vector4(72f, 72f, 72f, 72f), new Color(0.045f, 0.055f, 0.078f, 0.98f));
    }

    public static void ApplyBody(Image image)
    {
        ApplySliced(image, "CelestialBody", new Vector4(56f, 56f, 56f, 56f), new Color(0.02f, 0.024f, 0.036f, 0.9f));
    }

    public static void ApplyButton(Image image)
    {
        ApplySliced(image, "CelestialButton", new Vector4(44f, 44f, 44f, 44f), new Color(0.08f, 0.12f, 0.18f, 1f));
    }

    public static void ApplySliderTrack(Image image)
    {
        ApplySliced(image, "CelestialSliderTrack", new Vector4(28f, 28f, 28f, 28f), new Color(0.12f, 0.13f, 0.16f, 1f));
    }

    public static void ApplySliderFill(Image image)
    {
        ApplySliced(image, "CelestialSliderFill", new Vector4(28f, 28f, 28f, 28f), new Color(0.24f, 0.78f, 1f, 1f));
    }

    public static void ApplySliderHandle(Image image)
    {
        ApplySimple(image, "CelestialSliderHandle", new Color(0.9f, 0.96f, 1f, 1f));
    }

    public static void ApplyDivider(Image image)
    {
        ApplySimple(image, "CelestialDivider", new Color(0.35f, 0.82f, 1f, 0.55f));
        if (image != null) image.preserveAspect = false;
    }

    public static void ConfigureButton(Button button, Image image)
    {
        if (button == null) return;

        button.targetGraphic = image;
        Sprite pressedSprite = GetSprite("CelestialButtonPressed", new Vector4(44f, 44f, 44f, 44f));
        if (pressedSprite != null)
        {
            button.transition = Selectable.Transition.SpriteSwap;
            SpriteState state = button.spriteState;
            state.highlightedSprite = pressedSprite;
            state.pressedSprite = pressedSprite;
            state.selectedSprite = pressedSprite;
            button.spriteState = state;
            return;
        }

        button.transition = Selectable.Transition.ColorTint;
        ColorBlock colors = button.colors;
        colors.normalColor = Color.white;
        colors.highlightedColor = new Color(0.9f, 0.98f, 1f, 1f);
        colors.pressedColor = new Color(0.72f, 0.86f, 0.95f, 1f);
        colors.selectedColor = colors.highlightedColor;
        colors.disabledColor = new Color(0.45f, 0.48f, 0.52f, 0.6f);
        colors.colorMultiplier = 1f;
        button.colors = colors;
    }

    private static void ApplySliced(Image image, string resourceName, Vector4 border, Color fallbackColor)
    {
        ApplySprite(image, resourceName, border, Image.Type.Sliced, fallbackColor);
    }

    private static void ApplySimple(Image image, string resourceName, Color fallbackColor)
    {
        ApplySprite(image, resourceName, Vector4.zero, Image.Type.Simple, fallbackColor);
    }

    private static void ApplySprite(Image image, string resourceName, Vector4 border, Image.Type imageType, Color fallbackColor)
    {
        if (image == null) return;

        Sprite sprite = GetSprite(resourceName, border);
        if (sprite == null)
        {
            image.sprite = null;
            image.type = Image.Type.Simple;
            image.color = fallbackColor;
            return;
        }

        image.sprite = sprite;
        image.type = imageType;
        image.color = Color.white;
    }

    private static Sprite GetSprite(string resourceName, Vector4 border)
    {
        string key = resourceName + ":" + border;
        if (spriteCache.TryGetValue(key, out Sprite cachedSprite)) return cachedSprite;

        Texture2D texture = Resources.Load<Texture2D>(ResourceRoot + resourceName);
        if (texture == null) return null;

        texture.wrapMode = TextureWrapMode.Clamp;
        Sprite sprite = Sprite.Create(
            texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f),
            100f,
            0,
            SpriteMeshType.FullRect,
            border);

        spriteCache[key] = sprite;
        return sprite;
    }
}
