using UnityEngine;

// 카드 효과 실행 전용 파일입니다.
// Card.cs가 "클릭했다"를 감지하면, 이 파일이 CardDate의 ability 값을 보고 실제 효과를 실행합니다.
//
// static class로 만든 이유:
// - 씬에 따로 GameObject를 만들 필요 없이 CardAbilityLibrary.Execute(data)로 바로 호출할 수 있습니다.
// - 카드 효과는 대부분 BattleManager 같은 싱글톤에 명령을 보내는 형태라 인스턴스 상태가 거의 필요 없습니다.
//
// 읽는 법:
// 1. Execute 함수의 switch에서 카드 능력 종류를 찾습니다.
// 2. 공격 카드라면 Attack helper로 들어갑니다.
// 3. Attack helper는 최종적으로 BattleManager.DealDamageToEnemy를 호출합니다.
//
// 초심자용 핵심 개념:
// - switch는 값에 따라 여러 갈래 중 하나를 실행하는 문법입니다.
// - case 하나가 카드 능력 하나라고 생각하면 됩니다.
// - break는 해당 case 처리가 끝났다는 뜻입니다. break가 없으면 다음 case까지 이어질 수 있습니다.
// - static 함수는 오브젝트를 만들지 않고 바로 호출할 수 있습니다.
public static class CardAbilityLibrary
{
    public static void Execute(CardDate data)
    {
        // 카드 데이터나 전투 매니저가 없으면 효과를 실행할 수 없습니다.
        if (data == null || BattleManager.Instance == null) return;

        // ability enum을 기준으로 어떤 효과를 발동할지 나눕니다.
        // case 안에는 긴 계산을 넣지 않고, 카드별 함수만 호출합니다.
        // 그래서 새 카드를 추가할 때도 "enum 추가 -> case 추가 -> 함수 작성" 순서로 따라가면 됩니다.
        switch (data.ability)
        {
            case CardDate.CardAbility.AriesStrike:
            case CardDate.CardAbility.TaurusCharge:
                UseNormalAttack(data);
                break;
            case CardDate.CardAbility.CancerCrush:
                UseCancerCrush(data);
                break;
            case CardDate.CardAbility.GeminiShield:
                UseGeminiShield(data);
                break;
            case CardDate.CardAbility.VirgoVeil:
                UseVirgoVeil(data);
                break;
            case CardDate.CardAbility.LibraBalance:
                UseLibraBalance(data);
                break;
            case CardDate.CardAbility.ScorpioPoison:
                UseScorpioPoison(data);
                break;
            case CardDate.CardAbility.SagittariusUltimate:
                UseSagittariusUltimate(data);
                break;
            case CardDate.CardAbility.CapricornStack:
                UseCapricornStack(data);
                break;
            case CardDate.CardAbility.AquariusEnergy:
                UseAquariusEnergy(data);
                break;
            case CardDate.CardAbility.PiscesEmpower:
                UsePiscesEmpower(data);
                break;
            case CardDate.CardAbility.LeoEcho:
                UseLeoEcho(data);
                break;
        }

        CardFusionLibrary.ResolveAfterCard(data);
        CardFusionLibrary.RecordCard(data);
    }

    private static void UseNormalAttack(CardDate data)
    {
        // 양자리/황소자리처럼 단순히 현재 타겟을 공격하는 카드입니다.
        float damage = GetMultipliedPower(data);
        Attack(data, damage);
    }

    private static void UseCancerCrush(CardDate data)
    {
        // 게자리: 단단한 집게로 모든 적을 한 번에 찍어 누릅니다.
        AreaAttack(data, GetMultipliedPower(data));
    }

    private static void UseGeminiShield(CardDate data)
    {
        // 쌍둥이자리: 방어막 생성
        BattleManager.Instance.AddShield(data.shieldAmount, data.shieldRatio);
    }

    private static void UseVirgoVeil(CardDate data)
    {
        // 처녀자리: 다음 적 턴 단일 피해 제한 + 디버프 정화
        BattleManager.Instance.ActivateVirgoVeil(data.damageCap);
    }

    private static void UseLibraBalance(CardDate data)
    {
        // 천칭자리: 일정 턴 동안 공격 버프
        BattleManager.Instance.AddBalanceBuff(data.buffStacks, data.buffTurns);
    }

    private static void UseScorpioPoison(CardDate data)
    {
        // 전갈자리: 즉시 피해 + 독 부여
        Attack(data, GetMultipliedPower(data));
        BattleManager.Instance.ApplyPoisonToEnemy(data.poisonDamage, data.poisonTurns);
    }

    private static void UseSagittariusUltimate(CardDate data)
    {
        // 사수자리: 달의 기운 100%일 때만 쓰는 필살기입니다.
        if (!BattleManager.Instance.CanUseUltimate()) return;

        AreaAttack(data, GetMultipliedPower(data));
        BattleManager.Instance.ApplyWeatheringToAllEnemies(Mathf.Max(1, data.weatheringTurns));
        BattleManager.Instance.SpendMoonGauge();
    }

    private static void UseCapricornStack(CardDate data)
    {
        // 염소자리: 사용할수록 피해가 증가하는 중첩 공격
        BattleManager.Instance.AddCapricornStack(data.maxStacks);

        float stackBonus = BattleManager.Instance.capricornStack * data.stackDamageBonus;
        float damage = data.power + stackBonus;
        AreaAttack(data, damage);
    }

    private static void UseAquariusEnergy(CardDate data)
    {
        // 물병자리: 한 턴에 한 번만 기력 회복
        bool success = BattleManager.Instance.TryUseAquarius(data.energyGain);
        if (!success)
        {
            Debug.Log("물병자리는 한 턴에 1번만 사용할 수 있습니다.");
        }
    }

    private static void UsePiscesEmpower(CardDate data)
    {
        // 물고기자리: 기력/체력 회복 + 다음 공격 강화
        if (data.energyGain > 0)
        {
            BattleManager.Instance.GainEnergy(data.energyGain);
        }

        if (data.healAmount > 0f)
        {
            BattleManager.Instance.HealPlayer(data.healAmount);
        }

        BattleManager.Instance.EmpowerNextAttack(data.nextAttackMultiplier);
    }

    private static void UseLeoEcho(CardDate data)
    {
        // 사자자리: 바로 전 플레이어 턴의 최고 공격을 증폭합니다.
        // 기억할 공격이 없으면 0 피해가 되지 않도록 카드 기본 위력으로 공격합니다.
        float rememberedDamage = BattleManager.Instance.lastStrongestDamage;
        float damage = rememberedDamage > 0f
            ? rememberedDamage * GetSafeMultiplier(data)
            : Mathf.Max(1f, data.power);

        if (rememberedDamage <= 0f && UIManager.Instance != null)
        {
            UIManager.Instance.ShowTurnNotice("사자자리: 기억할 공격이 없어 기본 피해로 공격합니다.", 2f);
        }

        Attack(data, damage);
    }

    private static float GetMultipliedPower(CardDate data)
    {
        return data.power * GetSafeMultiplier(data);
    }

    private static float GetSafeMultiplier(CardDate data)
    {
        // 배율을 0이나 음수로 넣어도 최소 1배로 처리합니다.
        return Mathf.Max(1f, data.damageMultiplier);
    }

    private static void Attack(CardDate data, float damage)
    {
        // 공격형 카드들이 공통으로 사용하는 피해 적용 함수입니다.
        // 여기서 damage는 "카드가 의도한 기본 피해"이고,
        // 실제로 적 HP에서 빠지는 최종 피해는 BattleManager.CalculatePlayerDamage에서 결정됩니다.
        Debug.Log($"{data.cardName} 카드 발동: {damage:F0} 피해");
        BattleManager.Instance.DealDamageToEnemy(damage);
    }

    private static void AreaAttack(CardDate data, float damage)
    {
        Debug.Log($"{data.cardName} 카드 발동: 모든 적에게 {damage:F0} 피해");
        BattleManager.Instance.DealDamageToAllEnemies(damage);
    }
}
