using UnityEngine;

// 전투의 중앙 관리자입니다.
// 체력, 기력, 달의 기운, 적 등장 순서, 피해 계산처럼 "전투 규칙" 대부분을 여기서 관리합니다.
//
// 이 파일을 공부할 때 읽는 순서:
// 1. 위쪽 필드: 전투에 필요한 상태값이 무엇인지 확인합니다.
// 2. StartPlayerTurn / StartEnemyTurn: 턴 시작 때 어떤 값이 정리되는지 봅니다.
// 3. DealDamageToEnemy / TakePlayerDamage: 피해가 실제 HP에 적용되는 흐름을 봅니다.
// 4. EnemyAction: 적 종류별 행동 패턴을 봅니다.
// 5. SpawnEnemy / AdvanceEnemyStageOrWin: 적이 죽고 다음 스테이지로 넘어가는 흐름을 봅니다.
//
// 역할 분리:
// - BattleManager: 실제 숫자와 규칙을 계산합니다.
// - BattleVisualManager: 계산 결과를 화면 연출로 보여줍니다.
// - UIManager: HP바, 기력 구슬, 달 게이지 같은 UI를 갱신합니다.
//
// 초심자용 핵심 개념:
// - "필드"는 클래스 안에 저장되는 변수입니다. 예를 들어 currentPlayerHP는 현재 플레이어 체력을 기억합니다.
// - "public"은 다른 스크립트가 접근할 수 있다는 뜻입니다. CardAbilityLibrary가 BattleManager.Instance로 전투 값을 바꿀 수 있습니다.
// - "private"은 이 파일 안에서만 쓰겠다는 뜻입니다. 외부에서 함부로 바꾸면 위험한 내부 상태에 사용합니다.
// - "[SerializeField] private"은 외부 코드에서는 못 바꾸지만 Unity Inspector에서는 볼 수 있게 하는 방식입니다.
// - "const"는 게임 실행 중 바뀌지 않는 고정값입니다. MAX_ENERGY처럼 규칙 자체인 값에 사용합니다.
//
// 전투 한 사이클 예시:
// 1. TurnManager가 StartPlayerTurn을 호출합니다.
// 2. 플레이어는 카드를 클릭합니다.
// 3. Card -> CardAbilityLibrary -> BattleManager 순서로 카드 효과가 전달됩니다.
// 4. BattleManager가 피해/회복/방어막/디버프를 계산합니다.
// 5. BattleVisualManager와 UIManager가 그 결과를 화면에 보여줍니다.
// 6. 턴 종료 버튼을 누르면 TurnManager가 StartEnemyTurn과 EnemyAction을 호출합니다.
public class BattleManager : MonoBehaviour
{
    public static BattleManager Instance;

    // 현재 전투에 나올 수 있는 적 종류입니다.
    // enemyStageIndex가 증가하면서 아래 순서대로 적이 바뀝니다.
    public enum EnemyKind
    {
        VoidHowler,
        StarDustExecutor,
        FallenScorpio,
        StarAdversary
    }

    // 적마다 다른 체력/공격력/특수 규칙을 묶어두는 내부 데이터입니다.
    private struct EnemyBalance
    {
        public float maxHP;
        public float baseAttack;
        public float damageCap;
        public float handDiscardChance;
        public int scorpioInstantStack;

        public EnemyBalance(float maxHP, float baseAttack, float damageCap, float handDiscardChance, int scorpioInstantStack)
        {
            this.maxHP = maxHP;
            this.baseAttack = baseAttack;
            this.damageCap = damageCap;
            this.handDiscardChance = handDiscardChance;
            this.scorpioInstantStack = scorpioInstantStack;
        }
    }

    [Header("기력 데이터")]
    public int currentEnergy = 0;
    public const int MAX_ENERGY = 7;
    public const int ENERGY_PER_TURN = 3;

    [Header("전투 데이터")]
    [SerializeField] private float playerMaxHP = 150f;
    [SerializeField] private float enemyMaxHP = 120f;
    [SerializeField] private float enemyAttackDamage = 10f;
    [SerializeField] private EnemyKind enemyKind = EnemyKind.VoidHowler;
    [SerializeField] private float tutorialEnemyDamageCap = 16f;
    [SerializeField] private bool startBattleOnStart = true;

    [Header("초보자 설정 - 적 체력")]
    public float voidHowlerHP = 80f;
    public float starDustExecutorHP = 118f;
    public float fallenScorpioHP = 245f;
    public float starAdversaryHP = 390f;

    [Header("초보자 설정 - 적 기본 공격")]
    public float voidHowlerAttack = 6.5f;
    public float starDustExecutorAttack = 9.8f;
    public float fallenScorpioAttack = 10f;
    public float starAdversaryAttack = 12f;

    [Header("초보자 설정 - 특수 규칙")]
    public float tutorialEnemyDamageLimit = 14f;
    public float voidHowlerDiscardChance = 0.34f;
    public float specialAttackChance = 0.34f;
    public float weatheringDamage = 1.3f;
    public float weatheringEnemyAttackMultiplier = 0.8f;
    public float starAdversaryAuraDamage = 2f;
    public int scorpioInstantPoisonStack = 4;
    public float multiEnemyAttackMultiplier = 0.62f;
    public float voidHowlerPackHowlChance = 0.4f;
    public int voidHowlerPackEnergyDrain = 1;
    public float starDustFormationDamageReductionPerAlly = 0.11f;
    public float heavenlyPoisonMaxHpRatio = 0.2f;
    public int starAdversaryMeteorChargeMax = 3;

    [Header("정화 집행")]
    [SerializeField] private int purificationMaxStacks = 5;
    [SerializeField] private float defenseDownDamageMultiplier = 1.2f;
    [SerializeField] private int defenseDownTurnsOnHit = 2;
    [SerializeField] private float stardustExplosionDamage = 7f;

    public float currentPlayerHP;
    public float currentEnemyHP;
    public float currentShield;
    public bool IsBattleEnded { get; private set; }
    public int CurrentTurnCount { get; private set; }

    [Header("달의 기운 데이터")]
    public float moonGauge = 0f;
    public const float MAX_MOON_GAUGE = 100f;
    public const int MOON_GEM_COUNT = 5; // 달의 기운을 표시할 구슬 개수 (5칸)

    [Header("카드 효과 관련 데이터")]
    public int capricornStack = 0; // 염소자리 스택 변수 추가!
    public float lastStrongestDamage = 0f; // 사자자리용 직전 플레이어 턴 최고 피해 기록
    private int balanceBuffStacks;
    private int balanceBuffTurns;
    private float nextAttackMultiplier = 1f;
    private bool aquariusUsedThisTurn;
    private int heavenlyPoisonStacks;
    private bool virgoDamageCapActive;
    private float virgoDamageCap = 5f;

    private EnemyBalance enemyBalance;
    private int enemyStageIndex;
    private int enemyMemberIndex;
    private int enemyMemberCount;
    private int selectedEnemyIndex;
    private int pendingEnergyDrain;
    private int starAdversaryCharge;
    private const int MaxEnemyPartySize = 3;
    private readonly float[] enemyCurrentHPs = new float[MaxEnemyPartySize];
    private readonly float[] enemyMaxHPs = new float[MaxEnemyPartySize];
    private readonly bool[] enemyAliveStates = new bool[MaxEnemyPartySize];
    private readonly int[] enemyPoisonTurns = new int[MaxEnemyPartySize];
    private readonly float[] enemyPoisonDamages = new float[MaxEnemyPartySize];
    private readonly int[] enemyWeatheringTurns = new int[MaxEnemyPartySize];
    private readonly int[] enemySleepTurns = new int[MaxEnemyPartySize];
    private float currentPlayerTurnStrongestDamage;
    private int purificationStacks;
    private int defenseDownTurns;
    private bool stardustBodyActive;
    private bool didShowTutorialGuide;

    private void Awake()
    {
        // 싱글톤 패턴입니다.
        // 다른 스크립트에서 BattleManager.Instance로 전투 상태에 접근할 수 있게 합니다.
        if (Instance == null) Instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    private void Start()
    {
        // 전투 시작 시 플레이어 상태를 초기화하고 첫 번째 적을 소환합니다.
        // currentEnergy는 전투 시작 시 0으로 두고, 첫 플레이어 턴이 시작될 때 GainEnergy로 3을 받습니다.
        // CurrentTurnCount도 0에서 시작합니다. 실제 화면에는 StartPlayerTurn이 호출되면서 1턴으로 표시됩니다.
        ResetBattleRuntimeState();
        // startstory 씬에서 BattleScene으로 돌아온 경우,
        // StoryBattleFlow.BattleStageIndex에 저장된 번호의 적부터 이어서 시작합니다.
        // 아무 스토리 진행 없이 BattleScene을 직접 실행하면 기본값 0이라 첫 번째 적부터 시작합니다.
        enemyStageIndex = Mathf.Clamp(StoryBattleFlow.BattleStageIndex, 0, 4);
        enemyMemberIndex = 0;
        enemyMemberCount = GetEnemyCountForStage(enemyStageIndex);
        enemyKind = GetEnemyKindForStage(enemyStageIndex);

        if (UIManager.Instance != null)
        {
            UIManager.Instance.InitAllPools(MAX_ENERGY, MOON_GEM_COUNT);
        }

        SpawnEnemy(enemyKind);

        if (startBattleOnStart)
        {
            if (TurnManager.Instance == null)
            {
                new GameObject("TurnManager").AddComponent<TurnManager>();
            }

            TurnManager.Instance.BeginBattle();
        }
    }

    private void ResetBattleRuntimeState()
    {
        IsBattleEnded = false;
        currentEnergy = 0;
        currentPlayerHP = playerMaxHP;
        currentEnemyHP = 0f;
        currentShield = 0f;
        CurrentTurnCount = 0;
        moonGauge = 0f;
        capricornStack = 0;
        lastStrongestDamage = 0f;
        balanceBuffStacks = 0;
        balanceBuffTurns = 0;
        nextAttackMultiplier = 1f;
        aquariusUsedThisTurn = false;
        heavenlyPoisonStacks = 0;
        virgoDamageCapActive = false;
        virgoDamageCap = 5f;
        currentPlayerTurnStrongestDamage = 0f;
        pendingEnergyDrain = 0;
        starAdversaryCharge = 0;
        didShowTutorialGuide = false;
        ResetPurificationExecutionState();

        for (int i = 0; i < MaxEnemyPartySize; i++)
        {
            enemyCurrentHPs[i] = 0f;
            enemyMaxHPs[i] = 0f;
            enemyAliveStates[i] = false;
            enemyPoisonTurns[i] = 0;
            enemyPoisonDamages[i] = 0f;
            enemyWeatheringTurns[i] = 0;
            enemySleepTurns[i] = 0;
        }
    }

    private void Update()
    {
        HandleTargetSelectionInput();
    }

    private void HandleTargetSelectionInput()
    {
        if (IsBattleEnded || enemyMemberCount <= 1) return;
        if (TurnManager.Instance != null && !TurnManager.Instance.IsPlayerTurn) return;

        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A))
        {
            SelectAdjacentEnemyTarget(-1);
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D))
        {
            SelectAdjacentEnemyTarget(1);
        }
    }

    public void StartPlayerTurn()
    {
        // 플레이어 턴 시작 처리:
        // 턴성 버프/방어막을 정리하고, 매턴 기력 3을 회복합니다.
        // 이 게임에서는 "플레이어가 행동할 수 있는 차례"를 1턴으로 셉니다.
        // 그래서 적 턴이 아니라 플레이어 턴이 시작될 때 CurrentTurnCount가 1씩 증가합니다.
        CurrentTurnCount++;
        TickPlayerTurnStatus();
        currentPlayerTurnStrongestDamage = 0f;
        int energyPenalty = ConsumePendingEnergyDrain();
        GainEnergy(Mathf.Max(0, ENERGY_PER_TURN - energyPenalty));
        aquariusUsedThisTurn = false;
        ShowPlayerTurnGuide();
        if (energyPenalty > 0 && UIManager.Instance != null)
        {
            UIManager.Instance.ShowTurnNotice($"공허의 합창: 이번 턴 기력 -{energyPenalty}", 2f);
        }
    }

    public void StartEnemyTurn()
    {
        // 적 턴이 시작될 때 적에게 걸린 독 같은 지속 피해를 먼저 처리합니다.
        // 지속 효과는 실제 적 행동보다 먼저 들어갑니다.
        // 예: 별의 대적자 단계라면 매 적 턴 시작마다 플레이어에게 2 피해가 먼저 들어갑니다.
        ApplyEnemyPoison();
        ApplyEnemyWeathering();
        ApplyStarAdversaryAura();
    }

    private int ConsumePendingEnergyDrain()
    {
        int drain = Mathf.Max(0, pendingEnergyDrain);
        pendingEnergyDrain = 0;
        return drain;
    }

    public bool CanUseEnergy(int amount)
    {
        return !IsBattleEnded && currentEnergy >= amount;
    }

    public bool TryUseEnergy(int amount)
    {
        // 카드 사용 전에 기력이 충분한지 확인하고, 충분하면 바로 소모합니다.
        if (!CanUseEnergy(amount)) return false;

        UseEnergy(amount);
        return true;
    }

    // 카드를 써서 기력을 소모할 때 호출
    public void UseEnergy(int amount)
    {
        currentEnergy = Mathf.Max(0, currentEnergy - amount);
        UpdateAllUI();
    }

    // 카드 효과 등으로 기력을 얻을 때 호출하는 함수 (GainEnergy 추가!)
    public void GainEnergy(int amount)
    {
        int previousEnergy = currentEnergy;
        currentEnergy = Mathf.Min(MAX_ENERGY, currentEnergy + amount);
        int gainedEnergy = currentEnergy - previousEnergy;
        if (gainedEnergy > 0 && BattleVisualManager.Instance != null) BattleVisualManager.Instance.ShowEnergyGain(gainedEnergy);
        UpdateAllUI();
    }

    public void HealPlayer(float amount)
    {
        // 물고기자리 같은 회복 카드가 호출합니다.
        // 최대 체력을 넘지 않게 회복합니다.
        float previousHP = currentPlayerHP;
        currentPlayerHP = Mathf.Min(playerMaxHP, currentPlayerHP + amount);
        float healed = currentPlayerHP - previousHP;
        if (healed > 0f && BattleVisualManager.Instance != null) BattleVisualManager.Instance.ShowPlayerHeal(healed);
        UpdateAllUI();
        Debug.Log($"플레이어가 체력을 {amount:F0} 회복했습니다.");
    }

    public void AddShield(float amount, float maxHpRatio = 0f)
    {
        // 쌍둥이자리 같은 방어 카드가 호출합니다.
        // 고정 방어막 + 최대 체력 비율 방어막을 합산합니다.
        float shield = amount + playerMaxHP * maxHpRatio;
        currentShield = Mathf.Max(0f, currentShield + shield);
        if (shield > 0f && BattleVisualManager.Instance != null) BattleVisualManager.Instance.ShowPlayerShield(shield);
        UpdateAllUI();
        Debug.Log($"방어막 {shield:F0}을 얻었습니다. 현재 방어막: {currentShield:F0}");
    }

    public void ActivateVirgoVeil(float cap)
    {
        // 처녀자리 효과입니다.
        // 다음 적 턴 동안 단일 피해량을 cap 이하로 제한하고, 전갈 독 스택을 정화합니다.
        virgoDamageCapActive = true;
        virgoDamageCap = cap;
        heavenlyPoisonStacks = 0;
        Debug.Log($"처녀자리의 베일: 이번 적 턴 동안 단일 피해가 최대 {cap:F0}으로 고정되고 디버프가 정화됩니다.");
    }

    public void AddBalanceBuff(int stacks, int turns)
    {
        // 천칭자리 효과입니다.
        // 공격 피해 계산 시 중첩 수만큼 추가 피해를 줍니다.
        balanceBuffStacks = Mathf.Min(2, balanceBuffStacks + stacks);
        balanceBuffTurns = Mathf.Max(balanceBuffTurns, turns);
        Debug.Log($"천칭자리 버프 {balanceBuffStacks}중첩이 {balanceBuffTurns}턴 동안 유지됩니다.");
    }

    public void EmpowerNextAttack(float multiplier)
    {
        // 물고기자리 효과입니다.
        // 다음 공격 카드 1회에만 배율을 적용하고, 피해 계산 뒤 1로 돌아갑니다.
        nextAttackMultiplier = Mathf.Max(nextAttackMultiplier, multiplier);
        Debug.Log("물고기자리: 다음 공격 카드가 강화됩니다.");
    }

    public bool TryUseAquarius(int energyGain)
    {
        // 물병자리 효과입니다.
        // 한 턴에 1번만 기력 회복이 가능하도록 막습니다.
        if (aquariusUsedThisTurn) return false;

        aquariusUsedThisTurn = true;
        GainEnergy(energyGain);
        return true;
    }

    public void AddCapricornStack(int maxStacks)
    {
        capricornStack = Mathf.Min(maxStacks, capricornStack + 1);
    }

    public bool CanUseUltimate()
    {
        // 사수자리 필살기 생성/사용 조건입니다.
        return moonGauge >= MAX_MOON_GAUGE;
    }

    public void SpendMoonGauge()
    {
        moonGauge = 0f;
        UpdateAllUI();
    }

    // 달의 기운을 채울 때 호출
    public void GainMoonGauge(float amount, bool refreshUI = true)
    {
        moonGauge = Mathf.Min(MAX_MOON_GAUGE, moonGauge + amount);
        if (refreshUI)
        {
            UpdateAllUI();
        }
    }

    public void SelectEnemyTarget(int enemyIndex)
    {
        TrySelectEnemyTarget(enemyIndex, true);
    }

    public void DealDamageToEnemy(float damage)
    {
        // 카드 공격이 최종적으로 적에게 피해를 넣는 입구입니다.
        // 여기서 버프, 튜토리얼 피해 상한, 달의 기운 충전까지 함께 처리합니다.
        if (IsBattleEnded) return;

        int targetIndex = GetCurrentTargetIndex();
        if (targetIndex < 0) return;

        float finalDamage = CalculatePlayerDamage(damage);

        if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.PlayPlayerAttack(targetIndex);
        enemyCurrentHPs[targetIndex] = Mathf.Max(0f, enemyCurrentHPs[targetIndex] - finalDamage);
        if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.ShowEnemyDamage(finalDamage, targetIndex);
        GainMoonGauge(finalDamage * 0.6f, false);
        Debug.Log($"적에게 {finalDamage:F0}의 피해를 입혔습니다.");

        if (enemyCurrentHPs[targetIndex] <= 0f)
        {
            MarkEnemyDefeated(targetIndex);
            ResolveEnemyPartyAfterDamage();
            return;
        }

        SyncCurrentEnemySnapshot();
        UpdateAllUI();
    }

    public void DealDamageToAllEnemies(float damage)
    {
        if (IsBattleEnded) return;

        float finalDamage = CalculatePlayerDamage(damage);
        float totalDamage = 0f;
        bool defeatedAnyEnemy = false;

        for (int i = 0; i < enemyMemberCount; i++)
        {
            if (!enemyAliveStates[i]) continue;

            if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.PlayPlayerAttack(i);
            enemyCurrentHPs[i] = Mathf.Max(0f, enemyCurrentHPs[i] - finalDamage);
            totalDamage += finalDamage;
            if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.ShowEnemyDamage(finalDamage, i);

            if (enemyCurrentHPs[i] <= 0f)
            {
                MarkEnemyDefeated(i);
                defeatedAnyEnemy = true;
            }
        }

        if (totalDamage <= 0f) return;

        GainMoonGauge(totalDamage * 0.6f, false);
        Debug.Log($"모든 적에게 {finalDamage:F0}의 피해를 입혔습니다.");

        if (defeatedAnyEnemy)
        {
            ResolveEnemyPartyAfterDamage();
            return;
        }

        SyncCurrentEnemySnapshot();
        UpdateAllUI();
    }
    public void EnemyAction()
    {
        // 적 턴의 실제 행동입니다.
        // 현재 enemyKind에 따라 공격 패턴이 달라집니다.
        // Random.value는 0 이상 1 미만의 랜덤 값입니다.
        // specialAttackChance가 0.38이면 38% 확률로 특수 공격을 선택합니다.
        if (IsBattleEnded) return;

        bool didDiscardCard = false;
        bool didApplyPurification = false;
        bool didUsePackHowl = false;
        int aliveCount = GetAliveEnemyCount();

        for (int i = 0; i < enemyMemberCount; i++)
        {
            if (!enemyAliveStates[i] || currentPlayerHP <= 0f) continue;

            enemyMemberIndex = i;
            if (BattleVisualManager.Instance != null)
            {
                BattleVisualManager.Instance.SetActiveEnemyIndex(i);
            }

            if (ConsumeEnemySleepTurn(i)) continue;

            EnemyActionForMember(i, aliveCount, ref didDiscardCard, ref didApplyPurification, ref didUsePackHowl);
        }

        RestoreSelectedEnemyTarget();
        SyncCurrentEnemySnapshot();
        UpdateAllUI();

        if (currentPlayerHP <= 0f)
        {
            EndBattle(false);
        }
    }

    private bool ConsumeEnemySleepTurn(int enemyIndex)
    {
        if (enemyIndex < 0 || enemyIndex >= MaxEnemyPartySize) return false;
        if (enemySleepTurns[enemyIndex] <= 0) return false;

        enemySleepTurns[enemyIndex]--;
        string message = $"{GetEnemyDisplayName(enemyKind)} {enemyIndex + 1} 수면: 행동 불가";
        Debug.Log(message);
        if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice(message, 1.8f);
        return true;
    }

    private void EnemyActionForMember(int enemyIndex, int aliveCount, ref bool didDiscardCard, ref bool didApplyPurification, ref bool didUsePackHowl)
    {
        switch (enemyKind)
        {
            case EnemyKind.VoidHowler:
                if (!didUsePackHowl && aliveCount >= 2 && Random.value < voidHowlerPackHowlChance)
                {
                    didUsePackHowl = true;
                    ApplyVoidHowlerPackHowl(aliveCount);
                }

                EnemyAttack(enemyIndex, "공허의 울음꾼이 물어뜯습니다.", GetGroupScaledAttackDamage(enemyAttackDamage, aliveCount));
                if (!didDiscardCard && CardManmager.Instance != null && Random.value < enemyBalance.handDiscardChance)
                {
                    didDiscardCard = true;
                    CardManmager.Instance.DiscardRandomCard();
                    string howlMessage = "공허의 울음꾼이 웁니다 (카드를 놓습니다)";
                    Debug.Log(howlMessage);
                    if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice(howlMessage);
                }

                break;
            
            case EnemyKind.StarDustExecutor:
                UsePurificationExecution(enemyIndex, aliveCount, ref didApplyPurification);
                break;
            case EnemyKind.FallenScorpio:
                if (Random.value < specialAttackChance)
                {
                    UseScorpioHeavenlyPoison(enemyIndex);
                }
                else
                {
                    EnemyAttack(enemyIndex, "타락한 전갈이 독침으로 찌릅니다.", Random.Range(enemyAttackDamage * 0.85f, enemyAttackDamage * 1.15f));
                }
                break;
            case EnemyKind.StarAdversary:
                if (ShouldUseStarAdversaryMeteor())
                {
                    UseStarClusterMeteorShower();
                }
                else
                {
                    ChargeStarAdversaryCore(enemyIndex);
                }
                break;
        }
    }

    private void UsePurificationExecution(int enemyIndex, int aliveCount, ref bool didApplyPurification)
    {
        // 탁한 별가루 집행자 전용 스킬입니다.
        // 정화 창으로 피해를 주고, 정화 스택과 방어력 감소를 같이 부여합니다.
        EnemyAttack(enemyIndex, "탁한 별가루 집행자가 정화의 창으로 찌릅니다.", GetGroupScaledAttackDamage(enemyAttackDamage, aliveCount));

        if (didApplyPurification) return;

        didApplyPurification = true;
        AddPurificationStack();
        ApplyDefenseDown();
    }

    private void AddPurificationStack()
    {
        purificationStacks = Mathf.Min(purificationMaxStacks, purificationStacks + 1);

        if (UIManager.Instance != null)
        {
            UIManager.Instance.ShowTurnNotice($"정화 스택 {purificationStacks}/{purificationMaxStacks}");
        }

        if (purificationStacks >= purificationMaxStacks && !stardustBodyActive)
        {
            stardustBodyActive = true;
            Debug.Log("정화 스택 5중첩: 플레이어가 별가루화되었습니다.");

            if (UIManager.Instance != null)
            {
                UIManager.Instance.ShowTurnNotice("몸이 별가루화되었습니다!");
            }
        }
    }

    private void ApplyDefenseDown()
    {
        defenseDownTurns = Mathf.Max(defenseDownTurns, defenseDownTurnsOnHit);
        Debug.Log($"방어력 감소 {defenseDownTurns}턴");
    }

    private void ApplyVoidHowlerPackHowl(int aliveCount)
    {
        int drain = Mathf.Max(1, voidHowlerPackEnergyDrain);

        pendingEnergyDrain = Mathf.Max(pendingEnergyDrain, drain);
        string message = $"공허의 합창! 다음 턴 기력 -{drain}";
        Debug.Log(message);
        if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice(message, 2f);
    }

    public void ApplyPoisonToEnemy(float damage, int turns)
    {
        // 전갈자리 카드가 호출합니다.
        // 이미 걸린 독보다 강하거나 오래가면 그 값을 유지합니다.
        int targetIndex = GetCurrentTargetIndex();
        if (targetIndex < 0) return;

        enemyPoisonDamages[targetIndex] = Mathf.Max(enemyPoisonDamages[targetIndex], damage);
        enemyPoisonTurns[targetIndex] = Mathf.Max(enemyPoisonTurns[targetIndex], turns);
        Debug.Log($"적 {targetIndex + 1}에게 독을 부여했습니다. {enemyPoisonTurns[targetIndex]}턴 동안 {enemyPoisonDamages[targetIndex]:F0} 피해");
    }

    public void ApplyWeatheringToEnemy(int turns)
    {
        // 사수자리 풍화: 적을 약화시키고 적 턴 시작마다 바람 피해 1을 줍니다.
        int targetIndex = GetCurrentTargetIndex();
        if (targetIndex < 0) return;

        enemyWeatheringTurns[targetIndex] = Mathf.Max(enemyWeatheringTurns[targetIndex], turns);
        if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.PlayWeatheringTick(targetIndex);
        Debug.Log($"적 {targetIndex + 1}에게 풍화를 부여했습니다. {enemyWeatheringTurns[targetIndex]}턴 동안 공격 약화와 바람 피해가 적용됩니다.");
        if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice($"풍화 {enemyWeatheringTurns[targetIndex]}턴!");
    }

    public void ApplyWeatheringToAllEnemies(int turns)
    {
        int safeTurns = Mathf.Max(1, turns);
        bool appliedAny = false;

        for (int i = 0; i < enemyMemberCount; i++)
        {
            if (!enemyAliveStates[i]) continue;

            enemyWeatheringTurns[i] = Mathf.Max(enemyWeatheringTurns[i], safeTurns);
            appliedAny = true;
            if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.PlayWeatheringTick(i);
        }

        if (!appliedAny) return;

        Debug.Log($"모든 적에게 풍화 {safeTurns}턴을 부여했습니다.");
        if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice($"전체 풍화 {safeTurns}턴!");
    }

    public void ApplySleepToEnemy(int turns)
    {
        int targetIndex = GetCurrentTargetIndex();
        if (targetIndex < 0) return;

        int safeTurns = Mathf.Max(1, turns);
        enemySleepTurns[targetIndex] = Mathf.Max(enemySleepTurns[targetIndex], safeTurns);
        Debug.Log($"적 {targetIndex + 1}이 {enemySleepTurns[targetIndex]}턴 동안 수면 상태가 되었습니다.");
        if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice($"수면 {enemySleepTurns[targetIndex]}턴!");
    }

    public void ApplySleepToAllEnemies(int turns)
    {
        int safeTurns = Mathf.Max(1, turns);
        bool appliedAny = false;

        for (int i = 0; i < enemyMemberCount; i++)
        {
            if (!enemyAliveStates[i]) continue;

            enemySleepTurns[i] = Mathf.Max(enemySleepTurns[i], safeTurns);
            appliedAny = true;
        }

        if (!appliedAny) return;

        Debug.Log($"모든 적이 {safeTurns}턴 동안 수면 상태가 되었습니다.");
        if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice($"전체 수면 {safeTurns}턴!");
    }

    public void CommitPlayerTurnDamageRecord()
    {
        // 사자자리가 참조할 수 있도록 방금 끝난 플레이어 턴의 최고 피해만 저장합니다.
        lastStrongestDamage = currentPlayerTurnStrongestDamage;
        currentPlayerTurnStrongestDamage = 0f;
    }

    public void EndBattle(bool isWin)
    {
        if (IsBattleEnded) return;

        IsBattleEnded = true;
        if (!isWin && BattleVisualManager.Instance != null)
        {
            BattleVisualManager.Instance.PlayPlayerDefeat();
        }

        if (UIManager.Instance != null) UIManager.Instance.ShowGameOver(isWin, enemyKind);
    }

    public void RestartCurrentBattleFromGameOver()
    {
        int retryStageIndex = Mathf.Clamp(enemyStageIndex, 0, 4);
        StoryBattleFlow.BattleStageIndex = retryStageIndex;

        if (TurnManager.Instance != null)
        {
            TurnManager.Instance.ResetTurnFlow();
        }

        if (CardManmager.Instance != null)
        {
            CardManmager.Instance.ClearHand();
        }

        if (UIManager.Instance != null)
        {
            UIManager.Instance.HideGameOver();
            UIManager.Instance.InitAllPools(MAX_ENERGY, MOON_GEM_COUNT);
        }

        if (BattleVisualManager.Instance != null)
        {
            BattleVisualManager.Instance.ResetPlayerVisualState();
        }

        ResetBattleRuntimeState();
        enemyStageIndex = retryStageIndex;
        enemyMemberIndex = 0;
        enemyMemberCount = GetEnemyCountForStage(enemyStageIndex);
        enemyKind = GetEnemyKindForStage(enemyStageIndex);

        SpawnEnemy(enemyKind);

        if (TurnManager.Instance != null)
        {
            TurnManager.Instance.BeginBattle();
        }
    }

    // 모든 구슬 상태를 UI에 동기화
    private void UpdateAllUI()
    {
        if (UIManager.Instance != null)
        {
            UIManager.Instance.UpdateEnergyUI(currentEnergy);
            UIManager.Instance.UpdateMoonGaugeUI(moonGauge, MAX_MOON_GAUGE);
            UIManager.Instance.UpdateTurnCountUI(CurrentTurnCount);
            UIManager.Instance.UpdateEnemyPartyHP(enemyCurrentHPs, enemyMaxHPs, enemyAliveStates, enemyMemberIndex);
            UIManager.Instance.UpdatePlayerHP(currentPlayerHP, playerMaxHP, currentShield);
        }
    }

    private float CalculatePlayerDamage(float damage)
    {
        // 플레이어가 주는 피해를 최종 계산합니다.
        // 천칭 버프, 물고기 강화, 튜토리얼 적 피해 상한이 여기서 적용됩니다.
        float finalDamage = damage;

        if (balanceBuffStacks > 0)
        {
            finalDamage += balanceBuffStacks * 5f;
        }

        finalDamage *= nextAttackMultiplier;
        nextAttackMultiplier = 1f;

        if (enemyBalance.damageCap > 0f)
        {
            finalDamage = Mathf.Min(finalDamage, enemyBalance.damageCap);
        }

        finalDamage = ApplyEnemyDefensiveGimmick(finalDamage);
        currentPlayerTurnStrongestDamage = Mathf.Max(currentPlayerTurnStrongestDamage, finalDamage);
        return finalDamage;
    }

    private float ApplyEnemyDefensiveGimmick(float damage)
    {
        if (enemyKind != EnemyKind.StarDustExecutor) return damage;

        int aliveCount = GetAliveEnemyCount();
        if (aliveCount <= 1) return damage;

        float reduction = Mathf.Clamp01(starDustFormationDamageReductionPerAlly * (aliveCount - 1));
        float reducedDamage = damage * (1f - reduction);
        Debug.Log($"정화 방진: 집행자 {aliveCount}마리가 피해를 {reduction * 100f:F0}% 줄였습니다.");
        return reducedDamage;
    }

    private void EnemyAttack(string message, float damage)
    {
        EnemyAttack(enemyMemberIndex, message, damage);
    }

    private void EnemyAttack(int enemyIndex, string message, float damage)
    {
        if (enemyIndex < 0 || enemyIndex >= MaxEnemyPartySize) return;

        Debug.Log(message);
        if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.PlayEnemyAttack(enemyIndex);
        float finalDamage = enemyWeatheringTurns[enemyIndex] > 0 ? damage * weatheringEnemyAttackMultiplier : damage;
        TakePlayerDamage(finalDamage);
    }

    private void UseScorpioHeavenlyPoison(int enemyIndex)
    {
        heavenlyPoisonStacks++;
        EnemyAttack(enemyIndex, $"타락한 전갈의 천무독 {heavenlyPoisonStacks}스택.", Random.Range(enemyAttackDamage * 0.85f, enemyAttackDamage * 1.15f));

        float poisonDamage = playerMaxHP * Mathf.Clamp01(heavenlyPoisonMaxHpRatio);
        TakePlayerDirectDamage(poisonDamage, "천무독");

        int executionStacks = Mathf.Max(3, enemyBalance.scorpioInstantStack);
        if (UIManager.Instance != null)
        {
            UIManager.Instance.ShowTurnNotice($"천무독 {heavenlyPoisonStacks}/{executionStacks} - 최대체력 {heavenlyPoisonMaxHpRatio * 100f:F0}%", 2.4f);
        }

        if (heavenlyPoisonStacks >= executionStacks)
        {
            ExecuteHeavenlyPoison();
        }
    }

    private void UseStarClusterMeteorShower()
    {
        // 별무리 유성우는 4단 히트입니다.
        // 각 타격이 최종 보스 공격력에 비례해서 방어막/처녀자리 대응이 중요해집니다.
        starAdversaryCharge = 0;
        if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice("별무리 유성우!");
        if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.PlayMeteorShower();
        float meteorHitDamage = enemyAttackDamage * 0.78f;
        EnemyAttack("별의 대적자가 별무리 유성우를 부릅니다.", meteorHitDamage);
        EnemyAttack("별무리 유성우가 두 번째로 떨어집니다.", meteorHitDamage);
        EnemyAttack("별무리 유성우가 세 번째로 떨어집니다.", meteorHitDamage);
        EnemyAttack("별무리 유성우가 마지막으로 떨어집니다.", meteorHitDamage);
    }

    private bool ShouldUseStarAdversaryMeteor()
    {
        if (starAdversaryCharge >= Mathf.Max(1, starAdversaryMeteorChargeMax)) return true;
        return Random.value < specialAttackChance && starAdversaryCharge >= 1;
    }

    private void ChargeStarAdversaryCore(int enemyIndex)
    {
        starAdversaryCharge++;
        int maxCharge = Mathf.Max(1, starAdversaryMeteorChargeMax);
        EnemyAttack(enemyIndex, $"별의 대적자가 별핵을 충전합니다. {starAdversaryCharge}/{maxCharge}", Random.Range(enemyAttackDamage * 0.85f, enemyAttackDamage * 1.15f));

        if (UIManager.Instance != null)
        {
            UIManager.Instance.ShowTurnNotice($"별핵 충전 {starAdversaryCharge}/{maxCharge}", 2f);
        }
    }

    private void TakePlayerDamage(float damage)
    {
        // 플레이어가 피해를 받는 공통 함수입니다.
        // 처녀자리 피해 제한과 방어막 흡수를 여기서 처리합니다.
        float finalDamage = damage;
        if (defenseDownTurns > 0)
        {
            finalDamage *= defenseDownDamageMultiplier;
        }

        if (virgoDamageCapActive)
        {
            finalDamage = Mathf.Min(finalDamage, virgoDamageCap);
        }

        float absorbed = Mathf.Min(currentShield, finalDamage);
        currentShield -= absorbed;
        finalDamage -= absorbed;
        currentPlayerHP = Mathf.Max(0f, currentPlayerHP - finalDamage);
        if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.ShowPlayerDamage(finalDamage);
        if (finalDamage > 0f && stardustBodyActive && currentPlayerHP > 0f)
        {
            TriggerStardustExplosion();
        }

        UpdateAllUI();
        Debug.Log($"플레이어가 {finalDamage:F0}의 피해를 받았습니다. 방어막 흡수: {absorbed:F0}");

        if (currentPlayerHP <= 0f)
        {
            EndBattle(false);
        }
    }

    private void TakePlayerDirectDamage(float damage, string source)
    {
        float finalDamage = Mathf.Max(0f, damage);
        currentPlayerHP = Mathf.Max(0f, currentPlayerHP - finalDamage);

        if (BattleVisualManager.Instance != null)
        {
            BattleVisualManager.Instance.ShowPlayerDamage(finalDamage);
        }

        UpdateAllUI();
        Debug.Log($"{source}: 플레이어가 최대체력 기준 피해 {finalDamage:F0}을 받았습니다.");

        if (currentPlayerHP <= 0f)
        {
            EndBattle(false);
        }
    }

    private void ExecuteHeavenlyPoison()
    {
        if (IsBattleEnded) return;

        currentPlayerHP = 0f;
        UpdateAllUI();
        if (UIManager.Instance != null)
        {
            UIManager.Instance.ShowTurnNotice("천무독이 완성되었습니다.", 2.5f);
        }

        Debug.Log("천무독 완성: 플레이어가 즉사했습니다.");
        EndBattle(false);
    }

    private void TriggerStardustExplosion()
    {
        // 별가루화 상태에서 피해를 받으면 추가 폭발 피해가 한 번 발생합니다.
        stardustBodyActive = false;
        purificationStacks = 0;

        currentPlayerHP = Mathf.Max(0f, currentPlayerHP - stardustExplosionDamage);

        if (BattleVisualManager.Instance != null)
        {
            BattleVisualManager.Instance.ShowPlayerDamage(stardustExplosionDamage);
        }

        if (UIManager.Instance != null)
        {
            UIManager.Instance.ShowTurnNotice("별가루 폭발!");
        }

        UpdateAllUI();
        Debug.Log($"별가루 폭발 피해 {stardustExplosionDamage:F0}");

        if (currentPlayerHP <= 0f)
        {
            EndBattle(false);
        }
    }

    private void ApplyEnemyPoison()
    {
        // 적 턴 시작 때 독 피해를 적용합니다.
        if (IsBattleEnded) return;

        bool didApplyDamage = false;
        for (int i = 0; i < enemyMemberCount; i++)
        {
            if (!enemyAliveStates[i] || enemyPoisonTurns[i] <= 0) continue;

            enemyPoisonTurns[i]--;
            enemyCurrentHPs[i] = Mathf.Max(0f, enemyCurrentHPs[i] - enemyPoisonDamages[i]);
            didApplyDamage = true;
            if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.ShowEnemyDamage(enemyPoisonDamages[i], i);
            Debug.Log($"적 {i + 1} 독 피해 {enemyPoisonDamages[i]:F0}. 남은 독 턴: {enemyPoisonTurns[i]}");

            if (enemyCurrentHPs[i] <= 0f)
            {
                MarkEnemyDefeated(i);
            }
        }

        if (!didApplyDamage) return;

        ResolveEnemyPartyAfterDamage();
    }

    private void ApplyEnemyWeathering()
    {
        if (IsBattleEnded) return;

        bool didApplyDamage = false;
        for (int i = 0; i < enemyMemberCount; i++)
        {
            if (!enemyAliveStates[i] || enemyWeatheringTurns[i] <= 0) continue;

            enemyWeatheringTurns[i]--;
            enemyCurrentHPs[i] = Mathf.Max(0f, enemyCurrentHPs[i] - weatheringDamage);
            didApplyDamage = true;
            if (BattleVisualManager.Instance != null)
            {
                BattleVisualManager.Instance.PlayWeatheringTick(i);
                BattleVisualManager.Instance.ShowEnemyDamage(weatheringDamage, i);
            }
            Debug.Log($"적 {i + 1} 풍화 피해 {weatheringDamage:F0}. 남은 풍화 턴: {enemyWeatheringTurns[i]}");

            if (enemyCurrentHPs[i] <= 0f)
            {
                MarkEnemyDefeated(i);
            }
        }

        if (!didApplyDamage) return;

        ResolveEnemyPartyAfterDamage();
    }

    private void ApplyStarAdversaryAura()
    {
        if (enemyKind != EnemyKind.StarAdversary || IsBattleEnded) return;

        if (BattleVisualManager.Instance != null) BattleVisualManager.Instance.PlayEnemyAttack();
        TakePlayerDamage(starAdversaryAuraDamage);
        Debug.Log($"별의 대적자의 별가루 지속 피해 {starAdversaryAuraDamage:F0}");

        if (currentPlayerHP <= 0f)
        {
            EndBattle(false);
        }
    }

    private void TickPlayerTurnStatus()
    {
        // 플레이어 턴 시작마다 1턴짜리 방어 효과를 정리합니다.
        // 버프 턴 수도 여기서 줄어듭니다.
        virgoDamageCapActive = false;
        currentShield = 0f;

        if (balanceBuffTurns > 0)
        {
            balanceBuffTurns--;
            if (balanceBuffTurns <= 0)
            {
                balanceBuffStacks = 0;
            }
        }

        if (defenseDownTurns > 0)
        {
            defenseDownTurns--;
        }
    }

    private void ApplyEnemyBalance()
    {
        // enemyKind에 맞는 밸런스 값을 실제 전투 변수에 반영합니다.
        enemyBalance = GetEnemyBalance(enemyKind);
        enemyMaxHP = enemyBalance.maxHP;
        enemyAttackDamage = enemyBalance.baseAttack;
        tutorialEnemyDamageCap = enemyBalance.damageCap;
    }

    private void SpawnEnemy(EnemyKind kind)
    {
        // 새 적을 등장시키는 함수입니다.
        // HP, 독, 전갈 스택 등을 새 전투 구간에 맞게 초기화합니다.
        StoryBattleFlow.BattleStageIndex = Mathf.Clamp(enemyStageIndex, 0, 4);
        enemyKind = kind;
        ApplyEnemyBalance();
        enemyMemberCount = Mathf.Clamp(GetEnemyCountForStage(enemyStageIndex), 1, MaxEnemyPartySize);
        enemyMemberIndex = 0;
        selectedEnemyIndex = 0;
        heavenlyPoisonStacks = 0;
        pendingEnergyDrain = 0;
        starAdversaryCharge = 0;
        ResetPurificationExecutionState();

        for (int i = 0; i < MaxEnemyPartySize; i++)
        {
            bool isActiveMember = i < enemyMemberCount;
            enemyMaxHPs[i] = isActiveMember ? enemyMaxHP : 0f;
            enemyCurrentHPs[i] = isActiveMember ? enemyMaxHP : 0f;
            enemyAliveStates[i] = isActiveMember;
            enemyPoisonTurns[i] = 0;
            enemyPoisonDamages[i] = 0f;
            enemyWeatheringTurns[i] = 0;
            enemySleepTurns[i] = 0;
        }

        SyncCurrentEnemySnapshot();
        UpdateAllUI();

        if (UIManager.Instance != null)
        {
            string countText = enemyMemberCount > 1 ? $" {enemyMemberCount}마리" : "";
            UIManager.Instance.ShowTurnNotice(GetEnemyDisplayName(kind) + countText + " 등장!");
            ShowEnemyGimmickNotice(kind);
        }

        if (BattleVisualManager.Instance != null)
        {
            BattleVisualManager.Instance.SetEnemyPartyVisuals(kind, enemyMemberCount, GetEnemyDisplayName(kind));
        }

        GlobalBgmManager.SetBossBattleActive(kind == EnemyKind.FallenScorpio || kind == EnemyKind.StarAdversary);
    }

    private void ResetPurificationExecutionState()
    {
        purificationStacks = 0;
        defenseDownTurns = 0;
        stardustBodyActive = false;
    }

    private void ShowEnemyGimmickNotice(EnemyKind kind)
    {
        if (UIManager.Instance == null) return;

        switch (kind)
        {
            case EnemyKind.VoidHowler:
                if (enemyMemberCount > 1)
                {
                    UIManager.Instance.ShowTurnNotice("기믹: 무리의 합창이 다음 턴 기력을 깎습니다.", 3f);
                }
                break;
            case EnemyKind.StarDustExecutor:
                UIManager.Instance.ShowTurnNotice("기믹: 정화 방진으로 살아있는 집행자 수만큼 피해를 줄입니다.", 3f);
                break;
            case EnemyKind.FallenScorpio:
                UIManager.Instance.ShowTurnNotice($"기믹: 천무독은 최대체력 {heavenlyPoisonMaxHpRatio * 100f:F0}% 피해, {Mathf.Max(3, scorpioInstantPoisonStack)}스택이면 즉사합니다.", 3f);
                break;
            case EnemyKind.StarAdversary:
                UIManager.Instance.ShowTurnNotice("기믹: 별핵이 충전되면 별무리 유성우가 떨어집니다.", 3f);
                break;
        }
    }

    private void AdvanceEnemyStageOrWin()
    {
        // 적이 죽었을 때의 진행 처리입니다.
        // 한 스테이지 안에서는 최대 3마리를 동시에 상대합니다.
        // 화면의 적을 모두 쓰러뜨린 뒤에만 startstory 씬으로 이동해서 중간 스토리를 보여줍니다.

        int defeatedStageIndex = enemyStageIndex;
        enemyStageIndex++;

        if (enemyStageIndex >= 5)
        {
            IsBattleEnded = true;
            StoryBattleFlow.LoadFinalStory();
            return;
        }

        if (defeatedStageIndex == 0)
        {
            // 튜토리얼 직후에는 빈 스토리 씬을 거치지 않고,
            // 현재 전투 화면에서 바로 공허의 울음꾼 3마리 전투를 시작합니다.
            enemyMemberIndex = 0;
            enemyMemberCount = GetEnemyCountForStage(enemyStageIndex);
            SpawnEnemy(GetEnemyKindForStage(enemyStageIndex));
            return;
        }

        IsBattleEnded = true;
        StoryBattleFlow.LoadStoryAfterDefeatingStage(defeatedStageIndex);
    }

    private void MarkEnemyDefeated(int enemyIndex)
    {
        if (enemyIndex < 0 || enemyIndex >= enemyMemberCount) return;
        if (!enemyAliveStates[enemyIndex]) return;

        enemyAliveStates[enemyIndex] = false;
        enemyCurrentHPs[enemyIndex] = 0f;
        enemyPoisonTurns[enemyIndex] = 0;
        enemyPoisonDamages[enemyIndex] = 0f;
        enemyWeatheringTurns[enemyIndex] = 0;
        enemySleepTurns[enemyIndex] = 0;
        if (selectedEnemyIndex == enemyIndex)
        {
            selectedEnemyIndex = -1;
        }

        if (BattleVisualManager.Instance != null)
        {
            BattleVisualManager.Instance.SetEnemyAlive(enemyIndex, false);
        }

        if (UIManager.Instance != null && GetAliveEnemyCount() > 0)
        {
            UIManager.Instance.ShowTurnNotice($"{GetEnemyDisplayName(enemyKind)} {enemyIndex + 1} 정화!");
        }
    }

    private void ResolveEnemyPartyAfterDamage()
    {
        if (IsBattleEnded) return;

        if (GetAliveEnemyCount() <= 0)
        {
            AdvanceEnemyStageOrWin();
            return;
        }

        SelectNextLivingEnemy();
        SyncCurrentEnemySnapshot();
        UpdateAllUI();
    }

    private int GetCurrentTargetIndex()
    {
        if (selectedEnemyIndex >= 0 && selectedEnemyIndex < enemyMemberCount && enemyAliveStates[selectedEnemyIndex])
        {
            return selectedEnemyIndex;
        }

        if (enemyMemberIndex >= 0 && enemyMemberIndex < enemyMemberCount && enemyAliveStates[enemyMemberIndex])
        {
            selectedEnemyIndex = enemyMemberIndex;
            return enemyMemberIndex;
        }

        SelectNextLivingEnemy();
        if (selectedEnemyIndex >= 0 && selectedEnemyIndex < enemyMemberCount && enemyAliveStates[selectedEnemyIndex])
        {
            return selectedEnemyIndex;
        }

        return -1;
    }

    private void SelectAdjacentEnemyTarget(int direction)
    {
        if (enemyMemberCount <= 0) return;

        int startIndex = GetCurrentTargetIndex();
        if (startIndex < 0) startIndex = 0;

        int step = direction >= 0 ? 1 : -1;
        for (int offset = 1; offset <= enemyMemberCount; offset++)
        {
            int candidate = (startIndex + step * offset + enemyMemberCount) % enemyMemberCount;
            if (!enemyAliveStates[candidate]) continue;

            TrySelectEnemyTarget(candidate, true);
            return;
        }
    }

    private bool TrySelectEnemyTarget(int enemyIndex, bool showNotice)
    {
        if (IsBattleEnded) return false;
        if (enemyIndex < 0 || enemyIndex >= enemyMemberCount) return false;
        if (!enemyAliveStates[enemyIndex]) return false;

        selectedEnemyIndex = enemyIndex;
        enemyMemberIndex = enemyIndex;

        if (BattleVisualManager.Instance != null)
        {
            BattleVisualManager.Instance.SetActiveEnemyIndex(enemyIndex);
        }

        SyncCurrentEnemySnapshot();
        UpdateAllUI();

        if (showNotice && UIManager.Instance != null)
        {
            string memberText = enemyMemberCount > 1 ? $" {enemyIndex + 1}/{enemyMemberCount}" : "";
            UIManager.Instance.ShowTurnNotice($"타겟: {GetEnemyDisplayName(enemyKind)}{memberText}", 1.1f);
        }

        return true;
    }

    private void RestoreSelectedEnemyTarget()
    {
        if (selectedEnemyIndex >= 0 && selectedEnemyIndex < enemyMemberCount && enemyAliveStates[selectedEnemyIndex])
        {
            enemyMemberIndex = selectedEnemyIndex;
            if (BattleVisualManager.Instance != null)
            {
                BattleVisualManager.Instance.SetActiveEnemyIndex(selectedEnemyIndex);
            }
            return;
        }

        SelectNextLivingEnemy();
    }

    private void SelectNextLivingEnemy()
    {
        for (int i = 0; i < enemyMemberCount; i++)
        {
            if (!enemyAliveStates[i]) continue;

            selectedEnemyIndex = i;
            enemyMemberIndex = i;
            if (BattleVisualManager.Instance != null)
            {
                BattleVisualManager.Instance.SetActiveEnemyIndex(i);
            }
            return;
        }

        selectedEnemyIndex = -1;
        enemyMemberIndex = -1;
    }

    private int GetAliveEnemyCount()
    {
        int count = 0;
        for (int i = 0; i < enemyMemberCount; i++)
        {
            if (enemyAliveStates[i]) count++;
        }

        return count;
    }

    private void SyncCurrentEnemySnapshot()
    {
        int targetIndex = GetCurrentTargetIndex();
        if (targetIndex < 0)
        {
            currentEnemyHP = 0f;
            enemyMaxHP = enemyBalance.maxHP;
            return;
        }

        currentEnemyHP = enemyCurrentHPs[targetIndex];
        enemyMaxHP = enemyMaxHPs[targetIndex];
    }

    private float GetGroupScaledAttackDamage(float damage, int aliveCount)
    {
        if (enemyMemberCount <= 1 || aliveCount <= 1) return damage;
        return damage * Mathf.Clamp(multiEnemyAttackMultiplier, 0.2f, 1f);
    }

    private int GetEnemyCountForStage(int stageIndex)
    {
        // 0번 스테이지는 스토리 직후 바로 들어가는 튜토리얼 전투입니다.
        // 사용자가 요청한 대로 여기서는 공허의 울음꾼 1마리만 상대합니다.
        // 1번 스테이지는 튜토리얼 이후 공허의 울음꾼 3마리 전투입니다.
        // 2번 스테이지는 병사 역할인 탁한 별가루 집행자 3마리 전투입니다.
        // 전갈자리와 별의 대적자는 보스라서 1마리씩만 상대합니다.
        if (stageIndex == 0) return 1;
        if (stageIndex == 1) return 3;
        if (stageIndex == 2) return 3;

        return 1;
    }

    private void ShowPlayerTurnGuide()
    {
        // 첫 전투의 첫 턴에만 조작법을 알려주는 튜토리얼 안내입니다.
        // 스토리 진행 후 BattleScene에 들어오면 BattleManager.Start -> TurnManager.BeginBattle -> StartPlayerTurn 순서로 호출되고,
        // 이 함수가 처음 한 번만 긴 설명을 띄웁니다.
        if (UIManager.Instance == null) return;

        bool isFirstTutorialTurn = enemyStageIndex == 0 && enemyMemberIndex == 0 && CurrentTurnCount == 1;
        if (isFirstTutorialTurn && !didShowTutorialGuide)
        {
            didShowTutorialGuide = true;
            UIManager.Instance.ShowBattleTutorialSequence();
            return;
        }

        UIManager.Instance.ShowTurnNotice("플레이어 턴!");
    }

    private EnemyKind GetEnemyKindForStage(int stageIndex)
    {
        switch (stageIndex)
        {
            case 0:
                return EnemyKind.VoidHowler;
            case 1:
                return EnemyKind.VoidHowler;
            case 2:
                return EnemyKind.StarDustExecutor;
            case 3:
                return EnemyKind.FallenScorpio;
            default:
                return EnemyKind.StarAdversary;
        }
    }

    private string GetEnemyDisplayName(EnemyKind kind)
    {
        switch (kind)
        {
            case EnemyKind.VoidHowler:
                return "공허의 울음꾼";
            case EnemyKind.StarDustExecutor:
                return "탁한 별가루 집행자";
            case EnemyKind.FallenScorpio:
                return "타락한 황도13궁 전갈";
            case EnemyKind.StarAdversary:
                return "별의 대적자";
            default:
                return "적";
        }
    }

    public string GetCurrentEnemyGuideText()
    {
        int aliveCount = GetAliveEnemyCount();
        string statusText = enemyMemberCount > 1
            ? $"현재 수: {aliveCount}/{enemyMemberCount}\n현재 대상 HP: {currentEnemyHP:F0} / {enemyMaxHP:F0}\n"
            : $"HP: {currentEnemyHP:F0} / {enemyMaxHP:F0}\n";

        return $"{GetEnemyDisplayName(enemyKind)}\n{statusText}\n{GetEnemyLoreText(enemyKind)}\n\n위협\n{GetEnemyGimmickText(enemyKind)}\n\n성좌 대응\n{GetEnemyCounterText(enemyKind)}";
    }

    private string GetEnemyLoreText(EnemyKind kind)
    {
        switch (kind)
        {
            case EnemyKind.VoidHowler:
                return "공허 틈에서 몰려나온 사냥꾼입니다. 혼자일 때보다 무리로 남았을 때 훨씬 성가십니다.";
            case EnemyKind.StarDustExecutor:
                return "탁한 별가루로 무장한 집행자입니다. 서로의 빛을 겹쳐 방진을 만들고 플레이어를 정화 대상으로 삼습니다.";
            case EnemyKind.FallenScorpio:
                return "황도13궁의 독이 타락해 태어난 보스입니다. 천무독이 쌓이면 체력과 상관없이 처형됩니다.";
            case EnemyKind.StarAdversary:
                return "별빛을 거스르는 최종 적입니다. 별핵을 충전해 큰 유성우를 준비합니다.";
            default:
                return "정체를 알 수 없는 적입니다.";
        }
    }

    private string GetEnemyGimmickText(EnemyKind kind)
    {
        switch (kind)
        {
            case EnemyKind.VoidHowler:
                return
                    $"- 기본 공격 후 {voidHowlerDiscardChance * 100f:F0}% 확률로 카드 1장을 버리게 합니다.\n" +
                    $"- 2마리 이상 살아있으면 {voidHowlerPackHowlChance * 100f:F0}% 확률로 공허의 합창을 사용합니다.\n" +
                    $"- 공허의 합창은 다음 플레이어 턴 기력을 {voidHowlerPackEnergyDrain} 이상 깎습니다.";
            case EnemyKind.StarDustExecutor:
                return
                    $"- 정화의 창으로 공격하며 정화 스택과 방어력 감소를 남깁니다.\n" +
                    $"- 정화 스택 {purificationMaxStacks}개가 되면 별가루화 상태가 됩니다.\n" +
                    $"- 살아있는 집행자 1마리마다 피해 감소가 {starDustFormationDamageReductionPerAlly * 100f:F0}%씩 강해집니다.";
            case EnemyKind.FallenScorpio:
                return
                    $"- 천무독 사용 시 일반 피해와 함께 최대체력 {heavenlyPoisonMaxHpRatio * 100f:F0}% 고정 피해를 줍니다.\n" +
                    $"- 천무독 {Mathf.Max(3, scorpioInstantPoisonStack)}스택이 쌓이면 즉사합니다.\n" +
                    "- 처녀자리 베일은 독 스택을 정화할 수 있습니다.";
            case EnemyKind.StarAdversary:
                return
                    $"- 적 턴 시작마다 별가루 지속 피해 {starAdversaryAuraDamage:F0}를 줍니다.\n" +
                    $"- 별핵을 {Mathf.Max(1, starAdversaryMeteorChargeMax)}번 충전하면 별무리 유성우가 떨어집니다.\n" +
                    "- 별무리 유성우는 여러 번 나뉘어 들어오는 연속 피해입니다.";
            default:
                return "- 아직 등록된 기믹이 없습니다.";
        }
    }

    private string GetEnemyCounterText(EnemyKind kind)
    {
        switch (kind)
        {
            case EnemyKind.VoidHowler:
                return "무리 수를 먼저 줄이면 다음 턴 기력 손실과 총 공격 횟수가 줄어듭니다.";
            case EnemyKind.StarDustExecutor:
                return "한 마리씩 빠르게 정리하면 정화 방진 피해 감소가 약해집니다. 방어력 감소가 쌓이면 방어 카드를 아껴 두세요.";
            case EnemyKind.FallenScorpio:
                return "천무독 스택이 쌓이기 전에 공격을 몰아치거나 처녀자리로 위험한 상태를 정리하세요.";
            case EnemyKind.StarAdversary:
                return "별핵 충전이 보이면 쌍둥이자리 방어막이나 처녀자리 피해 제한을 준비하세요.";
            default:
                return "적의 패턴을 확인하면서 대응하세요.";
        }
    }

    private EnemyBalance GetEnemyBalance(EnemyKind kind)
    {
        switch (kind)
        {
            case EnemyKind.VoidHowler:
                return new EnemyBalance(voidHowlerHP, voidHowlerAttack, tutorialEnemyDamageLimit, voidHowlerDiscardChance, 0);
            case EnemyKind.StarDustExecutor:
                return new EnemyBalance(starDustExecutorHP, starDustExecutorAttack, 0f, 0f, 0);
            case EnemyKind.FallenScorpio:
                return new EnemyBalance(fallenScorpioHP, fallenScorpioAttack, 0f, 0f, scorpioInstantPoisonStack);
            case EnemyKind.StarAdversary:
                return new EnemyBalance(starAdversaryHP, starAdversaryAttack, 0f, 0f, 0);
            default:
                return new EnemyBalance(100f, 10f, 0f, 0f, 0);
        }
    }
}
