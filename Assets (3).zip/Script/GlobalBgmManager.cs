using UnityEngine;

public class GlobalBgmManager : MonoBehaviour
{
    private const string BgmResourcePath = "Audio/Celestial_Whispering_Veils";
    private const string MobBattleBgmResourcePath = "Audio/Whispers_of_the_Santa_Claus";
    private const string BossBgmResourcePath = "Audio/Triumph_of_the_Unknown";
    private const string VolumePrefsKey = "Volume";
    private const float DefaultVolume = 0.75f;

    private static GlobalBgmManager instance;
    private AudioSource audioSource;
    private string currentPlayingPath = "";  // 지금 재생 중인 BGM 경로 추적용

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void EnsureBgmPlayer()
    {
        if (instance != null) return;
        GameObject go = new GameObject("Global BGM Manager");
        DontDestroyOnLoad(go);
        instance = go.AddComponent<GlobalBgmManager>();
    }

    private void Awake()
    {
        if (instance != null && instance != this) { Destroy(gameObject); return; }
        instance = this;
        DontDestroyOnLoad(gameObject);
        PrepareAudioSource();
    }

    private void OnEnable()
    {
        // UnityEngine.SceneManagement.SceneManager를 전체 경로로 씁니다.
        // 프로젝트에 SceneManager.cs 커스텀 파일이 있어서 using으로 가져오면 이름이 충돌합니다.
        UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        UnityEngine.SceneManagement.SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    // 씬이 바뀔 때마다 자동으로 호출됩니다
    private void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
    {
        UpdateBgmForCurrentScene();
    }

    private void UpdateBgmForCurrentScene()
    {
        string currentSceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
        bool isBattleScene = currentSceneName == StoryBattleFlow.BattleSceneName;
        bool isBossStage = isBattleScene && (StoryBattleFlow.BattleStageIndex == 3 || StoryBattleFlow.BattleStageIndex == 4);

        string targetPath = BgmResourcePath;
        if (isBossStage) targetPath = BossBgmResourcePath;
        else if (isBattleScene) targetPath = MobBattleBgmResourcePath;

        PlayBgm(targetPath);
    }

    public static void SetBossBattleActive(bool isBossBattle)
    {
        if (instance == null) return;

        instance.PlayBgm(isBossBattle ? BossBgmResourcePath : MobBattleBgmResourcePath);
    }

    private void Update()
    {
        ApplySavedVolume();
    }

    public static void SetVolume(float volume)
    {
        float safeVolume = Mathf.Clamp01(volume);
        PlayerPrefs.SetFloat(VolumePrefsKey, safeVolume);
        PlayerPrefs.Save();
        if (instance != null) instance.ApplyVolume(safeVolume);
    }

    private void PrepareAudioSource()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();

        audioSource.playOnAwake = false;
        audioSource.loop = true;
        audioSource.spatialBlend = 0f;
        audioSource.priority = 0;
        ApplySavedVolume();

        // 처음 시작할 때도 씬에 맞는 BGM 재생
        UpdateBgmForCurrentScene();
    }

    private void PlayBgm(string resourcePath)
    {
        // 이미 같은 BGM이 재생 중이면 다시 시작하지 않습니다
        if (currentPlayingPath == resourcePath && audioSource.isPlaying) return;

        AudioClip clip = Resources.Load<AudioClip>(resourcePath);
        if (clip == null)
        {
            Debug.LogWarning($"BGM 파일을 찾을 수 없습니다: Resources/{resourcePath}");
            return;
        }

        audioSource.Stop();
        audioSource.clip = clip;
        audioSource.Play();
        currentPlayingPath = resourcePath;
    }

    private void ApplySavedVolume()
    {
        ApplyVolume(PlayerPrefs.GetFloat(VolumePrefsKey, DefaultVolume));
    }

    private void ApplyVolume(float volume)
    {
        if (audioSource != null)
            audioSource.volume = Mathf.Clamp01(volume);
    }
}
