using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using DG.Tweening;
#if UNITY_EDITOR
using UnityEditor;
#endif

// 카드 생성과 손패 배치를 담당합니다.
// Assets/Card 폴더의 12개 프리팹을 읽어서, 전투 중 UI 카드로 변환해 손패에 보여줍니다.
//
// 이 파일의 핵심 역할:
// - 카드 프리팹을 찾아 덱 목록을 만듭니다.
// - 턴 시작 시 카드 UI를 손패 영역에 배치합니다.
// - 카드가 사용되면 손패에서 제거하고 TurnManager에 알려줍니다.
// - 각 별자리 카드의 기본 코스트/피해/능력/설명을 설정합니다.
//
// 공부할 때 추천 순서:
// 1. EnsureDeck: 카드 목록이 어떻게 준비되는지 봅니다.
// 2. DrawStartingHand / DrawTurnHand: 카드를 몇 장 뽑는지 봅니다.
// 3. CreateHandCardFromPrefab: SpriteRenderer 기반 프리팹을 UI Button 카드로 바꾸는 과정을 봅니다.
// 4. CreateDefaultCardBalanceSettings: 카드 밸런스가 어디서 정해지는지 봅니다.
//
// 초심자용 핵심 개념:
// - List<GameObject>는 GameObject 여러 개를 담는 목록입니다.
// - Instantiate는 프리팹이나 오브젝트를 복제합니다.
// - Destroy는 필요 없어진 오브젝트를 제거합니다.
// - Transform은 오브젝트의 위치/부모/자식 관계를 다룹니다.
// - UI 카드는 Button + Image + Card 컴포넌트가 붙은 GameObject입니다.
//
// "덱"과 "손패" 차이:
// - cardPrefabs는 뽑을 수 있는 카드 후보 목록입니다.
// - currentHand는 지금 화면 아래에 실제로 떠 있는 카드 UI 목록입니다.
// - 카드를 사용하면 currentHand에서 빠지고, GameObject도 Destroy됩니다.
public class CardManmager : MonoBehaviour
{
    private const string CardArtSheetResourcePath = "CardArt/ZodiacCardSheet";
    private const float RuntimeCardSpriteWidth = 232f;
    private const float RuntimeCardSpriteHeight = 553f;
    private const float HandPanelHorizontalSafetyPadding = 96f;

    private static readonly string[] RuntimeCardArtOrder =
    {
        "양자리",
        "황소자리",
        "쌍둥이자리",
        "게자리",
        "사자자리",
        "처녀자리",
        "천칭자리",
        "전갈자리",
        "사수자리",
        "염소자리",
        "물병자리",
        "물고기자리"
    };

    private static readonly Dictionary<string, Sprite> runtimeCardArtCache = new Dictionary<string, Sprite>();
    private static readonly Dictionary<Sprite, Sprite> fullRectSpriteCache = new Dictionary<Sprite, Sprite>();

    [System.Serializable]
    private class CardBalanceSetting
    {
        // Inspector에서 보기 좋게 카드 밸런스 값을 묶어둔 내부 클래스입니다.
        // CardDate는 실제 카드 데이터이고, CardBalanceSetting은 런타임에 그 데이터를 채우는 기본 설정표입니다.
        [Header("기본 정보")]
        public string cardName;
        [TextArea(2, 6)]
        public string description;
        public int cost;
        public float power;
        public CardDate.CardType type;
        public CardDate.CardAbility ability;

        [Header("능력 수치")]
        public float damageMultiplier = 1f;
        public float shieldRatio = 0f;
        public float shieldAmount = 0f;
        public float damageCap = 5f;
        public int buffStacks = 0;
        public int buffTurns = 0;
        public float poisonDamage = 0f;
        public int poisonTurns = 0;
        public int weatheringTurns = 0;
        public int energyGain = 0;
        public float healAmount = 0f;
        public float nextAttackMultiplier = 1f;
        public int maxStacks = 0;
        public float stackDamageBonus = 0f;

        public CardBalanceSetting(string cardName, int cost, float power, CardDate.CardType type, CardDate.CardAbility ability, string description)
        {
            this.cardName = cardName;
            this.cost = cost;
            this.power = power;
            this.type = type;
            this.ability = ability;
            this.description = description;
        }

        public void ApplyTo(CardDate data)
        {
            // 이 설정표의 값을 실제 CardDate에 복사합니다.
            // 카드 프리팹에 오래된 값이 들어 있어도, 여기서 최신 밸런스로 덮어쓸 수 있습니다.
            data.cost = cost;
            data.power = power;
            data.type = type;
            data.ability = ability;
            data.description = description;
            data.damageMultiplier = damageMultiplier;
            data.shieldRatio = shieldRatio;
            data.shieldAmount = shieldAmount;
            data.damageCap = damageCap;
            data.buffStacks = buffStacks;
            data.buffTurns = buffTurns;
            data.poisonDamage = poisonDamage;
            data.poisonTurns = poisonTurns;
            data.weatheringTurns = weatheringTurns;
            data.energyGain = energyGain;
            data.healAmount = healAmount;
            data.nextAttackMultiplier = nextAttackMultiplier;
            data.maxStacks = maxStacks;
            data.stackDamageBonus = stackDamageBonus;
        }
    }

    public static CardManmager Instance;

    [Header("--- [연결할 오브젝트] ---")]
    [SerializeField] private List<GameObject> cardPrefabs; // Assets/Card에 있는 별자리 카드 프리팹
    [SerializeField] private Transform panelTransform;     // Horizontal Layout Group이 붙은 패널
    [SerializeField] private Transform deckTransform;      // 카드가 출발할 덱 위치 (UI 트랜스폼)
    [SerializeField] private int startingHandCount = 7;
    [SerializeField] private int cardsPerTurn = 5;
    [SerializeField] private int maxHandCount = 7;

    [Header("--- [트윈 연출 세팅] ---")]
    [SerializeField] private float moveDuration = 0.6f;    // 카드가 날아가는 시간
    [SerializeField] private float intervalDelay = 0.12f;  // 카드 간의 출발 시간차
    [SerializeField] private Vector2 handCardSize = new Vector2(202f, 298f);
    [SerializeField] private float handSpacing = 20f;
    [SerializeField] private Ease moveEase = Ease.OutQuad; // 이동 애니메이션 곡선

    [Header("--- [카드 밸런스 설정] ---")]
    [SerializeField] private List<CardBalanceSetting> cardBalanceSettings = new List<CardBalanceSetting>(); // 여기서 별자리 카드의 코스트/피해/회복/버프 수치를 수정합니다.

    [Header("--- [드로우 확률 설정] ---")]
    [SerializeField, Min(1)] private int attackCardDrawWeight = 2;
    [SerializeField, Min(1)] private int otherCardDrawWeight = 1;
    [SerializeField, Min(1)] private int ultimateCardDrawWeight = 1;

    private readonly List<Card> currentHand = new List<Card>();
    private readonly List<GameObject> runtimeCardTemplates = new List<GameObject>();
    private readonly List<GameObject> drawableDeckBuffer = new List<GameObject>();
    private readonly Dictionary<GameObject, string> prefabNameCache = new Dictionary<GameObject, string>();
    private readonly Dictionary<string, CardBalanceSetting> cardBalanceLookup = new Dictionary<string, CardBalanceSetting>();

    public int CurrentHandCount => currentHand.Count;

    private void Awake()
    {
        // 다른 스크립트가 CardManmager.Instance로 손패에 접근할 수 있게 합니다.
        if (Instance == null) Instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }

        EnsureCardBalanceSettings();
    }

    private void OnValidate()
    {
        // 인스펙터에서 CardManmager를 눌렀을 때 별자리 카드 설정 칸이 자동으로 준비되게 합니다.
        EnsureCardBalanceSettings();
    }

    private void Start()
    {
        // TurnManager가 없을 때도 단독 테스트가 가능하도록 기본 손패를 배치합니다.
        if (TurnManager.Instance == null)
        {
            DrawTurnHand();
        }
    }

    public void DrawTurnHand()
    {
        // 일반 턴 시작 때 cardsPerTurn만큼 카드를 뽑습니다.
        // SpawnAndSetupCards가 손패 최대치와 카드 생성 애니메이션을 처리합니다.
        SpawnAndSetupCards(cardsPerTurn);
    }

    public void DrawStartingHand()
    {
        // 첫 턴에는 기존 손패를 비우고 7장을 뽑습니다.
        // 전투 재시작 또는 테스트 상황에서 이전 손패 UI가 남아 있지 않게 먼저 ClearHand를 호출합니다.
        ClearHand();
        SpawnAndSetupCards(startingHandCount);
    }

    public void Configure(Transform handPanel, Transform deckAnchor)
    {
        // BattleSceneBootstrap이 자동 생성한 손패 패널과 덱 위치를 연결합니다.
        panelTransform = handPanel;
        deckTransform = deckAnchor;
        FitCardsInsideHandPanel();
    }

    public void SpawnAndSetupCards(int cardCount)
    {
        // 카드 드로우의 핵심 함수입니다.
        // 뽑을 수 있는 카드 풀을 만들고, 손패 최대치 7장을 넘지 않게 생성합니다.
        if (panelTransform == null || deckTransform == null) return;
        EnsureDeck();

        BuildDrawableDeck(drawableDeckBuffer);
        Shuffle(drawableDeckBuffer);

        int availableSlots = Mathf.Max(0, maxHandCount - currentHand.Count);
        int drawCount = Mathf.Min(cardCount, drawableDeckBuffer.Count, availableSlots);
        int startIndex = currentHand.Count;
        int totalHandCountAfterDraw = currentHand.Count + drawCount;
        for (int i = 0; i < drawCount; i++)
        {
            GameObject originPrefab = drawableDeckBuffer[i];

            // SpriteRenderer 기반 원본 프리팹을 UI 카드로 감싸 손패에 표시합니다.
            GameObject newCard = CreateHandCardFromPrefab(originPrefab);
            newCard.transform.SetParent(panelTransform, false);
            newCard.transform.position = deckTransform.position;
            newCard.SetActive(true);
            Card card = newCard.GetComponent<Card>();
            if (card != null)
            {
                currentHand.Add(card);
            }

            // 3. UI 자동 정렬 컴포넌트 제어 (컴포넌트가 없다면 자동 추가)
            LayoutElement layoutElement = newCard.GetComponent<LayoutElement>();
            if (layoutElement == null)
            {
                layoutElement = newCard.AddComponent<LayoutElement>();
            }

            // [중요] 이동하는 동안 패널이 카드를 강제로 배치하지 못하도록 차단
            layoutElement.ignoreLayout = true;

            // 4. DOTween 시퀀스 연출 구성
            Sequence spawnSequence = DOTween.Sequence();
            
            // 각 카드마다 출발에 시간차(Delay)를 줍니다.
            spawnSequence.SetDelay(i * intervalDelay);

            // 초기 상태 세팅 (크기 0에서 시작)
            newCard.transform.localScale = Vector3.zero;

            // 연출 A: 크기가 뿅하고 커짐 (통통 튀는 느낌 부여)
            spawnSequence.Append(newCard.transform.DOScale(Vector3.one, moveDuration).SetEase(Ease.OutBack));

            // 연출 B: 크기가 커짐과 동시에 덱 위치에서 패널의 고유 슬롯(0,0,0)으로 날아감
            // 패널의 자식이 되었으므로 LocalMove 기준 (0,0,0)이 자기 자리가 됩니다.
            spawnSequence.Join(newCard.transform.DOLocalMove(GetHandSlotPosition(startIndex + i, totalHandCountAfterDraw), moveDuration).SetEase(moveEase));

            // 연출 C: 도착이 완료되면 패널의 자동 정렬 시스템에 카드를 편입시킴
            spawnSequence.OnComplete(() =>
            {
                layoutElement.ignoreLayout = false;
            });
        }

        int discardedCount = Mathf.Max(0, cardCount - drawCount);
        if (discardedCount > 0)
        {
            Debug.Log($"손패가 {maxHandCount}장을 넘어 {discardedCount}장을 버렸습니다.");
        }
    }

    public void NotifyCardUsed(Card usedCard)
    {
        // Card.cs에서 카드 사용이 끝나면 호출됩니다.
        // 손패 목록에서 제거하고 실제 오브젝트도 삭제합니다.
        if (usedCard == null) return;

        currentHand.Remove(usedCard);
        usedCard.transform.DOKill();
        Destroy(usedCard.gameObject);

        if (TurnManager.Instance != null)
        {
            TurnManager.Instance.NotifyPlayerActionResolved();
        }
    }

    public void ClearHand()
    {
        // 손패 UI를 모두 비웁니다. 첫 손패 생성이나 전투 리셋에 사용합니다.
        currentHand.Clear();

        if (panelTransform == null) return;

        foreach (Transform child in panelTransform)
        {
            child.DOKill();
            Destroy(child.gameObject);
        }
    }

    public void DiscardRandomCard()
    {
        // 공허의 울음꾼 하울링 같은 효과가 손패 1장을 버릴 때 사용합니다.
        if (currentHand.Count <= 0) return;

        int index = Random.Range(0, currentHand.Count);
        Card card = currentHand[index];
        currentHand.RemoveAt(index);

        if (card != null)
        {
            card.transform.DOKill();
            Destroy(card.gameObject);
        }
    }

    private void Shuffle(List<GameObject> deck)
    {
        for (int i = 0; i < deck.Count; i++)
        {
            int randomIndex = Random.Range(i, deck.Count);
            GameObject temp = deck[i];
            deck[i] = deck[randomIndex];
            deck[randomIndex] = temp;
        }
    }

    private void BuildDrawableDeck(List<GameObject> drawableDeck)
    {
        // 현재 뽑을 수 있는 카드 목록을 만듭니다.
        // 사수자리는 달의 기운이 100%일 때만 이 목록에 들어갑니다.
        drawableDeck.Clear();
        bool canUseUltimate = BattleManager.Instance != null && BattleManager.Instance.CanUseUltimate();

        foreach (GameObject prefab in cardPrefabs)
        {
            if (prefab == null) continue;

            string cardName = GetCachedCardName(prefab);
            if (cardName == "사수자리" && !canUseUltimate)
            {
                continue;
            }

            CardDate.CardType cardType = GetCardTypeForDraw(prefab, cardName);
            int drawWeight = GetDrawWeight(cardType);
            for (int weightIndex = 0; weightIndex < drawWeight; weightIndex++)
            {
                drawableDeck.Add(prefab);
            }
        }
    }

    private CardDate.CardType GetCardTypeForDraw(GameObject prefab, string cardName)
    {
        CardBalanceSetting setting = FindCardBalanceSetting(cardName);
        if (setting != null)
        {
            return setting.type;
        }

        Card sourceCard = prefab != null ? prefab.GetComponent<Card>() : null;
        if (sourceCard != null && sourceCard.data != null)
        {
            return sourceCard.data.type;
        }

        return CardDate.CardType.Attack;
    }

    private int GetDrawWeight(CardDate.CardType cardType)
    {
        if (cardType == CardDate.CardType.Attack)
        {
            return Mathf.Max(1, attackCardDrawWeight);
        }

        if (cardType == CardDate.CardType.Ultimate)
        {
            return Mathf.Max(1, ultimateCardDrawWeight);
        }

        return Mathf.Max(1, otherCardDrawWeight);
    }

    private Vector3 GetHandSlotPosition(int index, int totalCount)
    {
        // 카드가 한 점에 겹치지 않고, 자기 슬롯 위치로 날아가게 계산합니다.
        float totalWidth = totalCount * handCardSize.x + Mathf.Max(0, totalCount - 1) * handSpacing;
        float x = -totalWidth * 0.5f + handCardSize.x * 0.5f + index * (handCardSize.x + handSpacing);
        return new Vector3(x, 0f, 0f);
    }

    private void FitCardsInsideHandPanel()
    {
        // 손패 7장이 작은 화면이나 빌드 해상도에서 가장자리로 잘리지 않도록,
        // 패널 폭보다 카드 총 폭이 커지면 카드 크기와 간격을 같은 비율로 줄입니다.
        RectTransform panelRect = panelTransform as RectTransform;
        if (panelRect == null) return;

        float panelWidth = panelRect.rect.width > 0f ? panelRect.rect.width : panelRect.sizeDelta.x;
        float usableWidth = Mathf.Max(360f, panelWidth - HandPanelHorizontalSafetyPadding);
        float totalWidth = maxHandCount * handCardSize.x + Mathf.Max(0, maxHandCount - 1) * handSpacing;
        if (totalWidth > usableWidth)
        {
            float scale = Mathf.Clamp(usableWidth / totalWidth, 0.84f, 1f);
            handCardSize *= scale;
            handSpacing *= scale;
        }

        HorizontalLayoutGroup layout = panelTransform.GetComponent<HorizontalLayoutGroup>();
        if (layout != null)
        {
            layout.spacing = handSpacing;
            layout.padding.left = 24;
            layout.padding.right = 24;
        }
    }

    private void EnsureDeck()
    {
        // cardPrefabs가 비어 있으면 Assets/Card에서 프리팹을 자동으로 찾습니다.
        // 에디터가 아닌 빌드에서는 Resources/Card에서 찾도록 예비 코드가 들어 있습니다.
        if (cardPrefabs != null && cardPrefabs.Count > 0) return;

        cardPrefabs = new List<GameObject>();
        runtimeCardTemplates.Clear();

        LoadCardPrefabsFromProject();

        if (cardPrefabs.Count > 0) return;

        CreateRuntimeCard("양자리", 1, 12, CardDate.CardType.Attack, new Color(0.78f, 0.22f, 0.22f));
        CreateRuntimeCard("황소자리", 2, 14, CardDate.CardType.Attack, new Color(0.22f, 0.55f, 0.28f));
        CreateRuntimeCard("쌍둥이자리", 1, 0, CardDate.CardType.Defense, new Color(0.95f, 0.72f, 0.24f));
        CreateRuntimeCard("게자리", 3, 18, CardDate.CardType.Attack, new Color(0.18f, 0.56f, 0.78f));
        CreateRuntimeCard("사자자리", 2, 12, CardDate.CardType.Attack, new Color(0.94f, 0.47f, 0.18f));
        CreateRuntimeCard("처녀자리", 1, 10, CardDate.CardType.Buff, new Color(0.58f, 0.48f, 0.38f));
        CreateRuntimeCard("천칭자리", 1, 6, CardDate.CardType.Buff, new Color(0.5f, 0.46f, 0.82f));
        CreateRuntimeCard("전갈자리", 2, 11, CardDate.CardType.Attack, new Color(0.45f, 0.18f, 0.28f));
        CreateRuntimeCard("사수자리", 3, 20, CardDate.CardType.Ultimate, new Color(0.28f, 0.42f, 0.78f));
        CreateRuntimeCard("염소자리", 2, 9, CardDate.CardType.Attack, new Color(0.35f, 0.36f, 0.34f));
        CreateRuntimeCard("물병자리", 0, 0, CardDate.CardType.Energy, new Color(0.17f, 0.68f, 0.72f));
        CreateRuntimeCard("물고기자리", 1, 7, CardDate.CardType.Buff, new Color(0.34f, 0.42f, 0.68f));
    }

    private void LoadCardPrefabsFromProject()
    {
#if UNITY_EDITOR
        string[] guids = AssetDatabase.FindAssets("t:Prefab", new[] { "Assets/Card" });
        System.Array.Sort(guids);

        foreach (string guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefab != null && prefab.GetComponentInChildren<SpriteRenderer>() != null)
            {
                cardPrefabs.Add(prefab);
            }
        }
#else
        GameObject[] loadedPrefabs = Resources.LoadAll<GameObject>("Card");
        foreach (GameObject prefab in loadedPrefabs)
        {
            if (prefab != null && prefab.GetComponentInChildren<SpriteRenderer>() != null)
            {
                cardPrefabs.Add(prefab);
            }
        }
#endif
    }

    private GameObject CreateHandCardFromPrefab(GameObject sourcePrefab)
    {
        // 원본 카드 프리팹은 SpriteRenderer 기반이라 UI에 바로 쓰기 어렵습니다.
        // 그래서 원본 스프라이트/데이터를 읽고, 새 UI 카드 오브젝트를 만들어 반환합니다.
        // 여기서 만들어지는 카드에는 Button과 Card 컴포넌트가 붙어서 실제로 클릭할 수 있습니다.
        string cardName = GetCachedCardName(sourcePrefab);
        Sprite cardSprite = ResolveCardArtwork(sourcePrefab, cardName);
        CardDate data = GetPrefabData(sourcePrefab, cardName, cardSprite);

        GameObject cardObject = new GameObject(cardName + " Hand Card", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(Card));

        RectTransform rect = cardObject.GetComponent<RectTransform>();
        rect.sizeDelta = handCardSize;
        LayoutElement layoutElement = cardObject.AddComponent<LayoutElement>();
        layoutElement.preferredWidth = handCardSize.x;
        layoutElement.preferredHeight = handCardSize.y;
        layoutElement.minWidth = handCardSize.x;
        layoutElement.minHeight = handCardSize.y;

        Image background = cardObject.GetComponent<Image>();
        background.color = new Color(0.08f, 0.08f, 0.1f, 1f);

        Image artwork = CreateArtworkImage(cardObject.transform, cardSprite);

        Card card = cardObject.GetComponent<Card>();
        card.costDisplay = CreateText("Cost", cardObject.transform, data.cost.ToString(), 22, TextAnchor.MiddleCenter, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(22f, -18f), new Vector2(34f, 30f));
        card.nameDisplay = CreateText("Name", cardObject.transform, cardName, 21, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -56f), new Vector2(172f, 30f));
        card.powerDisplay = CreateText("Power", cardObject.transform, data.power.ToString("F0"), 22, TextAnchor.MiddleCenter, new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(-22f, 24f), new Vector2(42f, 30f));
        card.artworkDisplay = artwork;
        card.SetData(data);

        return cardObject;
    }

    private Image CreateArtworkImage(Transform parent, Sprite sprite)
    {
        GameObject artworkObject = new GameObject("Artwork", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        artworkObject.transform.SetParent(parent, false);

        RectTransform rect = artworkObject.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.5f, 0.5f);
        rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.anchoredPosition = new Vector2(0f, -6f);
        rect.sizeDelta = new Vector2(handCardSize.x - 30f, handCardSize.y - 48f);

        Image image = artworkObject.GetComponent<Image>();
        image.sprite = sprite;
        image.color = sprite != null ? Color.white : new Color(0.16f, 0.18f, 0.24f, 1f);
        image.type = Image.Type.Simple;
        image.useSpriteMesh = false;
        image.preserveAspect = true;
        image.raycastTarget = false;

        return image;
    }

    private Sprite GetPrefabSprite(GameObject sourcePrefab)
    {
        if (sourcePrefab == null) return null;

        SpriteRenderer renderer = sourcePrefab.GetComponentInChildren<SpriteRenderer>();
        return renderer != null ? renderer.sprite : null;
    }

    private Sprite ResolveCardArtwork(GameObject sourcePrefab, string cardName)
    {
        // 에디터에서는 프리팹이 들고 있는 SpriteRenderer를 우선 사용합니다.
        // 빌드에서는 Assets/Card 폴더를 직접 검색할 수 없기 때문에 Resources/CardArt의 카드 시트를 잘라서 사용합니다.
        Sprite prefabSprite = GetPrefabSprite(sourcePrefab);
        if (prefabSprite != null) return CreateFullRectSprite(prefabSprite);

        Card sourceCard = sourcePrefab != null ? sourcePrefab.GetComponent<Card>() : null;
        if (sourceCard != null && sourceCard.data != null && sourceCard.data.cardImage != null)
        {
            return CreateFullRectSprite(sourceCard.data.cardImage);
        }

        return LoadRuntimeCardArtwork(cardName);
    }

    private Sprite LoadRuntimeCardArtwork(string cardName)
    {
        string key = NormalizeCardName(cardName);
        if (string.IsNullOrEmpty(key)) return null;
        if (runtimeCardArtCache.TryGetValue(key, out Sprite cachedSprite)) return cachedSprite;

        Texture2D sheet = Resources.Load<Texture2D>(CardArtSheetResourcePath);
        if (sheet == null)
        {
            Debug.LogWarning($"카드 시트를 찾지 못했습니다: Resources/{CardArtSheetResourcePath}");
            runtimeCardArtCache[key] = null;
            return null;
        }

        int index = GetRuntimeCardArtIndex(key);
        if (index < 0)
        {
            Debug.LogWarning($"{cardName} 카드의 시트 위치를 찾지 못했습니다.");
            runtimeCardArtCache[key] = null;
            return null;
        }

        int column = index % 6;
        int row = index / 6;
        float x = 8f + column * RuntimeCardSpriteWidth;
        float y = row == 0 ? 553f : 0f;
        Rect rect = new Rect(x, y, RuntimeCardSpriteWidth, RuntimeCardSpriteHeight);

        Sprite sprite = Sprite.Create(sheet, rect, new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, Vector4.zero);
        sprite.name = key + " 카드 그림";
        runtimeCardArtCache[key] = sprite;
        return sprite;
    }

    private Sprite CreateFullRectSprite(Sprite source)
    {
        if (source == null) return null;
        if (fullRectSpriteCache.TryGetValue(source, out Sprite cachedSprite)) return cachedSprite;

        try
        {
            Rect rect = source.textureRect;
            Vector2 pivot = new Vector2(
                rect.width > 0f ? source.pivot.x / rect.width : 0.5f,
                rect.height > 0f ? source.pivot.y / rect.height : 0.5f);

            Sprite sprite = Sprite.Create(source.texture, rect, pivot, source.pixelsPerUnit, 0, SpriteMeshType.FullRect, Vector4.zero);
            sprite.name = source.name + " FullRect";
            fullRectSpriteCache[source] = sprite;
            return sprite;
        }
        catch (System.Exception)
        {
            fullRectSpriteCache[source] = source;
            return source;
        }
    }

    private int GetRuntimeCardArtIndex(string normalizedCardName)
    {
        for (int i = 0; i < RuntimeCardArtOrder.Length; i++)
        {
            if (NormalizeCardName(RuntimeCardArtOrder[i]) == normalizedCardName)
            {
                return i;
            }
        }

        return -1;
    }

    private CardDate GetPrefabData(GameObject sourcePrefab, string cardName, Sprite cardSprite)
    {
        // 프리팹에 CardDate가 있으면 그 데이터를 사용하고,
        // 없으면 런타임 ScriptableObject를 만들어 기본 능력치를 채웁니다.
        Card sourceCard = sourcePrefab.GetComponent<Card>();
        if (sourceCard != null && sourceCard.data != null)
        {
            sourceCard.data.cardName = cardName;
            sourceCard.data.cardImage = cardSprite != null ? cardSprite : sourceCard.data.cardImage;
            ApplyDefaultStats(sourceCard.data);
            return sourceCard.data;
        }

        CardDate data = ScriptableObject.CreateInstance<CardDate>();
        data.cardName = cardName;
        data.cardImage = cardSprite;
        ApplyDefaultStats(data);
        return data;
    }

    private string NormalizeCardName(string prefabName)
    {
        if (string.IsNullOrEmpty(prefabName)) return string.Empty;

        return prefabName
            .Replace(" ", "")
            .Replace("카드", "")
            .Replace("Card", "")
            .Replace("card", "")
            .Replace("(Clone)", "");
    }

    private string GetCachedCardName(GameObject prefab)
    {
        if (prefab == null) return string.Empty;
        if (prefabNameCache.TryGetValue(prefab, out string cachedName)) return cachedName;

        string normalizedName = NormalizeCardName(prefab.name);
        prefabNameCache[prefab] = normalizedName;
        return normalizedName;
    }

    private void ApplyDefaultStats(CardDate data)
    {
        // 별자리 카드의 기본 코스트/피해/능력/설명을 인스펙터 설정값에서 가져옵니다.
        // 카드 밸런스를 수정하고 싶으면 CardManmager 오브젝트의 "카드 밸런스 설정" 리스트를 고치면 됩니다.
        if (cardBalanceSettings == null || cardBalanceSettings.Count == 0 || cardBalanceLookup.Count == 0)
        {
            EnsureCardBalanceSettings();
        }

        CardBalanceSetting setting = FindCardBalanceSetting(data.cardName);
        if (setting == null)
        {
            Debug.LogWarning($"{data.cardName} 카드의 밸런스 설정을 찾지 못했습니다. 기본 공격 카드로 처리합니다.");
            setting = CreateFallbackCardSetting(data.cardName);
        }

        setting.ApplyTo(data);
    }

    private CardBalanceSetting FindCardBalanceSetting(string cardName)
    {
        string normalizedName = NormalizeCardName(cardName);
        if (string.IsNullOrEmpty(normalizedName)) return null;

        if (cardBalanceLookup.TryGetValue(normalizedName, out CardBalanceSetting setting))
        {
            return setting;
        }

        RebuildCardBalanceLookup();
        return cardBalanceLookup.TryGetValue(normalizedName, out setting) ? setting : null;
    }

    private void EnsureCardBalanceSettings()
    {
        // 카드 밸런스 리스트가 비어 있거나 일부 카드가 빠져 있어도
        // 기본 별자리 카드 설정이 항상 존재하도록 보장합니다.
        if (cardBalanceSettings == null)
        {
            cardBalanceSettings = new List<CardBalanceSetting>();
        }

        RebuildCardBalanceLookup();

        List<CardBalanceSetting> defaults = CreateDefaultCardBalanceSettings();
        foreach (CardBalanceSetting defaultSetting in defaults)
        {
            string key = NormalizeCardName(defaultSetting.cardName);
            if (!cardBalanceLookup.TryGetValue(key, out CardBalanceSetting existingSetting))
            {
                cardBalanceSettings.Add(defaultSetting);
                cardBalanceLookup[key] = defaultSetting;
            }
            else
            {
                ApplyCardIdentityOverride(existingSetting, defaultSetting);
            }
        }

        RebuildCardBalanceLookup();
    }

    private void RebuildCardBalanceLookup()
    {
        cardBalanceLookup.Clear();
        if (cardBalanceSettings == null) return;

        for (int i = 0; i < cardBalanceSettings.Count; i++)
        {
            CardBalanceSetting setting = cardBalanceSettings[i];
            if (setting == null) continue;

            string key = NormalizeCardName(setting.cardName);
            if (string.IsNullOrEmpty(key)) continue;

            cardBalanceLookup[key] = setting;
        }
    }

    private void ApplyCardIdentityOverride(CardBalanceSetting setting, CardBalanceSetting defaultSetting)
    {
        // 씬에 이미 저장된 카드 밸런스가 있으면 Unity가 그 값을 우선 사용합니다.
        // 하지만 카드 이름/종류/능력/설명은 서로 엉키면 안 되므로 기본 설정표를 항상 따르게 합니다.
        setting.cardName = defaultSetting.cardName;
        setting.type = defaultSetting.type;
        setting.ability = defaultSetting.ability;
        setting.description = defaultSetting.description;
    }

    private string WithFusionDescription(string baseDescription, CardDate.CardAbility ability)
    {
        return baseDescription + "\n연성: " + CardFusionLibrary.GetFusionHint(ability);
    }

    private List<CardBalanceSetting> CreateDefaultCardBalanceSettings()
    {
        // 모든 별자리 카드의 기본 밸런스를 한곳에서 정의합니다.
        // 새 카드의 코스트나 설명을 바꾸고 싶다면 가장 먼저 이 함수를 확인하면 됩니다.
        List<CardBalanceSetting> defaults = new List<CardBalanceSetting>();

        CardBalanceSetting aries = new CardBalanceSetting("양자리", 1, 12, CardDate.CardType.Attack, CardDate.CardAbility.AriesStrike, WithFusionDescription("선택한 적 하나에게 안정적인 피해를 줍니다.", CardDate.CardAbility.AriesStrike));
        aries.damageMultiplier = 1f;
        defaults.Add(aries);

        CardBalanceSetting taurus = new CardBalanceSetting("황소자리", 2, 14, CardDate.CardType.Attack, CardDate.CardAbility.TaurusCharge, WithFusionDescription("선택한 적 하나에게 높은 피해를 줍니다.", CardDate.CardAbility.TaurusCharge));
        taurus.damageMultiplier = 1.5f;
        defaults.Add(taurus);

        CardBalanceSetting gemini = new CardBalanceSetting("쌍둥이자리", 1, 0, CardDate.CardType.Defense, CardDate.CardAbility.GeminiShield, WithFusionDescription("방어막 30을 얻어 이번 적 턴의 피해를 받아냅니다.", CardDate.CardAbility.GeminiShield));
        gemini.shieldRatio = 0f;
        gemini.shieldAmount = 30f;
        defaults.Add(gemini);

        CardBalanceSetting cancer = new CardBalanceSetting("게자리", 3, 18, CardDate.CardType.Attack, CardDate.CardAbility.CancerCrush, WithFusionDescription("모든 적을 한 번에 공격합니다.", CardDate.CardAbility.CancerCrush));
        cancer.damageMultiplier = 2.2f;
        defaults.Add(cancer);

        CardBalanceSetting leo = new CardBalanceSetting("사자자리", 2, 12, CardDate.CardType.Attack, CardDate.CardAbility.LeoEcho, WithFusionDescription("직전 플레이어 턴의 가장 강한 공격 피해를 증폭해 공격합니다. 기억할 공격이 없으면 기본 피해로 공격합니다.", CardDate.CardAbility.LeoEcho));
        leo.damageMultiplier = 1.5f;
        defaults.Add(leo);

        CardBalanceSetting virgo = new CardBalanceSetting("처녀자리", 2, 0, CardDate.CardType.Defense, CardDate.CardAbility.VirgoVeil, WithFusionDescription("이번 적 턴 동안 단일 피해를 최대 5로 제한하고 독성 상태를 정화합니다.", CardDate.CardAbility.VirgoVeil));
        virgo.damageCap = 5f;
        defaults.Add(virgo);

        CardBalanceSetting libra = new CardBalanceSetting("천칭자리", 2, 0, CardDate.CardType.Buff, CardDate.CardAbility.LibraBalance, WithFusionDescription("2턴 동안 공격 버프 2중첩을 얻습니다.", CardDate.CardAbility.LibraBalance));
        libra.buffStacks = 2;
        libra.buffTurns = 2;
        defaults.Add(libra);

        CardBalanceSetting scorpio = new CardBalanceSetting("전갈자리", 2, 11, CardDate.CardType.Attack, CardDate.CardAbility.ScorpioPoison, WithFusionDescription("선택한 적에게 피해를 주고 3턴 동안 독을 남깁니다.", CardDate.CardAbility.ScorpioPoison));
        scorpio.damageMultiplier = 1f;
        scorpio.poisonDamage = 4f;
        scorpio.poisonTurns = 3;
        defaults.Add(scorpio);

        CardBalanceSetting sagittarius = new CardBalanceSetting("사수자리", 3, 20, CardDate.CardType.Ultimate, CardDate.CardAbility.SagittariusUltimate, WithFusionDescription("필살기. 모든 적에게 강력한 피해를 주고 풍화를 부여합니다.", CardDate.CardAbility.SagittariusUltimate));
        sagittarius.damageMultiplier = 5f;
        sagittarius.weatheringTurns = 3;
        defaults.Add(sagittarius);

        CardBalanceSetting capricorn = new CardBalanceSetting("염소자리", 2, 9, CardDate.CardType.Attack, CardDate.CardAbility.CapricornStack, WithFusionDescription("모든 적을 공격합니다. 전투 중 사용 횟수만큼 피해가 증가합니다.", CardDate.CardAbility.CapricornStack));
        capricorn.maxStacks = 3;
        capricorn.stackDamageBonus = 10f;
        defaults.Add(capricorn);

        CardBalanceSetting aquarius = new CardBalanceSetting("물병자리", 0, 0, CardDate.CardType.Energy, CardDate.CardAbility.AquariusEnergy, WithFusionDescription("기력을 1 회복합니다. 한 턴에 1번만 사용할 수 있습니다.", CardDate.CardAbility.AquariusEnergy));
        aquarius.energyGain = 1;
        defaults.Add(aquarius);

        CardBalanceSetting pisces = new CardBalanceSetting("물고기자리", 2, 0, CardDate.CardType.Buff, CardDate.CardAbility.PiscesEmpower, WithFusionDescription("기력과 체력을 회복하고 다음 공격 카드의 피해를 강화합니다.", CardDate.CardAbility.PiscesEmpower));
        pisces.energyGain = 1;
        pisces.healAmount = 5f;
        pisces.nextAttackMultiplier = 1.5f;
        defaults.Add(pisces);

        return defaults;
    }

    private CardBalanceSetting CreateFallbackCardSetting(string cardName)
    {
        CardBalanceSetting fallback = new CardBalanceSetting(cardName, 1, 10, CardDate.CardType.Attack, CardDate.CardAbility.AriesStrike, "기본 공격 카드입니다.");
        fallback.damageMultiplier = 1f;
        return fallback;
    }

    private void CreateRuntimeCard(string cardName, int cost, float power, CardDate.CardType type, Color color)
    {
        CardDate data = ScriptableObject.CreateInstance<CardDate>();
        data.cardName = cardName;
        data.cost = cost;
        data.power = power;
        data.type = type;
        data.cardImage = LoadRuntimeCardArtwork(cardName);
        ApplyDefaultStats(data);

        GameObject cardObject = new GameObject(cardName + " Card", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(Card));
        cardObject.transform.SetParent(transform, false);

        RectTransform rect = cardObject.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(150f, 220f);

        Image background = cardObject.GetComponent<Image>();
        background.color = color;

        Card card = cardObject.GetComponent<Card>();
        card.costDisplay = CreateText("Cost", cardObject.transform, data.cost.ToString(), 18, TextAnchor.MiddleCenter, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(18f, -16f), new Vector2(28f, 26f));
        card.nameDisplay = CreateText("Name", cardObject.transform, cardName, 17, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -44f), new Vector2(116f, 26f));
        card.powerDisplay = CreateText("Power", cardObject.transform, data.power.ToString("F0"), 18, TextAnchor.MiddleCenter, new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(-18f, 22f), new Vector2(34f, 26f));
        card.artworkDisplay = CreateArtworkImage(cardObject.transform, data.cardImage);
        CreateText("Type", cardObject.transform, data.type.ToString(), 17, TextAnchor.MiddleCenter, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 62f), new Vector2(130f, 34f));
        card.SetData(data);

        cardObject.SetActive(false);
        cardPrefabs.Add(cardObject);
        runtimeCardTemplates.Add(cardObject);
    }

    private Text CreateText(string objectName, Transform parent, string value, int size, TextAnchor alignment, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
    {
        GameObject textObject = new GameObject(objectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        textObject.transform.SetParent(parent, false);

        RectTransform rect = textObject.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = sizeDelta;

        Text text = textObject.GetComponent<Text>();
        text.text = value;
        text.font = GetBuiltinFont();
        text.fontSize = size;
        text.alignment = alignment;
        ReadableTextStyle.Apply(text);
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 12;
        text.resizeTextMaxSize = size;

        return text;
    }

    private Font GetBuiltinFont()
    {
        return ReadableTextStyle.GetReadableFont();
    }
}
