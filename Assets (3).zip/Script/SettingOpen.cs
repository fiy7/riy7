using UnityEngine;

// 간단한 설정창 열기/닫기 스크립트입니다.
// settingsPanel에는 Canvas 아래의 설정창 GameObject를 연결합니다.
// 버튼의 OnClick 이벤트에 OpenSettings 또는 CloseSettings를 연결하면
// 패널을 켜고 끄는 기본 UI 흐름을 만들 수 있습니다.
//
// 초심자용 핵심 개념:
// - GameObject는 Unity 씬 안에 존재하는 모든 오브젝트의 기본 단위입니다.
// - SetActive(true)는 오브젝트를 켭니다.
// - SetActive(false)는 오브젝트를 끕니다.
// - null 체크는 Inspector에 연결을 깜빡했을 때 오류를 막기 위한 안전장치입니다.
public class SettingOpen : MonoBehaviour
{
   public GameObject settingsPanel;

    // 설정창을 여는 함수입니다.
    // SetActive(true)는 비활성화되어 있던 UI 오브젝트를 다시 화면에 보이게 만듭니다.
    public void OpenSettings()
    {
        if (settingsPanel != null)
        {
            settingsPanel.SetActive(true); // 창 활성화
        }
    }

    // 설정창을 닫는 함수입니다. 닫기 버튼용으로 연결하면 됩니다.
    // null 체크를 하는 이유는 Inspector에 패널을 연결하지 않았을 때 에러를 막기 위해서입니다.
    public void CloseSettings()
    {
        if (settingsPanel != null)
        {
            settingsPanel.SetActive(false); // 창 비활성화
        }
    }
}
