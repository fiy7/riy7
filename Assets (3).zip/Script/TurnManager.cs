using UnityEngine;

// 턴의 흐름만 담당하는 관리자입니다.
// 전투 수치 계산은 BattleManager가 하고, 이 파일은 "지금 누구 턴인가"를 관리합니다.
//
// 전투 흐름 전체:
// BeginBattle
// -> StartPlayerTurn: 플레이어에게 기력 지급, 카드 드로우
// -> EndPlayerTurn: 턴 종료 버튼 또는 자동 종료로 적 턴 진입
// -> StartEnemyTurn: 독/풍화/지속 피해 같은 턴 시작 효과 처리
// -> PlayEnemyTurn: 실제 적 공격 실행
// -> StartPlayerTurn으로 다시 돌아감
//
// TurnManager는 "순서"만 관리하고, HP/피해/버프 같은 숫자 계산은 BattleManager에 맡깁니다.
//
// 초심자용 핵심 개념:
// - enum은 정해진 선택지 중 하나를 표현할 때 씁니다. 여기서는 None/Player/Enemy 중 하나입니다.
// - Invoke("함수명", 시간)는 몇 초 뒤에 함수를 실행합니다. 적 행동에 약간의 딜레이를 주기 위해 사용합니다.
// - IsPlayerTurn은 읽기 쉬운 조건문을 만들기 위한 속성입니다.
//   Card.cs에서 "지금 카드 클릭이 가능한가?"를 확인할 때 사용합니다.
public class TurnManager : MonoBehaviour
{
    public static TurnManager Instance;

    public enum TurnState
    {
        // None은 아직 전투가 시작되지 않았거나 턴 상태가 정해지지 않은 상태입니다.
        None,
        // Player는 카드 클릭이 가능한 플레이어 턴입니다.
        Player,
        // Enemy는 카드 클릭을 막고 적 행동을 기다리는 적 턴입니다.
        Enemy
    }

    [Header("턴 설정")]
    [SerializeField] private float enemyTurnDelay = 1f;
    [SerializeField] private bool autoEndWhenNoEnergy = false;
    [SerializeField] private bool autoEndWhenNoCards = true;

    public TurnState CurrentTurn { get; private set; } = TurnState.None;
    public bool IsPlayerTurn => CurrentTurn == TurnState.Player;
    private bool firstPlayerTurn = true;

    private void Awake()
    {
        // 다른 스크립트에서 TurnManager.Instance로 접근하기 위한 싱글톤입니다.
        if (Instance == null) Instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    public void BeginBattle()
    {
        // 전투가 시작될 때 첫 플레이어 턴으로 진입합니다.
        if (IsBattleAlreadyEnded()) return;

        firstPlayerTurn = true;
        StartPlayerTurn();
    }

    public void ResetTurnFlow()
    {
        // 전투를 씬 재로드 없이 다시 시작할 때 예약된 적 턴 호출을 모두 끊고,
        // 다음 BeginBattle이 첫 플레이어 턴부터 시작하게 합니다.
        CancelInvoke();
        CurrentTurn = TurnState.None;
        firstPlayerTurn = true;
    }

    public void StartPlayerTurn()
    {
        // 플레이어 턴 시작:
        // BattleManager가 기력/상태를 갱신하고, CardManmager가 카드를 뽑습니다.
        if (IsBattleAlreadyEnded()) return;

        CurrentTurn = TurnState.Player;
        CardFusionLibrary.ResetTurn();
        if (BattleManager.Instance != null) BattleManager.Instance.StartPlayerTurn();
        DrawCardsForThisTurn();

        firstPlayerTurn = false;
    }

    public void EndPlayerTurn()
    {
        // 턴 종료 버튼이 누르면 호출됩니다.
        // 현재 설정은 기력을 다 써도 자동 종료되지 않고, 이 함수로만 적 턴에 들어갑니다.
        if (CurrentTurn != TurnState.Player) return;
        if (IsBattleAlreadyEnded()) return;

        if (BattleManager.Instance != null) BattleManager.Instance.CommitPlayerTurnDamageRecord();

        CurrentTurn = TurnState.Enemy;
        if (BattleManager.Instance != null) BattleManager.Instance.StartEnemyTurn();
        if (IsBattleAlreadyEnded()) return;
        if (UIManager.Instance != null) UIManager.Instance.ShowTurnNotice("적 턴!");

        Invoke(nameof(PlayEnemyTurn), enemyTurnDelay);
    }

    public void NotifyPlayerActionResolved()
    {
        // 카드 1장이 사용된 뒤 CardManmager가 알려주는 함수입니다.
        // 지금은 자동 턴 종료가 꺼져 있어서 바로 return 됩니다.
        // 자동 종료 옵션을 켜면 "기력이 0이 됐는지" 또는 "손패가 비었는지"를 보고
        // 플레이어가 직접 턴 종료 버튼을 누르지 않아도 적 턴으로 넘어가게 할 수 있습니다.
        if (CurrentTurn != TurnState.Player) return;
        if (IsBattleAlreadyEnded()) return;

        // 기력을 다 쓰는 것은 자동 종료 조건이 아닙니다.
        // 손패 카드를 모두 사용했을 때만 자동으로 적 턴으로 넘어갑니다.
        if (ShouldAutoEndPlayerTurn())
        {
            EndPlayerTurn();
        }
    }

    private void PlayEnemyTurn()
    {
        // 적 행동을 실행한 뒤, 전투가 끝나지 않았으면 다시 플레이어 턴으로 돌아갑니다.
        if (IsBattleAlreadyEnded()) return;

        if (BattleManager.Instance != null) BattleManager.Instance.EnemyAction();

        if (!IsBattleAlreadyEnded())
        {
            Invoke(nameof(StartPlayerTurn), enemyTurnDelay);
        }
    }

    private void DrawCardsForThisTurn()
    {
        if (CardManmager.Instance == null) return;

        if (firstPlayerTurn)
        {
            CardManmager.Instance.DrawStartingHand();
        }
        else
        {
            CardManmager.Instance.DrawTurnHand();
        }
    }

    private bool ShouldAutoEndPlayerTurn()
    {
        if (!autoEndWhenNoEnergy && !autoEndWhenNoCards) return false;

        if (autoEndWhenNoEnergy && IsPlayerOutOfEnergy())
        {
            return true;
        }

        if (autoEndWhenNoCards && IsPlayerHandEmpty())
        {
            return true;
        }

        return false;
    }

    private bool IsPlayerOutOfEnergy()
    {
        if (BattleManager.Instance == null) return false;
        return BattleManager.Instance.currentEnergy <= 0;
    }

    private bool IsPlayerHandEmpty()
    {
        if (CardManmager.Instance == null) return false;
        return CardManmager.Instance.CurrentHandCount <= 0;
    }

    private bool IsBattleAlreadyEnded()
    {
        if (BattleManager.Instance == null) return false;
        return BattleManager.Instance.IsBattleEnded;
    }
}
