using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// 손패에 보이는 카드 1장을 담당합니다.
// 클릭, 마우스 올림 툴팁, 카드 UI 갱신 같은 "카드 오브젝트의 행동"이 여기 있습니다.
//
// 이 클래스는 카드의 실제 효과를 직접 계산하지 않습니다.
// 클릭 가능 여부 확인과 UI 표시만 담당하고, 능력 실행은 CardAbilityLibrary로 넘깁니다.
// 이렇게 나누면 "카드 버튼" 코드와 "전투 규칙" 코드가 섞이지 않아 읽기 쉬워집니다.
//
// 초심자용 핵심 개념:
// - MonoBehaviour는 Unity GameObject에 붙일 수 있는 스크립트입니다.
// - IPointerEnterHandler / IPointerExitHandler는 마우스가 카드 위에 올라가거나 벗어났을 때 호출됩니다.
// - RequireComponent(typeof(Button))은 이 스크립트가 붙는 오브젝트에 Button이 꼭 필요하다는 뜻입니다.
// - OnClickCard는 버튼 클릭 이벤트와 연결되는 함수입니다.
[RequireComponent(typeof(Button))]
public class Card : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler
{
    public CardDate data; // 인스펙터에서 할당

    // 아래 Text/Image 변수들은 카드 UI의 각 부분입니다.
    // CardManmager가 런타임 카드 UI를 만들 때 여기에 연결해 줍니다.
    public Text nameDisplay;
    public Text costDisplay;
    public Text powerDisplay;
    public Image artworkDisplay;

    private Button button;

    private void Awake()
    {
        // 이 카드 오브젝트의 Button 컴포넌트에 클릭 함수를 연결합니다.
        // RemoveAllListeners를 먼저 호출하는 이유는 중복 연결을 막기 위해서입니다.
        // 중복 연결되면 한 번 클릭했는데 효과가 두 번 실행될 수 있습니다.
        button = GetComponent<Button>();
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(OnClickCard);
    }

    private void Start()
    {
        RefreshView();
    }

    public void SetData(CardDate newData)
    {
        // CardManmager가 UI 카드를 만들 때 카드 데이터를 넣어주는 입구입니다.
        data = newData;
        RefreshView();
    }

    private void RefreshView()
    {
        // 카드 데이터에 맞춰 이름, 코스트, 공격력, 이미지를 화면에 표시합니다.
        if (data != null)
        {
            if (nameDisplay != null) nameDisplay.text = data.cardName;
            if (costDisplay != null) costDisplay.text = data.cost.ToString();
            if (powerDisplay != null) powerDisplay.text = data.power.ToString("F0");
            if (artworkDisplay != null && data.cardImage != null) artworkDisplay.sprite = data.cardImage;
        }
    }

    public void OnClickCard()
    {
        // 카드 클릭 시 실행됩니다.
        // 아래 순서대로 읽으면 됩니다:
        // 1. 이 카드를 지금 쓸 수 있는지 확인합니다.
        // 2. 기력이 충분하면 기력을 소비합니다.
        // 3. 카드 효과를 실행합니다.
        // 4. 손패에서 카드를 제거합니다.
        if (!CanUseThisCardNow()) return;

        if (!PayCardCost()) return;

        ExecuteEffect();
        RemoveThisCardFromHand();
    }

    private bool PayCardCost()
    {
        return BattleManager.Instance.TryUseEnergy(data.cost);
    }

    private bool CanUseThisCardNow()
    {
        // 카드 데이터와 전투 매니저가 없으면 카드를 사용할 수 없습니다.
        if (data == null) return false;
        if (BattleManager.Instance == null) return false;

        // 플레이어 턴이 아닐 때는 카드를 사용할 수 없습니다.
        if (TurnManager.Instance != null)
        {
            if (!TurnManager.Instance.IsPlayerTurn) return false;
        }

        // 필살기는 달의 기운이 가득 찼을 때만 사용할 수 있습니다.
        bool isUltimateCard = data.type == CardDate.CardType.Ultimate;
        bool hasFullMoonGauge = BattleManager.Instance.CanUseUltimate();
        if (isUltimateCard && !hasFullMoonGauge)
        {
            Debug.Log("달의 기운이 가득 차야 필살기를 사용할 수 있습니다.");
            return false;
        }

        return true;
    }

    private void ExecuteEffect()
    {
        // 실제 카드 효과 실행은 CardAbilityLibrary에 맡깁니다.
        // Card.cs는 클릭 처리만 하고, 능력 로직은 분리해둔 구조입니다.
        CardAbilityLibrary.Execute(data);
    }

    private void RemoveThisCardFromHand()
    {
        // CardManmager가 있으면 손패 정리와 턴 자동 종료 확인까지 맡깁니다.
        // 없으면 카드 오브젝트만 삭제합니다.
        if (CardManmager.Instance != null)
        {
            CardManmager.Instance.NotifyCardUsed(this);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        // 마우스를 카드 위에 올리면 카드 설명 툴팁을 띄웁니다.
        ShowTooltip();
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        // 빌드본이나 터치 입력에서는 hover가 없을 수 있으므로 누르는 순간에도 설명을 띄웁니다.
        ShowTooltip();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        // 마우스가 카드에서 벗어나면 툴팁을 숨깁니다.
        HideTooltip();
    }

    private void OnDisable()
    {
        HideTooltip();
    }

    private void ShowTooltip()
    {
        if (data != null && UIManager.Instance != null)
        {
            UIManager.Instance.ShowCardTooltip(data, transform.position);
        }
    }

    private void HideTooltip()
    {
        if (UIManager.Instance != null)
        {
            UIManager.Instance.HideCardTooltip();
        }
    }
}
