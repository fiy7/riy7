using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;
#if UNITY_EDITOR
using UnityEditor;
#endif

// 전투 씬에 필요한 UI와 매니저 오브젝트를 런타임에 자동 생성하는 부트스트랩입니다.
//
// 원래 Unity UI는 씬에서 직접 배치하는 경우가 많지만,
// 이 프로젝트는 전투 화면을 코드로 생성해서 씬에 필요한 오브젝트가 비어 있어도 실행되게 만듭니다.
//
// 이 파일이 만드는 것:
// - Canvas / EventSystem
// - 전투 배경, 플레이어/적 앵커, HP바
// - 기력/달 게이지 UI
// - 손패 패널, 덱 앵커, 턴 종료 버튼
// - 설정창, 카드 툴팁, 게임오버 패널
// - BattleManager, UIManager, BattleVisualManager, CardManmager, TurnManager
//
// 읽을 때 팁:
// Build 함수가 전체 조립 순서이고,
// Create... 함수들은 각각 UI 조각을 만드는 작은 공장 함수라고 보면 됩니다.
//
// 초심자용 핵심 개념:
// - Canvas는 Unity UI가 그려지는 큰 도화지입니다.
// - RectTransform은 UI의 위치와 크기를 정하는 컴포넌트입니다.
// - anchorMin/anchorMax는 "부모 기준 어디에 붙을지"를 정합니다.
// - anchoredPosition은 앵커 기준으로 얼마나 떨어질지 정합니다.
// - sizeDelta는 UI 크기 또는 늘어난 영역에서 추가/감소할 크기입니다.
// - Ensure...로 시작하는 함수는 "있으면 재사용하고 없으면 만든다"는 뜻으로 보면 됩니다.
//
// 왜 코드로 UI를 만들까?
// - 씬에 UI를 직접 배치하지 않아도 전투 화면이 자동으로 구성됩니다.
// - 테스트 씬, private 씬, fight 씬처럼 여러 씬에서 같은 전투 UI를 재사용하기 쉽습니다.
// - 대신 코드가 길어지므로, 각 Create 함수의 역할을 나눠 읽는 것이 중요합니다.
public class BattleSceneBootstrap : MonoBehaviour
{
    //전체의 전투 UI를 한번 자동 생성하는 코드입니다 다회성으로 쓰기 좋은 코드 이지만 꼬이면 쓰기 어려줘 지는 코드입니다 
    private static bool didBootstrap;
    private static bool didSubscribeSceneLoaded;

    private void Awake()
    {
        if (didBootstrap && Find<BattleManager>() != null) return;

        didBootstrap = true;
        Build();
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void RegisterSceneLoadedBootstrap()
    {
        // RuntimeInitializeOnLoadMethod는 게임 시작 때의 초기화에는 좋지만,
        // startstory -> BattleScene처럼 나중에 씬을 로드할 때 자동 UI 생성 코드가 다시 안 돌 수 있습니다.
        // sceneLoaded 이벤트에 등록하면 씬이 바뀔 때마다 BootstrapCurrentScene을 확실히 실행할 수 있습니다.
        if (didSubscribeSceneLoaded) return;

        didSubscribeSceneLoaded = true;
        UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void BootstrapCurrentScene()
    {
        TryBootstrapBattleScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name);
    }

    private static void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
    {
        // 버튼이나 스토리 종료로 BattleScene이 새로 열릴 때마다 호출됩니다.
        // 그래서 전투 UI와 BattleManager가 다음 씬에서도 다시 살아납니다.
        TryBootstrapBattleScene(scene.name);
    }

    private static void TryBootstrapBattleScene(string loadedSceneName)
    {
        string sceneName = loadedSceneName.ToLower();
        bool looksLikeBattleScene = sceneName.Contains("battle") || sceneName.Contains("figth") || sceneName.Contains("fight") || sceneName.Contains("private");

        // BattleScene -> startstory -> BattleScene처럼 씬을 왕복할 때를 위한 처리입니다.
        // 전투 씬이 아닌 곳으로 나가면 didBootstrap을 false로 돌려서,
        // 나중에 BattleScene에 다시 들어왔을 때 전투 UI가 다시 생성될 수 있게 합니다.
        if (!looksLikeBattleScene && Find<BattleManager>() == null)
        {
            didBootstrap = false;
            return;
        }

        if (didBootstrap && Find<BattleManager>() != null) return;
        if (Find<BattleSceneBootstrap>() != null && Find<BattleManager>() != null)
        {
            didBootstrap = true;
            return;
        }

        didBootstrap = true;
        GameObject bootstrapObject = new GameObject("BattleSceneBootstrap");
        bootstrapObject.AddComponent<BattleSceneBootstrap>().Build();
    }

    private void Build()
    {
        // Build는 전투 화면을 실제로 조립하는 중심 함수입니다.
        // 위에서부터 아래로 읽으면 화면의 큰 구조가 만들어지는 순서를 따라갈 수 있습니다.
        Canvas canvas = EnsureCanvas();
        EnsureEventSystem();

        Transform root = EnsureChild(canvas.transform, "Auto Battle UI", typeof(RectTransform));
        RectTransform rootRect = root.GetComponent<RectTransform>();
        Stretch(rootRect);

        Image battlefieldBackground = CreateBattleBackground(root);

        Transform topBar = EnsurePanel(root, "Top Bar", new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0f, -42f), new Vector2(-48f, 72f));
        topBar.GetComponent<Image>().color = new Color(0.025f, 0.03f, 0.04f, 0.88f);
        HorizontalLayoutGroup topLayout = EnsureComponent<HorizontalLayoutGroup>(topBar.gameObject);
        topLayout.childAlignment = TextAnchor.MiddleCenter;
        topLayout.spacing = 24f;
        topLayout.childForceExpandWidth = false;
        topLayout.childForceExpandHeight = false;

        Text energyText = CreateLabel(topBar, "Energy Text", "기력 0 / 7", 24, new Vector2(140f, 42f));
        Transform energyGems = CreateRow(topBar, "Energy Gems", new Vector2(132f, 32f));
        Text moonText = CreateLabel(topBar, "Moon Text", "달 0%", 24, new Vector2(120f, 42f));
        Transform moonGems = CreateRow(topBar, "Moon Gems", new Vector2(132f, 32f));
        Text turnCountText = CreateLabel(topBar, "Turn Count Text", "턴 1", 24, new Vector2(110f, 42f));

        CreateBattlefield(root, out RectTransform playerAnchor, out RectTransform[] enemyAnchors, out Image[] enemyImages, out Text[] enemyNameTexts, out Transform effectParent, out Slider playerSlider, out Text playerText, out Slider[] enemySliders, out Text[] enemyTexts);
        Text turnText = CreateTurnNotice(root);

        UIManager uiManager = Find<UIManager>();
        if (uiManager == null) uiManager = new GameObject("UIManager").AddComponent<UIManager>();

        GameObject gameOverPanel = CreateGameOverPanel(root, LoadGameOverFontAsset());
        gameOverPanel.SetActive(false);
        GameObject tooltipPanel = CreateCardTooltip(root, out Text tooltipText);
        tooltipPanel.SetActive(false);
        GameObject settingsPanel = CreateSettingsPanel(root);
        settingsPanel.SetActive(false);
        CreateSettingsButton(root, settingsPanel);
        GameObject cardGuidePanel = CreateCardGuidePanel(root);
        cardGuidePanel.SetActive(false);
        CreateCardGuideButton(root, cardGuidePanel);
        GameObject enemyGuidePanel = CreateEnemyGuidePanel(root, out Text enemyGuideText);
        enemyGuidePanel.SetActive(false);
        CreateEnemyGuideButton(root, enemyGuidePanel, enemyGuideText);

        Transform commandTray = EnsurePanel(root, "Command Tray", new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(-44f, 142f), new Vector2(1780f, 372f));
        commandTray.GetComponent<Image>().color = new Color(0.035f, 0.038f, 0.052f, 0.88f);

        Transform handPanel = EnsurePanel(root, "Hand Panel", new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(-44f, 142f), new Vector2(1700f, 336f));
        handPanel.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0f);
        HorizontalLayoutGroup handLayout = EnsureComponent<HorizontalLayoutGroup>(handPanel.gameObject);
        handLayout.childAlignment = TextAnchor.MiddleCenter;
        handLayout.spacing = 20f;
        handLayout.padding.left = 24;
        handLayout.padding.right = 24;
        handLayout.childForceExpandWidth = false;
        handLayout.childForceExpandHeight = false;

        Transform deckAnchor = EnsurePanel(root, "Deck Anchor", new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(118f, 148f), new Vector2(96f, 142f));
        Image deckImage = EnsureComponent<Image>(deckAnchor.gameObject);
        deckImage.color = new Color(0f, 0f, 0f, 0f);
        deckImage.raycastTarget = false;

        CreateEndTurnButton(root);

        GameObject gemPrefab = CreateGemPrefab(root);
        Sprite activeGem = CreateSprite(new Color(0.1f, 0.9f, 0.75f));
        Sprite inactiveGem = CreateSprite(new Color(0.18f, 0.18f, 0.2f));

        uiManager.ConfigureRuntimeUI(energyText, moonText, turnCountText, enemySliders[0], enemyTexts[0], playerSlider, playerText, turnText, gameOverPanel, tooltipPanel, tooltipText, gemPrefab, energyGems, gemPrefab, moonGems, activeGem, inactiveGem);
        uiManager.ConfigureEnemyPartyUI(enemySliders, enemyTexts);

        BattleVisualManager visualManager = Find<BattleVisualManager>();
        if (visualManager == null) visualManager = new GameObject("BattleVisualManager").AddComponent<BattleVisualManager>();
        visualManager.Configure(playerAnchor, enemyAnchors, enemyImages, enemyNameTexts, battlefieldBackground, effectParent);

        CardManmager cardManager = Find<CardManmager>();
        if (cardManager == null) cardManager = new GameObject("CardManmager").AddComponent<CardManmager>();
        cardManager.Configure(handPanel, deckAnchor);

        if (Find<TurnManager>() == null)
        {
            new GameObject("TurnManager").AddComponent<TurnManager>();
        }

        if (Find<BattleManager>() == null)
        {
            new GameObject("BattleManager").AddComponent<BattleManager>();
        }
    }

    private Canvas EnsureCanvas()
    {
        // UI는 Canvas 아래에 있어야 화면에 보입니다.
        // 이미 씬에 Canvas가 있다면 재사용하고, 없다면 새로 만듭니다.
        Canvas canvas = Find<Canvas>();
        if (canvas != null) return canvas;

        GameObject canvasObject = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;

        return canvas;
    }

    private void EnsureEventSystem()
    {
        if (Find<EventSystem>() != null) return;

        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
    }

    private Transform EnsureChild(Transform parent, string objectName, params System.Type[] components)
    {
        // 같은 이름의 자식이 있으면 재사용하고, 없으면 새로 만듭니다.
        // 런타임 부트스트랩은 여러 번 호출될 수 있으므로 중복 생성을 막는 것이 중요합니다.
        Transform child = parent.Find(objectName);
        if (child != null) return child;

        GameObject go = new GameObject(objectName, components);
        go.transform.SetParent(parent, false);
        return go.transform;
    }

    private Transform EnsurePanel(Transform parent, string objectName, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
    {
        // Image가 붙은 기본 UI 패널을 만드는 helper입니다.
        // anchorMin/anchorMax/anchoredPosition/sizeDelta는 RectTransform 배치를 결정합니다.
        Transform panel = EnsureChild(parent, objectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        RectTransform rect = panel.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = sizeDelta;

        Image image = panel.GetComponent<Image>();
        image.color = new Color(0f, 0f, 0f, 0f);

        return panel;
    }

    private Text CreateLabel(Transform parent, string objectName, string value, int size, Vector2 layoutSize)
    {
        Transform existing = parent.Find(objectName);
        Text text;
        if (existing == null)
        {
            GameObject go = new GameObject(objectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text), typeof(LayoutElement));
            go.transform.SetParent(parent, false);
            text = go.GetComponent<Text>();
        }
        else
        {
            text = existing.GetComponent<Text>();
        }

        LayoutElement layout = text.GetComponent<LayoutElement>();
        layout.preferredWidth = layoutSize.x;
        layout.preferredHeight = layoutSize.y;

        text.text = value;
        text.font = GetBuiltinFont();
        text.fontSize = size;
        text.alignment = TextAnchor.MiddleCenter;
        ReadableTextStyle.Apply(text);
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 12;
        text.resizeTextMaxSize = size;

        return text;
    }

    private Transform CreateRow(Transform parent, string objectName, Vector2 layoutSize)
    {
        Transform row = EnsureChild(parent, objectName, typeof(RectTransform), typeof(LayoutElement), typeof(HorizontalLayoutGroup));
        LayoutElement layout = row.GetComponent<LayoutElement>();
        layout.preferredWidth = layoutSize.x;
        layout.preferredHeight = layoutSize.y;

        HorizontalLayoutGroup group = row.GetComponent<HorizontalLayoutGroup>();
        group.childAlignment = TextAnchor.MiddleCenter;
        group.spacing = 6f;
        group.childForceExpandWidth = false;
        group.childForceExpandHeight = false;

        return row;
    }

    private Slider CreateHPBar(Transform root, string objectName, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Color fillColor, out Text hpText)
    {
        Transform holder = EnsurePanel(root, objectName, anchorMin, anchorMax, anchoredPosition, new Vector2(520f, 58f));
        Slider slider = EnsureComponent<Slider>(holder.gameObject);
        slider.transition = Selectable.Transition.None;
        slider.interactable = false;
        slider.minValue = 0f;
        slider.maxValue = 1f;
        slider.value = 1f;

        Transform background = EnsurePanel(holder, "Background", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        background.GetComponent<Image>().color = new Color(0.22f, 0.08f, 0.1f, 0.95f);

        Transform fillArea = EnsureChild(holder, "Fill Area", typeof(RectTransform));
        Stretch(fillArea.GetComponent<RectTransform>());

        Transform fill = EnsurePanel(fillArea, "Fill", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        fill.GetComponent<Image>().color = fillColor;

        slider.fillRect = fill.GetComponent<RectTransform>();
        slider.targetGraphic = fill.GetComponent<Image>();
        hpText = CreateAbsoluteText(holder, "HP Text", "120 / 120", 24, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);

        return slider;
    }

    private Text CreateTurnNotice(Transform root)
    {
        Text text = CreateAbsoluteText(root, "Turn Notice", "", 44, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(520f, 92f));
        text.gameObject.SetActive(false);
        return text;
    }

    private GameObject CreateGameOverPanel(Transform root, TMP_FontAsset fontAsset)
    {
        Transform panel = EnsurePanel(root, "Game Over Panel", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        panel.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.72f);
        CreateGameOverText(panel, "Result Text", "", 48, fontAsset);
        return panel.gameObject;
    }

    private TMP_Text CreateGameOverText(Transform parent, string objectName, string value, int size, TMP_FontAsset fontAsset)
    {
        Transform existing = parent.Find(objectName);
        TextMeshProUGUI text;
        if (existing == null)
        {
            GameObject go = new GameObject(objectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            go.transform.SetParent(parent, false);
            text = go.GetComponent<TextMeshProUGUI>();
        }
        else
        {
            text = existing.GetComponent<TextMeshProUGUI>();
            if (text == null) text = existing.gameObject.AddComponent<TextMeshProUGUI>();
        }

        RectTransform rect = text.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.anchoredPosition = Vector2.zero;
        rect.sizeDelta = Vector2.zero;

        text.text = value;
        if (fontAsset != null) text.font = fontAsset;
        text.fontSize = size;
        text.alignment = TextAlignmentOptions.Center;
        text.color = Color.white;
        text.enableAutoSizing = true;
        text.fontSizeMin = 18f;
        text.fontSizeMax = size;
        text.raycastTarget = false;
        ReadableTextStyle.Apply(text);

        return text;
    }

    private GameObject CreateCardTooltip(Transform root, out Text tooltipText)
    {
        Transform panel = EnsurePanel(root, "Card Tooltip", new Vector2(0f, 0f), new Vector2(0f, 0f), Vector2.zero, new Vector2(460f, 220f));
        Image image = EnsureComponent<Image>(panel.gameObject);
        CelestialUiAssets.ApplyBody(image);
        image.raycastTarget = false;
        tooltipText = CreateAbsoluteText(panel, "Tooltip Text", "", 18, TextAnchor.UpperLeft, new Vector2(0f, 0f), new Vector2(1f, 1f), Vector2.zero, new Vector2(-28f, -24f));
        tooltipText.raycastTarget = false;
        RectTransform textRect = tooltipText.GetComponent<RectTransform>();
        textRect.offsetMin = new Vector2(16f, 12f);
        textRect.offsetMax = new Vector2(-16f, -12f);
        return panel.gameObject;
    }

    private void CreateCardGuideButton(Transform root, GameObject guidePanel)
    {
        // 카드 설명을 한 번에 볼 수 있는 버튼입니다.
        Transform buttonTransform = EnsurePanel(root, "Card Guide Button", new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-198f, -42f), new Vector2(112f, 48f));
        Button button = CreateStyledButton(buttonTransform);
        button.onClick.AddListener(() =>
        {
            if (guidePanel != null)
            {
                guidePanel.transform.SetAsLastSibling();
                guidePanel.SetActive(true);
            }
        });

        Text label = CreateAbsoluteText(buttonTransform, "Label", "성좌", 22, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        label.raycastTarget = false;
    }

    private void CreateEnemyGuideButton(Transform root, GameObject guidePanel, Text guideText)
    {
        Transform buttonTransform = EnsurePanel(root, "Enemy Guide Button", new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-318f, -42f), new Vector2(112f, 48f));
        Button button = CreateStyledButton(buttonTransform);
        button.onClick.AddListener(() =>
        {
            if (guidePanel == null) return;

            if (guideText != null)
            {
                guideText.text = BattleManager.Instance != null
                    ? BattleManager.Instance.GetCurrentEnemyGuideText()
                    : BuildFallbackEnemyGuideText();
            }

            guidePanel.transform.SetAsLastSibling();
            guidePanel.SetActive(true);
        });

        Text label = CreateAbsoluteText(buttonTransform, "Label", "적 기록", 19, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        label.raycastTarget = false;
    }

    private Button CreateStyledButton(Transform buttonTransform)
    {
        Image image = EnsureComponent<Image>(buttonTransform.gameObject);
        CelestialUiAssets.ApplyButton(image);

        Button button = EnsureComponent<Button>(buttonTransform.gameObject);
        CelestialUiAssets.ConfigureButton(button, image);
        button.onClick.RemoveAllListeners();
        return button;
    }

    private void CreateCelestialDivider(Transform parent, string objectName, Vector2 anchoredPosition, Vector2 sizeDelta)
    {
        Transform divider = EnsurePanel(parent, objectName, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), anchoredPosition, sizeDelta);
        Image image = EnsureComponent<Image>(divider.gameObject);
        CelestialUiAssets.ApplyDivider(image);
        image.raycastTarget = false;
    }

    private GameObject CreateCardGuidePanel(Transform root)
    {
        // 카드 설명을 한 창에 모아서 보여주는 패널입니다.
        Transform overlay = EnsurePanel(root, "Card Guide Panel", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        overlay.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.58f);

        Transform window = EnsurePanel(overlay, "Card Guide Window", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(820f, 760f));
        Image windowImage = EnsureComponent<Image>(window.gameObject);
        CelestialUiAssets.ApplyWindow(windowImage);

        CreateAbsoluteText(window, "Title", "성좌 카드 기록", 34, TextAnchor.MiddleCenter, new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0f, -48f), new Vector2(0f, 54f));
        CreateCelestialDivider(window, "Title Divider", new Vector2(0f, -86f), new Vector2(560f, 42f));

        CreateCardGuideScrollView(window);

        Transform closeButtonTransform = EnsurePanel(window, "Close Button", new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 42f), new Vector2(150f, 48f));
        Button closeButton = CreateStyledButton(closeButtonTransform);
        closeButton.onClick.AddListener(() => overlay.gameObject.SetActive(false));

        Text closeLabel = CreateAbsoluteText(closeButtonTransform, "Label", "닫기", 24, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        closeLabel.raycastTarget = false;

        return overlay.gameObject;
    }

    private GameObject CreateEnemyGuidePanel(Transform root, out Text guideText)
    {
        Transform overlay = EnsurePanel(root, "Enemy Guide Panel", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        overlay.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.58f);

        Transform window = EnsurePanel(overlay, "Enemy Guide Window", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(760f, 620f));
        Image windowImage = EnsureComponent<Image>(window.gameObject);
        CelestialUiAssets.ApplyWindow(windowImage);

        CreateAbsoluteText(window, "Title", "타락한 별 기록", 34, TextAnchor.MiddleCenter, new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0f, -48f), new Vector2(0f, 54f));
        CreateCelestialDivider(window, "Title Divider", new Vector2(0f, -86f), new Vector2(590f, 42f));

        Transform body = EnsurePanel(window, "Body", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        RectTransform bodyRect = body.GetComponent<RectTransform>();
        bodyRect.offsetMin = new Vector2(48f, 96f);
        bodyRect.offsetMax = new Vector2(-48f, -106f);
        CelestialUiAssets.ApplyBody(body.GetComponent<Image>());

        guideText = CreateAbsoluteText(body, "Guide Text", BuildFallbackEnemyGuideText(), 22, TextAnchor.UpperLeft, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        RectTransform guideRect = guideText.GetComponent<RectTransform>();
        guideRect.offsetMin = new Vector2(24f, 22f);
        guideRect.offsetMax = new Vector2(-24f, -22f);
        guideText.horizontalOverflow = HorizontalWrapMode.Wrap;
        guideText.verticalOverflow = VerticalWrapMode.Overflow;
        guideText.resizeTextForBestFit = false;
        guideText.raycastTarget = false;

        Transform closeButtonTransform = EnsurePanel(window, "Close Button", new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 42f), new Vector2(150f, 48f));
        Button closeButton = CreateStyledButton(closeButtonTransform);
        closeButton.onClick.AddListener(() => overlay.gameObject.SetActive(false));

        Text closeLabel = CreateAbsoluteText(closeButtonTransform, "Label", "닫기", 24, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        closeLabel.raycastTarget = false;

        return overlay.gameObject;
    }

    private void CreateCardGuideScrollView(Transform window)
    {
        // 긴 카드 설명을 위아래로 내려볼 수 있는 스크롤 영역입니다.
        Transform scrollView = EnsurePanel(window, "Guide Scroll View", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 8f), new Vector2(710f, 520f));

        Image scrollImage = EnsureComponent<Image>(scrollView.gameObject);
        CelestialUiAssets.ApplyBody(scrollImage);

        ScrollRect scrollRect = EnsureComponent<ScrollRect>(scrollView.gameObject);
        scrollRect.horizontal = false;
        scrollRect.vertical = true;
        scrollRect.movementType = ScrollRect.MovementType.Clamped;
        scrollRect.scrollSensitivity = 34f;

        Transform viewport = EnsurePanel(scrollView, "Viewport", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        RectTransform viewportRect = viewport.GetComponent<RectTransform>();
        viewportRect.offsetMin = new Vector2(28f, 28f);
        viewportRect.offsetMax = new Vector2(-56f, -28f);

        Image viewportImage = EnsureComponent<Image>(viewport.gameObject);
        viewportImage.color = new Color(1f, 1f, 1f, 0.01f);
        Mask viewportMask = EnsureComponent<Mask>(viewport.gameObject);
        viewportMask.showMaskGraphic = false;

        Transform content = EnsureChild(viewport, "Content", typeof(RectTransform));
        RectTransform contentRect = content.GetComponent<RectTransform>();
        contentRect.anchorMin = new Vector2(0f, 1f);
        contentRect.anchorMax = new Vector2(1f, 1f);
        contentRect.pivot = new Vector2(0.5f, 1f);
        contentRect.anchoredPosition = new Vector2(0f, -10f);
        contentRect.sizeDelta = new Vector2(0f, 2300f);

        Text guideText = CreateAbsoluteText(content, "Guide Text", BuildCardGuideText(), 17, TextAnchor.UpperLeft, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        RectTransform guideRect = guideText.GetComponent<RectTransform>();
        guideRect.offsetMin = new Vector2(0f, 0f);
        guideRect.offsetMax = new Vector2(-8f, -4f);
        guideText.horizontalOverflow = HorizontalWrapMode.Wrap;
        guideText.verticalOverflow = VerticalWrapMode.Overflow;
        guideText.resizeTextForBestFit = false;
        guideText.lineSpacing = 1.06f;
        guideText.raycastTarget = false;

        Transform scrollbarTransform = EnsurePanel(scrollView, "Vertical Scrollbar", new Vector2(1f, 0f), new Vector2(1f, 1f), new Vector2(-8f, 0f), new Vector2(16f, -4f));
        Image scrollbarImage = EnsureComponent<Image>(scrollbarTransform.gameObject);
        CelestialUiAssets.ApplySliderTrack(scrollbarImage);

        Scrollbar scrollbar = EnsureComponent<Scrollbar>(scrollbarTransform.gameObject);
        scrollbar.direction = Scrollbar.Direction.BottomToTop;

        Transform slidingArea = EnsureChild(scrollbarTransform, "Sliding Area", typeof(RectTransform));
        Stretch(slidingArea.GetComponent<RectTransform>());

        Transform handle = EnsurePanel(slidingArea, "Handle", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        Image handleImage = EnsureComponent<Image>(handle.gameObject);
        CelestialUiAssets.ApplySliderFill(handleImage);

        scrollbar.handleRect = handle.GetComponent<RectTransform>();
        scrollbar.targetGraphic = handleImage;

        scrollRect.viewport = viewportRect;
        scrollRect.content = contentRect;
        scrollRect.verticalScrollbar = scrollbar;
        scrollRect.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.Permanent;
        scrollRect.verticalNormalizedPosition = 1f;
    }

    private string BuildCardGuideText()
    {
        return
            "연성 방법\n" +
            CardFusionLibrary.FusionRuleIntro + "\n" +
            "연성은 인접한 두 카드만 봅니다. 예를 들어 양자리 다음에 황소자리를 바로 쓰면 성각돌진이 발동하고, 그 다음 카드는 황소자리를 기준으로 다시 연성이 이어집니다.\n\n" +
            "카드 기본 효과\n" +
            "양자리 / 비용 1 / 단일 공격: 선택한 적 하나에게 안정적인 피해를 줍니다.\n" +
            "황소자리 / 비용 2 / 단일 강타: 선택한 적 하나에게 높은 피해를 줍니다.\n" +
            "쌍둥이자리 / 비용 1 / 방어: 방어막 30을 얻어 적 턴의 피해를 받아냅니다.\n" +
            "게자리 / 비용 3 / 전체 공격: 모든 적을 한 번에 공격합니다.\n" +
            "사자자리 / 비용 2 / 기억의 일격: 직전 플레이어 턴의 가장 강한 공격을 증폭해 다시 사용합니다.\n" +
            "처녀자리 / 비용 2 / 방어와 정화: 단일 피해를 제한하고 위험한 독성 상태를 정리합니다.\n" +
            "천칭자리 / 비용 2 / 공격 강화: 2턴 동안 공격 버프 2중첩을 얻습니다.\n" +
            "전갈자리 / 비용 2 / 독 공격: 선택한 적에게 피해와 독을 남깁니다.\n" +
            "사수자리 / 비용 3 / 달 100% 필살기: 모든 적에게 큰 피해를 주고 풍화를 겁니다.\n" +
            "염소자리 / 비용 2 / 성장형 전체 공격: 모든 적을 공격하고 사용할수록 피해가 커집니다.\n" +
            "물병자리 / 비용 0 / 기력 회복: 한 턴에 한 번 기력을 회복합니다.\n" +
            "물고기자리 / 비용 2 / 회복과 강화: 기력과 체력을 회복하고 다음 공격을 강화합니다.\n\n" +
            CardFusionLibrary.BuildFusionGuideText();
    }

    private string BuildFallbackEnemyGuideText()
    {
        return
            "공허의 울음꾼\n무리로 남으면 공허의 합창으로 다음 턴 기력을 깎습니다. 수를 줄이면 압박이 약해집니다.\n\n" +
            "탁한 별가루 집행자\n살아있는 수가 많을수록 정화 방진으로 피해를 덜 받습니다. 한 마리씩 줄이면 방진이 무너집니다.\n\n" +
            "타락한 황도13궁 전갈\n천무독은 최대체력 비율 피해를 주며, 스택이 완성되면 즉사합니다. 장기전이 가장 위험합니다.\n\n" +
            "별의 대적자\n별핵을 충전하다가 별무리 유성우를 사용합니다. 유성우 전에 방어막과 피해 제한을 준비해야 합니다.";
    }

    private void CreateSettingsButton(Transform root, GameObject settingsPanel)
    {
        // 오른쪽 위 설정 버튼입니다. 누르면 아래 CreateSettingsPanel에서 만든 창을 켜고 끕니다.
        Transform buttonTransform = EnsurePanel(root, "Settings Button", new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-78f, -42f), new Vector2(112f, 48f));
        Button button = CreateStyledButton(buttonTransform);
        button.onClick.AddListener(() =>
        {
            if (settingsPanel != null)
            {
                settingsPanel.transform.SetAsLastSibling();
                settingsPanel.SetActive(true);
            }
        });

        Text label = CreateAbsoluteText(buttonTransform, "Label", "설정", 22, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        label.raycastTarget = false;
    }

    private GameObject CreateSettingsPanel(Transform root)
    {
        // 설정창 전체 배경입니다. 반투명 검은 막을 깔아서 전투 화면 위에 창이 뜬 것처럼 보이게 합니다.
        Transform overlay = EnsurePanel(root, "Settings Panel", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        overlay.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.58f);

        Transform window = EnsurePanel(overlay, "Settings Window", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(620f, 430f));
        Image windowImage = EnsureComponent<Image>(window.gameObject);
        CelestialUiAssets.ApplyWindow(windowImage);

        CreateAbsoluteText(window, "Title", "성좌 설정", 34, TextAnchor.MiddleCenter, new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0f, -48f), new Vector2(0f, 54f));
        CreateCelestialDivider(window, "Title Divider", new Vector2(0f, -86f), new Vector2(500f, 42f));
        CreateSettingSlider(window, "BGM Volume", "별빛 음악", new Vector2(0f, 80f));
        CreateSettingSlider(window, "SFX Volume", "전투 음향", new Vector2(0f, 8f));
        CreateQualitySettingButton(window, new Vector2(0f, -64f));
        CreateAbsoluteText(window, "Guide", "별빛의 흐름과 전투 화면을 조율합니다.", 20, TextAnchor.MiddleCenter, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 106f), new Vector2(500f, 42f));

        Transform closeButtonTransform = EnsurePanel(window, "Close Button", new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 44f), new Vector2(180f, 54f));
        Button closeButton = CreateStyledButton(closeButtonTransform);
        closeButton.onClick.AddListener(() =>
        {
            overlay.gameObject.SetActive(false);
        });

        Text closeLabel = CreateAbsoluteText(closeButtonTransform, "Label", "닫기", 24, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        closeLabel.raycastTarget = false;

        return overlay.gameObject;
    }

    private void CreateQualitySettingButton(Transform parent, Vector2 anchoredPosition)
    {
        // 전투 중 설정창에서 그래픽 품질을 바꾸기 위한 행입니다.
        // 이 프로젝트의 전투 설정창은 런타임에 코드로 만들어지므로,
        // Dropdown 프리팹을 따로 준비하지 않고 버튼을 누를 때마다 품질이 순서대로 바뀌는 방식으로 구성했습니다.
        Transform row = EnsurePanel(parent, "Quality Setting", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), anchoredPosition, new Vector2(500f, 56f));
        CreateAbsoluteText(row, "Label", "그래픽", 22, TextAnchor.MiddleLeft, new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(62f, 0f), new Vector2(120f, 48f));

        Transform buttonTransform = EnsurePanel(row, "Quality Button", new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(-120f, 0f), new Vector2(190f, 44f));
        Button button = CreateStyledButton(buttonTransform);

        Text valueText = CreateAbsoluteText(buttonTransform, "Value", GetQualityLabel(GetSavedQualityIndex()), 20, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        valueText.raycastTarget = false;

        // 버튼을 누르면 현재 품질 인덱스에 1을 더하고, 마지막 품질 다음에는 다시 처음으로 돌아갑니다.
        // 예: 낮음 -> 보통 -> 높음 -> 낮음
        button.onClick.AddListener(() =>
        {
            int nextQuality = (GetSavedQualityIndex() + 1) % GetQualityCount();
            SetRuntimeQuality(nextQuality);
            valueText.text = GetQualityLabel(nextQuality);
        });

        SetRuntimeQuality(GetSavedQualityIndex());
    }

    private int GetQualityCount()
    {
        // Unity 프로젝트 설정에 품질 단계가 몇 개 있는지 확인합니다.
        // 혹시 품질 단계가 하나도 없는 비정상 상황에서도 나눗셈 오류가 나지 않게 최소 1을 반환합니다.
        return RuntimeGraphicsQuality.QualityCount;
    }

    private int GetSavedQualityIndex()
    {
        // PlayerPrefs는 이전에 선택한 그래픽 품질을 저장하는 작은 로컬 저장소입니다.
        // 저장된 값이 없으면 현재 Unity 품질 값을 기본값으로 사용합니다.
        return RuntimeGraphicsQuality.GetSavedQualityIndex();
    }

    private string GetQualityLabel(int qualityIndex)
    {
        return RuntimeGraphicsQuality.GetQualityLabel(qualityIndex);
    }

    private void SetRuntimeQuality(int qualityIndex)
    {
        RuntimeGraphicsQuality.Apply(qualityIndex);
    }

    private void CreateSettingSlider(Transform parent, string objectName, string label, Vector2 anchoredPosition)
    {
        // 전투 중 설정창에서 바로 조절할 수 있는 슬라이더입니다.
        // 배경음 슬라이더는 GlobalBgmManager와 연결되어 실제 BGM 볼륨을 바꿉니다.
        Transform row = EnsurePanel(parent, objectName, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), anchoredPosition, new Vector2(500f, 56f));
        CreateAbsoluteText(row, "Label", label, 22, TextAnchor.MiddleLeft, new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(62f, 0f), new Vector2(120f, 48f));

        Transform sliderTransform = EnsurePanel(row, "Slider", new Vector2(0f, 0.5f), new Vector2(1f, 0.5f), new Vector2(110f, 0f), new Vector2(-150f, 28f));
        Slider slider = EnsureComponent<Slider>(sliderTransform.gameObject);
        slider.minValue = 0f;
        slider.maxValue = 1f;
        slider.value = GetSavedSliderValue(objectName);

        Transform background = EnsurePanel(sliderTransform, "Background", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        CelestialUiAssets.ApplySliderTrack(background.GetComponent<Image>());

        Transform fillArea = EnsureChild(sliderTransform, "Fill Area", typeof(RectTransform));
        RectTransform fillAreaRect = fillArea.GetComponent<RectTransform>();
        fillAreaRect.anchorMin = Vector2.zero;
        fillAreaRect.anchorMax = Vector2.one;
        fillAreaRect.offsetMin = new Vector2(6f, 6f);
        fillAreaRect.offsetMax = new Vector2(-6f, -6f);

        Transform fill = EnsurePanel(fillArea, "Fill", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        CelestialUiAssets.ApplySliderFill(fill.GetComponent<Image>());

        Transform handleArea = EnsureChild(sliderTransform, "Handle Slide Area", typeof(RectTransform));
        Stretch(handleArea.GetComponent<RectTransform>());

        Transform handle = EnsurePanel(handleArea, "Handle", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(28f, 34f));
        CelestialUiAssets.ApplySliderHandle(handle.GetComponent<Image>());

        slider.fillRect = fill.GetComponent<RectTransform>();
        slider.handleRect = handle.GetComponent<RectTransform>();
        slider.targetGraphic = handle.GetComponent<Image>();

        if (objectName == "BGM Volume")
        {
            slider.onValueChanged.RemoveAllListeners();
            slider.onValueChanged.AddListener(GlobalBgmManager.SetVolume);
        }
        else if (objectName == "SFX Volume")
        {
            slider.onValueChanged.RemoveAllListeners();
            slider.onValueChanged.AddListener(value =>
            {
                PlayerPrefs.SetFloat("SFXVolume", value);
                PlayerPrefs.Save();
            });
        }
    }

    private float GetSavedSliderValue(string objectName)
    {
        if (objectName == "BGM Volume") return PlayerPrefs.GetFloat("Volume", 0.75f);
        if (objectName == "SFX Volume") return PlayerPrefs.GetFloat("SFXVolume", 0.75f);

        return 0.75f;
    }

    private Image CreateBattleBackground(Transform root)
    {
        // 전투 배경은 화면 전체에 깔립니다.
        // 적이 바뀔 때 BattleVisualManager가 이 Image의 sprite를 교체합니다.
        Transform background = EnsurePanel(root, "Enemy Background", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        background.SetAsFirstSibling();
        Image image = background.GetComponent<Image>();
        image.color = new Color(1f, 1f, 1f, 0.9f);
        image.preserveAspect = false;
        image.raycastTarget = false;

        Transform shade = EnsurePanel(root, "Enemy Background Shade", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        shade.SetSiblingIndex(1);
        Image shadeImage = shade.GetComponent<Image>();
        shadeImage.color = new Color(0f, 0f, 0f, 0.24f);
        shadeImage.raycastTarget = false;

        return image;
    }

    private void CreateBattlefield(Transform root, out RectTransform playerAnchor, out RectTransform[] enemyAnchors, out Image[] enemyImages, out Text[] enemyNameTexts, out Transform effectParent, out Slider playerSlider, out Text playerText, out Slider[] enemySliders, out Text[] enemyTexts)
    {
        // 실제 전투 배우가 서 있는 영역입니다.
        // playerAnchor와 enemyAnchors는 공격 모션, 피해 숫자, 이펙트 위치의 기준점으로도 사용됩니다.
        Transform field = EnsurePanel(root, "Battlefield", new Vector2(0f, 0.30f), new Vector2(1f, 0.86f), Vector2.zero, Vector2.zero);
        field.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0f);

        effectParent = EnsureChild(field, "Effects", typeof(RectTransform));
        Stretch(effectParent.GetComponent<RectTransform>());

        Transform stageLine = EnsurePanel(field, "Stage Line", new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0f, 84f), new Vector2(-120f, 6f));
        stageLine.GetComponent<Image>().color = new Color(0.38f, 0.65f, 0.78f, 0.35f);

        Transform player = EnsurePanel(field, "Lunaris", new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(360f, 184f), new Vector2(260f, 360f));
        Image playerImage = player.GetComponent<Image>();
        playerImage.color = Color.white;
        playerImage.preserveAspect = true;
        playerImage.raycastTarget = false;
        playerAnchor = player.GetComponent<RectTransform>();
        CreateAbsoluteText(player, "Name", "루나리스", 22, TextAnchor.MiddleCenter, new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0f, 24f), new Vector2(0f, 34f));
        playerSlider = CreateActorHPBar(player, "Lunaris HP", new Color(0.2f, 0.72f, 0.46f, 1f), out playerText);

        enemyAnchors = new RectTransform[3];
        enemyImages = new Image[3];
        enemyNameTexts = new Text[3];
        enemySliders = new Slider[3];
        enemyTexts = new Text[3];

        Vector2[] enemyPositions =
        {
            new Vector2(-720f, 150f),
            new Vector2(-430f, 176f),
            new Vector2(-140f, 150f)
        };

        Vector2[] enemySizes =
        {
            new Vector2(190f, 215f),
            new Vector2(220f, 245f),
            new Vector2(190f, 215f)
        };

        for (int i = 0; i < enemyAnchors.Length; i++)
        {
            string objectName = i == 0 ? "Enemy Actor" : $"Enemy Actor {i + 1}";
            Transform enemy = EnsurePanel(field, objectName, new Vector2(1f, 0f), new Vector2(1f, 0f), enemyPositions[i], enemySizes[i]);
            Image enemyImage = enemy.GetComponent<Image>();
            enemyImage.color = new Color(1f, 1f, 1f, 1f);
            enemyImage.preserveAspect = true;
            int targetIndex = i;
            Button enemyButton = EnsureComponent<Button>(enemy.gameObject);
            enemyButton.transition = Selectable.Transition.None;
            enemyButton.targetGraphic = enemyImage;
            enemyButton.onClick.RemoveAllListeners();
            enemyButton.onClick.AddListener(() =>
            {
                if (BattleManager.Instance != null)
                {
                    BattleManager.Instance.SelectEnemyTarget(targetIndex);
                }
            });
            enemyAnchors[i] = enemy.GetComponent<RectTransform>();
            enemyImages[i] = enemyImage;
            enemyNameTexts[i] = CreateAbsoluteText(enemy, "Name", "적", 20, TextAnchor.MiddleCenter, new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0f, 28f), new Vector2(0f, 38f));
            enemySliders[i] = CreateActorHPBar(enemy, "Enemy HP", new Color(0.85f, 0.1f, 0.18f, 1f), out enemyTexts[i]);
        }
    }

    private Slider CreateActorHPBar(Transform actor, string objectName, Color fillColor, out Text hpText)
    {
        Transform holder = EnsurePanel(actor, objectName, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, -34f), new Vector2(260f, 38f));
        Slider slider = EnsureComponent<Slider>(holder.gameObject);
        slider.transition = Selectable.Transition.None;
        slider.interactable = false;
        slider.minValue = 0f;
        slider.maxValue = 1f;
        slider.value = 1f;

        Sprite shellSprite = CreateCylinderSprite(new Color(0.03f, 0.035f, 0.045f, 1f), 0.6f);
        Sprite trackSprite = CreateCylinderSprite(new Color(0.1f, 0.1f, 0.12f, 1f), 0.4f);
        Sprite fillSprite = CreateCylinderSprite(fillColor, 0.85f);

        Transform shell = EnsurePanel(holder, "Cylinder Shell", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        Image shellImage = shell.GetComponent<Image>();
        shellImage.sprite = shellSprite;
        shellImage.type = Image.Type.Sliced;
        shellImage.color = Color.white;

        Transform track = EnsurePanel(holder, "Cylinder Track", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        RectTransform trackRect = track.GetComponent<RectTransform>();
        trackRect.offsetMin = new Vector2(4f, 4f);
        trackRect.offsetMax = new Vector2(-4f, -4f);
        Image trackImage = track.GetComponent<Image>();
        trackImage.sprite = trackSprite;
        trackImage.type = Image.Type.Sliced;
        trackImage.color = Color.white;

        Transform fillArea = EnsureChild(holder, "Fill Area", typeof(RectTransform));
        RectTransform fillAreaRect = fillArea.GetComponent<RectTransform>();
        fillAreaRect.anchorMin = Vector2.zero;
        fillAreaRect.anchorMax = Vector2.one;
        fillAreaRect.offsetMin = new Vector2(6f, 6f);
        fillAreaRect.offsetMax = new Vector2(-6f, -6f);

        Transform fill = EnsurePanel(fillArea, "Cylinder Fill", Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        Image fillImage = fill.GetComponent<Image>();
        fillImage.sprite = fillSprite;
        fillImage.type = Image.Type.Sliced;
        fillImage.color = Color.white;

        Transform shine = EnsurePanel(holder, "Cylinder Highlight", new Vector2(0f, 0.55f), new Vector2(1f, 1f), new Vector2(0f, -3f), new Vector2(-16f, -8f));
        Image shineImage = shine.GetComponent<Image>();
        shineImage.sprite = CreateCylinderSprite(new Color(1f, 1f, 1f, 0.24f), 0.25f);
        shineImage.type = Image.Type.Sliced;
        shineImage.raycastTarget = false;

        slider.fillRect = fill.GetComponent<RectTransform>();
        slider.targetGraphic = fillImage;
        hpText = CreateAbsoluteText(holder, "HP Text", "100 / 100", 16, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        hpText.raycastTarget = false;

        return slider;
    }

    private void CreateEndTurnButton(Transform root)
    {
        Transform buttonTransform = EnsurePanel(root, "End Turn Button", new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(-116f, 150f), new Vector2(108f, 108f));
        Image image = EnsureComponent<Image>(buttonTransform.gameObject);
        Sprite endTurnSprite = LoadEndTurnButtonSprite();
        image.sprite = endTurnSprite != null ? endTurnSprite : CreateCircleSprite(new Color(0.08f, 0.18f, 0.28f, 1f), new Color(0.22f, 0.82f, 1f, 1f));
        image.type = Image.Type.Simple;
        image.preserveAspect = true;
        image.color = Color.white;

        Button button = EnsureComponent<Button>(buttonTransform.gameObject);
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(() =>
        {
            if (TurnManager.Instance != null) TurnManager.Instance.EndPlayerTurn();
        });

        Text label = CreateAbsoluteText(buttonTransform, "Label", endTurnSprite == null ? "턴\n종료" : "", 24, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        label.raycastTarget = false;
    }

    private Text CreateAbsoluteText(Transform parent, string objectName, string value, int size, TextAnchor alignment, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
    {
        Transform existing = parent.Find(objectName);
        Text text;
        if (existing == null)
        {
            GameObject go = new GameObject(objectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
            go.transform.SetParent(parent, false);
            text = go.GetComponent<Text>();
        }
        else
        {
            text = existing.GetComponent<Text>();
        }

        RectTransform rect = text.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = sizeDelta;

        text.text = value;
        text.font = GetBuiltinFont();
        text.fontSize = size;
        text.alignment = alignment;
        ReadableTextStyle.Apply(text);
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 14;
        text.resizeTextMaxSize = size;

        return text;
    }

    private GameObject CreateGemPrefab(Transform parent)
    {
        GameObject prefab = new GameObject("Runtime Gem Prefab", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(LayoutElement));
        prefab.transform.SetParent(parent, false);
        RectTransform rect = prefab.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(22f, 22f);
        LayoutElement layout = prefab.GetComponent<LayoutElement>();
        layout.preferredWidth = 22f;
        layout.preferredHeight = 22f;
        prefab.GetComponent<Image>().sprite = CreateSprite(Color.white);
        prefab.SetActive(false);
        return prefab;
    }

    private Sprite CreateSprite(Color color)
    {
        Texture2D texture = new Texture2D(1, 1);
        texture.SetPixel(0, 0, color);
        texture.Apply();
        return Sprite.Create(texture, new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f));
    }

    private Sprite CreateCircleSprite(Color centerColor, Color rimColor)
    {
        int size = 128;
        Texture2D texture = new Texture2D(size, size);
        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        float radius = size * 0.48f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float distance = Vector2.Distance(new Vector2(x, y), center);
                if (distance > radius)
                {
                    texture.SetPixel(x, y, Color.clear);
                    continue;
                }

                float edge = Mathf.InverseLerp(radius * 0.72f, radius, distance);
                Color color = Color.Lerp(centerColor, rimColor, edge);
                color.a = Mathf.Lerp(1f, 0.88f, edge);
                texture.SetPixel(x, y, color);
            }
        }

        texture.Apply();
        return Sprite.Create(texture, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f));
    }

    private Sprite CreateCylinderSprite(Color color, float contrast)
    {
        int width = 128;
        int height = 32;
        float radius = height * 0.5f;
        Texture2D texture = new Texture2D(width, height);

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                float leftDistance = Vector2.Distance(new Vector2(x, y), new Vector2(radius, radius));
                float rightDistance = Vector2.Distance(new Vector2(x, y), new Vector2(width - radius, radius));
                bool insideMiddle = x >= radius && x <= width - radius;
                bool insideCaps = leftDistance <= radius || rightDistance <= radius;
                bool inside = insideMiddle || insideCaps;

                if (!inside)
                {
                    texture.SetPixel(x, y, Color.clear);
                    continue;
                }

                float vertical = y / (float)(height - 1);
                float highlight = Mathf.Exp(-Mathf.Pow((vertical - 0.74f) * 4.8f, 2f)) * 0.42f * contrast;
                float shadow = Mathf.Exp(-Mathf.Pow((vertical - 0.18f) * 4.2f, 2f)) * 0.38f * contrast;
                Color shaded = color;
                shaded.r = Mathf.Clamp01(shaded.r + highlight - shadow);
                shaded.g = Mathf.Clamp01(shaded.g + highlight - shadow);
                shaded.b = Mathf.Clamp01(shaded.b + highlight - shadow);
                texture.SetPixel(x, y, shaded);
            }
        }

        texture.Apply();
        return Sprite.Create(texture, new Rect(0f, 0f, width, height), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(radius, radius, radius, radius));
    }

    private T EnsureComponent<T>(GameObject go) where T : Component
    {
        T component = go.GetComponent<T>();
        if (component == null) component = go.AddComponent<T>();
        return component;
    }

    private static T Find<T>() where T : Object
    {
        return Object.FindFirstObjectByType<T>();
    }

    private void Stretch(RectTransform rect)
    {
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }

    private Font GetBuiltinFont()
    {
        return ReadableTextStyle.GetReadableFont();
    }

    private TMP_FontAsset LoadGameOverFontAsset()
    {
        return ReadableTextStyle.GetReadableTMPFont();
    }

    private Sprite LoadEndTurnButtonSprite()
    {
#if UNITY_EDITOR
        Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/button/Battle/TurnEndButton_Anime-removebg-preview.png");
        if (texture == null) return null;

        return Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
#else
        return null;
#endif
    }
}
