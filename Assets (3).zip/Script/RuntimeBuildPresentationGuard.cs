using TMPro;
using UnityEngine;
using UnityEngine.UI;

// 빌드본에서 에디터와 다르게 보이는 표시 문제를 한 곳에서 보정합니다.
//
// 현재 해결하는 문제:
// - 빌드에서 TMP 기본 폰트로 떨어져 한글이 깨지는 문제
// - 씬 카메라의 기본 파란 배경이 UI 뒤로 비치는 문제
public class RuntimeBuildPresentationGuard : MonoBehaviour
{
    private static bool didSubscribe;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Register()
    {
        if (didSubscribe) return;

        didSubscribe = true;
        UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void ApplyToCurrentScene()
    {
        ApplyBuildPresentationFixes();
    }

    private static void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
    {
        ApplyBuildPresentationFixes();
    }

    private static void ApplyBuildPresentationFixes()
    {
        ApplySafeCameraBackground();
        ApplyReadableFontsToScene();
    }

    private static void ApplySafeCameraBackground()
    {
        Camera[] cameras = Object.FindObjectsByType<Camera>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < cameras.Length; i++)
        {
            Camera camera = cameras[i];
            if (camera == null) continue;

            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.black;
        }
    }

    private static void ApplyReadableFontsToScene()
    {
        Text[] legacyTexts = Object.FindObjectsByType<Text>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < legacyTexts.Length; i++)
        {
            ReadableTextStyle.Apply(legacyTexts[i]);
        }

        TMP_Text[] tmpTexts = Object.FindObjectsByType<TMP_Text>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < tmpTexts.Length; i++)
        {
            ReadableTextStyle.Apply(tmpTexts[i]);
        }
    }
}
