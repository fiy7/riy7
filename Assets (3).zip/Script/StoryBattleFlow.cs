using UnityEngine;

// 전투 씬(BattleScene)과 스토리 씬(startstory)을 이어 주는 진행 관리자입니다.
//
// 왜 이 파일이 필요할까요?
// - Unity에서 씬을 바꾸면 그 씬에 있던 일반 오브젝트는 대부분 사라집니다.
// - 그래서 BattleManager 안에만 "현재 몇 번째 적까지 왔는지"를 저장하면,
//   스토리 씬으로 넘어갔다가 다시 BattleScene으로 돌아올 때 진행도가 0으로 돌아갈 수 있습니다.
// - 이 클래스는 MonoBehaviour가 아닌 static 클래스라서 씬 오브젝트에 붙이지 않아도 값을 기억합니다.
//
// 초심자용 핵심 개념:
// - static 변수는 특정 오브젝트 한 개가 아니라 클래스 자체에 저장됩니다.
// - 그래서 씬을 바꿔도 게임 실행 중에는 값이 유지됩니다.
// - const string은 씬 이름처럼 자주 쓰지만 바뀌면 안 되는 글자를 한 곳에 묶어 두는 방식입니다.
// - LoadScene은 현재 씬을 닫고 다른 씬을 여는 Unity 함수입니다.
public static class StoryBattleFlow
{
    // 실제 프로젝트에 존재하는 전투 씬 이름입니다.
    // 사용자가 말한 BattleScene과 연결됩니다.
    public const string BattleSceneName = "BattleScene";

    // 현재 프로젝트에는 stroyscene이라는 씬이 없고 startstory 씬이 있습니다.
    // 그래서 startstory를 스토리 전용 씬으로 사용합니다.
    // 나중에 정말 storyscene/stroyscene 씬을 새로 만들면 이 값만 바꾸면 됩니다.
    public const string StorySceneName = "startstory";

    // 게임을 모두 클리어한 뒤 돌아갈 기본 화면입니다.
    public const string InterfaceSceneName = "intface";

    // BattleStageIndex는 BattleScene에 돌아갔을 때 몇 번째 적을 소환할지 저장합니다.
    // 0: 튜토리얼 공허의 울음꾼 1마리
    // 1: 튜토리얼 이후 공허의 울음꾼 3마리
    // 2: 탁한 별가루 집행자
    // 3: 타락한 황도13궁 전갈
    // 4: 별의 대적자
    public static int BattleStageIndex;

    // StorySegmentIndex는 startstory 씬에서 어떤 스토리 묶음을 보여줄지 저장합니다.
    // 0: 운명의 서막
    // 1: 운명의 쇄도
    // 2: 별자리의 타락
    // 3: 별자리들의 구원자, 최종전 직전
    // 4: 최종 결말
    public static int StorySegmentIndex;

    // startstory 씬이 처음 열렸는지 구분하기 위한 값입니다.
    // 아무 값도 지정하지 않고 startstory를 직접 실행하면 0부부터 시작하게 만듭니다.
    public static bool HasStoryFlowStarted;

    // intface의 이야기 버튼으로 들어왔을 때는 전투로 이어지지 않고 전체 스토리만 감상합니다.
    public static bool IsFullStoryMode;

    public static bool IsFinalStory => StorySegmentIndex >= 4;

    public static void StartIntroStory()
    {
        // 게임 시작 스토리로 초기화합니다.
        HasStoryFlowStarted = true;
        IsFullStoryMode = false;
        StorySegmentIndex = 0;
        BattleStageIndex = 0;
    }

    public static void LoadIntroStory()
    {
        // intface 씬의 시작 버튼에서 호출하기 좋은 함수입니다.
        // 먼저 진행도를 0부/첫 전투로 초기화한 뒤, 스토리 씬으로 이동합니다.
        // 이렇게 해야 이전에 엔딩까지 봤거나 중간까지 진행한 상태여도 새 게임은 항상 처음부터 시작됩니다.
        StartIntroStory();
        UnityEngine.SceneManagement.SceneManager.LoadScene(StorySceneName);
    }

    public static void LoadStoryAfterDefeatingStage(int defeatedStageIndex)
    {
        // 적을 쓰러뜨린 직후 호출됩니다.
        // 튜토리얼 뒤에 공허의 울음꾼 3마리 전투가 추가되었기 때문에,
        // defeatedStageIndex 1부터 중간 스토리 1번을 보여줍니다.
        HasStoryFlowStarted = true;
        IsFullStoryMode = false;

        int nextBattleStage = defeatedStageIndex + 1;
        BattleStageIndex = Mathf.Clamp(nextBattleStage, 0, 4);

        // 예: 울음꾼 3마리 처치 후 StorySegmentIndex = 1, 다음 적은 BattleStageIndex = 2
        StorySegmentIndex = Mathf.Clamp(defeatedStageIndex, 1, 3);
        UnityEngine.SceneManagement.SceneManager.LoadScene(StorySceneName);
    }

    public static void LoadBattleStageDirectly(int battleStageIndex)
    {
        // 스토리를 거치지 않고 바로 특정 전투 스테이지로 들어갑니다.
        // 튜토리얼 직후 공허의 울음꾼 3마리 전투로 이어질 때 사용합니다.
        HasStoryFlowStarted = true;
        IsFullStoryMode = false;
        BattleStageIndex = Mathf.Clamp(battleStageIndex, 0, 4);
        UnityEngine.SceneManagement.SceneManager.LoadScene(BattleSceneName);
    }

    public static void LoadFullStory()
    {
        // 이야기 버튼에서 호출합니다.
        // 전투 안내나 전투 진입 없이 0부부터 엔딩까지 이어서 보여줍니다.
        HasStoryFlowStarted = true;
        IsFullStoryMode = true;
        StorySegmentIndex = 0;
        BattleStageIndex = 0;
        UnityEngine.SceneManagement.SceneManager.LoadScene(StorySceneName);
    }

    public static void LoadFinalStory()
    {
        // 마지막 적인 별의 대적자를 쓰러뜨렸을 때 호출됩니다.
        HasStoryFlowStarted = true;
        IsFullStoryMode = false;
        StorySegmentIndex = 4;
        BattleStageIndex = 0;
        UnityEngine.SceneManagement.SceneManager.LoadScene(StorySceneName);
    }

    public static void LoadCurrentBattleStage()
    {
        // 스토리 대화가 끝났을 때 BattleScene으로 돌아갑니다.
        // BattleManager.Start가 BattleStageIndex를 읽어서 맞는 적을 소환합니다.
        HasStoryFlowStarted = true;
        IsFullStoryMode = false;
        UnityEngine.SceneManagement.SceneManager.LoadScene(BattleSceneName);
    }

    public static void LoadInterfaceAfterEnding()
    {
        // 최종 결말까지 다 본 뒤 설정/시작 화면 역할을 하는 intface로 돌아갑니다.
        IsFullStoryMode = false;
        UnityEngine.SceneManagement.SceneManager.LoadScene(InterfaceSceneName);
    }
}
