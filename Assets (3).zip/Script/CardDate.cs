using System;
using UnityEngine;

// 카드 한 장의 데이터를 담는 ScriptableObject입니다.
// 이름/코스트/피해량/능력 타입/능력 수치를 여기에 저장해두고, CardAbilityLibrary가 이 값을 읽어 효과를 실행합니다.
//
// ScriptableObject를 쓰는 이유:
// - 카드마다 수치가 다르지만, 실행 로직은 대부분 공통입니다.
// - 데이터는 CardDate에 넣고, 실제 행동은 CardAbilityLibrary에 맡기면
//   "데이터"와 "규칙"이 분리되어 카드 밸런스를 바꾸기 쉬워집니다.
//
// 초심자용 핵심 개념:
// - 이 파일은 "카드 한 장이 어떤 정보를 가지고 있는지"를 정의합니다.
// - 직접 피해를 주거나 UI를 움직이지 않습니다.
// - 예를 들어 사수자리 카드라면 cost, power, damageMultiplier, weatheringTurns 같은 값을 여기에 가집니다.
// - CardAbilityLibrary는 이 값을 읽어서 "어떤 효과를 실행할지" 결정합니다.
[CreateAssetMenu(fileName = "NewCard", menuName = "CardSystem/CardData")]
public class CardDate : ScriptableObject
{
    // 카드 UI에 표시되는 이름입니다. 예: 양자리, 사자자리, 사수자리
    public string cardName;

    // 마우스를 카드 위에 올렸을 때 툴팁에 표시되는 설명입니다.
    [TextArea(2, 5)]
    public string description;

    // 카드를 사용하기 위해 소비하는 기력입니다.
    public int cost;

    // 공격 카드라면 기본 공격력, 방어 카드라면 참고 수치로 사용할 수 있는 값입니다.
    public float power; // 공격력 혹은 방어력 수치

    // 카드 그림입니다. 손패 UI의 Artwork 이미지에 들어갑니다.
    public Sprite cardImage;

    // 카드의 큰 분류입니다. 필살기 조건 확인, UI 표시 등에 사용됩니다.
    public CardType type;

    // 실제로 어떤 능력을 실행할지 결정하는 enum입니다.
    public CardAbility ability;

    [Header("Ability Values")]
    // 아래 값들은 모든 카드가 전부 쓰는 것은 아닙니다.
    // 예: 독 카드는 poisonDamage를 쓰고, 방어 카드는 shieldAmount/shieldRatio를 씁니다.
    // 하나의 CardDate 안에 여러 수치를 모아둔 이유는 카드 종류가 늘어나도
    // 별도 데이터 클래스를 계속 만들지 않고 Inspector에서 빠르게 조정하기 위해서입니다.
    public float damageMultiplier = 1f;
    public float shieldRatio = 0f;
    public float shieldAmount = 0f;
    public float damageCap = 5f;
    public int buffStacks = 0;
    public int buffTurns = 0;
    public float poisonDamage = 0f;
    public int poisonTurns = 0;
    public int weatheringTurns = 0;
    public int energyGain = 0;
    public float healAmount = 0f;
    public float nextAttackMultiplier = 1f;
    public int maxStacks = 0;
    public float stackDamageBonus = 0f;

    // 카드의 큰 분류입니다. UI 표시와 필살기 조건 확인 등에 사용됩니다.
    public enum CardType { Attack, Defense, Buff, Energy, Ultimate }

    // 실제 발동할 능력 종류입니다.
    // CardAbilityLibrary.Execute에서 이 enum을 보고 효과를 분기합니다.
    // 새 카드를 추가할 때는 보통 이 enum에 새 항목을 만들고,
    // CardAbilityLibrary.Execute의 switch에 실행 코드를 추가합니다.
    public enum CardAbility
    {
        AriesStrike,
        TaurusCharge,
        GeminiShield,
        CancerCrush,
        VirgoVeil,
        LibraBalance,
        ScorpioPoison,
        SagittariusUltimate,
        CapricornStack,
        AquariusEnergy,
        PiscesEmpower,
        LeoEcho
    }
}
