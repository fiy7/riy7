using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;
#endif

// startstory 씬의 대화 연출을 담당하는 관리자입니다.
//
// 목표:
// - 림버스 컴퍼니처럼 화면 아래에 어두운 대화창을 띄웁니다.
// - 글자가 한 글자씩 타이핑되듯 나타납니다.
// - 화면을 터치/클릭하면 현재 문장이 즉시 완성됩니다.
// - 문장이 이미 완성된 상태에서 다시 터치/클릭하면 다음 대화로 넘어갑니다.
// - 아무것도 누르지 않아도 일정 시간이 지나면 자동으로 다음 대화로 넘어갑니다.
// - 대화마다 배경 색과 분위기가 바뀝니다.
//
// 초심자용 핵심 개념:
// - Coroutine은 시간이 걸리는 일을 여러 프레임에 나누어 실행할 때 사용합니다.
// - yield return null은 "다음 프레임까지 기다린다"는 뜻입니다.
// - Button.onClick은 UI 버튼을 클릭했을 때 실행할 함수를 연결하는 이벤트입니다.
// - TMP_Text는 TextMeshPro 텍스트 컴포넌트입니다. 일반 Text보다 한글 표시와 품질이 좋습니다.
// - Image.color를 바꾸면 UI 이미지의 색이 바뀝니다.
public class DialogueManager : MonoBehaviour
{
    private enum DialogueSpeakerKind
    {
        Narration,
        Hero,
        Villager,
        Boss,
        Mystic
    }

    // 대사 한 줄에 필요한 데이터를 묶어 둔 구조체입니다.
    // speaker: 말하는 사람 이름
    // line: 실제 대사
    // topColor/bottomColor: 해당 대사에서 사용할 배경 그라데이션 색
    // waitAfterComplete: 문장이 다 나온 뒤 자동으로 다음 대사로 넘어가기까지 기다리는 시간
    [System.Serializable]
    private struct DialogueEntry
    {
        public string speaker;
        [TextArea(2, 5)] public string line;
        public Color topColor;
        public Color bottomColor;
        public int backgroundIndex;
        public DialogueSpeakerKind speakerKind;
        public float waitAfterComplete;

        public DialogueEntry(string speaker, string line, Color topColor, Color bottomColor, int backgroundIndex, DialogueSpeakerKind speakerKind, float waitAfterComplete)
        {
            this.speaker = speaker;
            this.line = line;
            this.topColor = topColor;
            this.bottomColor = bottomColor;
            this.backgroundIndex = backgroundIndex;
            this.speakerKind = speakerKind;
            this.waitAfterComplete = waitAfterComplete;
        }
    }

    private static bool didBootstrap;
    private static bool didSubscribeSceneLoaded;

    [Header("Dialogue Timing")]
    [SerializeField] private float characterInterval = 0.035f;
    [SerializeField] private float defaultAutoAdvanceDelay = 2.2f;
    [SerializeField] private float autoAdvanceExtraDelay = 1f;

    private DialogueEntry[] entries;
    private int currentIndex;
    private bool isTyping;
    private bool isWaitingForAutoAdvance;

    private Canvas canvas;
    private Image backgroundImage;
    private Image dimImage;
    private Image dialogueBoxImage;
    private Image speakerPlateImage;
    private Image portraitFrameImage;
    private Image portraitImage;
    private RectTransform speakerCutsceneRoot;
    private Image speakerCutsceneImage;
    private CanvasGroup speakerCutsceneCanvasGroup;
    private RectTransform dialogueBoxRoot;
    private RectTransform storyControlsRoot;
    private TMP_Text speakerText;
    private TMP_Text bodyText;
    private TMP_Text continueText;
    private TMP_FontAsset dialogueFontAsset;
    private static readonly Dictionary<int, Sprite> storyBackgroundCache = new Dictionary<int, Sprite>();
    private static readonly Dictionary<string, Sprite> dialoguePortraitCache = new Dictionary<string, Sprite>();
    private static readonly Dictionary<DialogueSpeakerKind, Sprite> generatedPortraitCache = new Dictionary<DialogueSpeakerKind, Sprite>();
    private static readonly Dictionary<string, Sprite> gradientBackgroundCache = new Dictionary<string, Sprite>();
    private int storyBuildSegmentIndex;
    private Button touchButton;
    private Coroutine typingCoroutine;
    private Coroutine autoAdvanceCoroutine;
    private Coroutine endingSequenceCoroutine;
    private GameObject endingSequenceRoot;
    private CanvasGroup endingSequenceCanvasGroup;
    private GameObject endingCreditsViewportRoot;
    private RectTransform endingCreditsRect;
    private TMP_Text endingCreditsText;
    private bool endingSequenceActive;
    private bool endingCreditsPlaying;
    private float lastTouchHandledTime = -10f;
    private const float TouchDebounceSeconds = 0.12f;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void RegisterSceneLoadedBootstrap()
    {
        // RuntimeInitializeOnLoadMethod만 쓰면 게임이 처음 시작될 때는 잘 동작하지만,
        // 버튼으로 intface -> startstory처럼 나중에 씬을 바꿀 때는 원하는 코드가 다시 안 돌 수 있습니다.
        // 그래서 Unity의 sceneLoaded 이벤트에 한 번 등록해서, 씬이 로드될 때마다 TryBootstrapStartStory를 실행합니다.
        if (didSubscribeSceneLoaded) return;

        didSubscribeSceneLoaded = true;
        UnityEngine.SceneManagement.SceneManager.sceneLoaded += OnSceneLoaded;
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void BootstrapStartStory()
    {
        // 첫 씬이 startstory인 경우도 바로 대화 시스템이 켜지도록 한 번 더 확인합니다.
        TryBootstrapStartStory(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name);
    }

    private static void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
    {
        // 버튼이나 코드로 새 씬을 불러온 뒤에도 이 함수가 호출됩니다.
        // 그래서 startstory 씬으로 넘어간 순간 DialogueManager가 확실히 생성됩니다.
        TryBootstrapStartStory(scene.name);
    }

    private static void TryBootstrapStartStory(string loadedSceneName)
    {
        string sceneName = loadedSceneName.ToLower();
        if (!sceneName.Contains("startstory"))
        {
            // BattleScene으로 나갔다가 다시 startstory로 돌아오는 구조이므로,
            // 다른 씬에 있을 때는 didBootstrap을 풀어 두어야 다음 스토리도 다시 생성됩니다.
            didBootstrap = false;
            return;
        }

        if (didBootstrap) return;
        if (UnityEngine.Object.FindFirstObjectByType<DialogueManager>() != null)
        {
            didBootstrap = true;
            return;
        }

        didBootstrap = true;
        new GameObject("DialogueManager").AddComponent<DialogueManager>();
    }

    private void Awake()
    {
        // 혹시 씬에 DialogueManager를 직접 배치한 경우에도 중복 생성되지 않게 방어합니다.
        DialogueManager[] managers = FindObjectsByType<DialogueManager>(FindObjectsSortMode.None);
        if (managers.Length > 1)
        {
            Destroy(gameObject);
            return;
        }
    }

    private void Start()
    {
        // Start에서 실제 대화 데이터와 UI를 준비합니다.
        // Awake보다 Start가 늦게 호출되므로, 씬 안의 Canvas나 EventSystem을 찾기에 안전합니다.
        if (!StoryBattleFlow.HasStoryFlowStarted)
        {
            // startstory 씬을 에디터에서 직접 재생했거나 처음 게임이 시작된 경우입니다.
            // 이때는 0부 운명의 서막부터 시작합니다.
            StoryBattleFlow.StartIntroStory();
        }

        entries = CreateDefaultStory();
        EnsureEventSystem();
        BuildDialogueUI();
        ShowEntry(0);
    }

    private void Update()
    {
        // 대사는 화면 클릭 또는 터치로만 넘깁니다.
        // 키보드 입력으로 스토리가 의도치 않게 넘어가지 않도록 막아둡니다.
        if (Input.GetMouseButtonDown(0))
        {
            OnTouchDialogue();
        }
    }

    private DialogueEntry[] CreateDefaultStory()
    {
        // StoryBattleFlow.StorySegmentIndex 값에 따라 다른 스토리 묶음을 반환합니다.
        // BattleManager가 적 처치 후 이 번호를 바꿔 두고 startstory 씬을 열기 때문에,
        // startstory는 "지금 몇 번째 이야기를 보여줘야 하는지"를 여기서 알 수 있습니다.
        if (StoryBattleFlow.IsFullStoryMode)
        {
            return CreateFullStory();
        }

        storyBuildSegmentIndex = Mathf.Clamp(StoryBattleFlow.StorySegmentIndex, 0, 4);
        switch (StoryBattleFlow.StorySegmentIndex)
        {
            case 1:
                return CreatePartOneStory();
            case 2:
                return CreatePartTwoStory();
            case 3:
                return CreatePartThreeBeforeFinalBattleStory();
            case 4:
                return CreateEndingStory();
            default:
                return CreatePrologueStory();
        }
    }

    private DialogueEntry[] CreateFullStory()
    {
        List<DialogueEntry> fullStory = new List<DialogueEntry>();
        AddStorySegment(fullStory, 0, CreatePrologueStory);
        AddStorySegment(fullStory, 1, CreatePartOneStory);
        AddStorySegment(fullStory, 2, CreatePartTwoStory);
        AddStorySegment(fullStory, 3, CreatePartThreeBeforeFinalBattleStory);
        AddStorySegment(fullStory, 4, CreateEndingStory);
        return fullStory.ToArray();
    }

    private void AddStorySegment(List<DialogueEntry> target, int segmentIndex, System.Func<DialogueEntry[]> createStory)
    {
        storyBuildSegmentIndex = segmentIndex;
        target.AddRange(createStory());
    }

    private DialogueEntry[] CreatePrologueStory()
    {
        // 0부: 운명의 서막.
        // 첫 전투가 시작되기 전에 세계관의 원인을 알려주는 구간입니다.
        return new DialogueEntry[]
        {
            StoryLine("제단의 밤", "아주 오래전, 밤하늘에는 13개의 별자리가 있었다.", 2.4f, 0),
            StoryLine("별하늘의 저위에", "그들은 계절과 꿈과 죽음 뒤의 길까지 나누어 지켰다.", 2.6f, 0),
            StoryLine("별의 기록", "사람들은 별을 올려다보며 자기 운명이 혼자가 아니라고 믿었다.", 2.8f, 0),
            StoryLine("별의 기록", "그러나 열세 번째 별자리의 한 조각이 그 빛을 질투했다.", 2.8f, 1),
            StoryLine("추방된 별", "왜 나는 경계에만 서 있어야 하지. 왜 나만 이름을 잃어야 하지.", 3.0f, 1),
            StoryLine("별하늘의 저위에", "그 울음은 어둠이 되었고, 어둠은 별자리의 숨결을 더럽혔다.", 3.0f, 1),
            StoryLine("별의 기록", "13성좌는 무너지지 않으려 버텼지만, 전갈자리는 가장 먼저 독빛에 잠겼다.", 3.0f, 2),
            StoryLine("전갈자리", "나의 침묵을 들은 자는 없었다. 그렇다면 모두 같은 독을 마셔라.", 3.0f, 2),
            StoryLine("달의 마나", "그때 달의 가장 낮은 곳에서 작은 불씨 하나가 깨어났다.", 2.6f, 0),
            StoryLine("주인공", "이 목소리... 내가 부른 게 아니야. 그런데 계속 나를 향해 와.", 2.8f, 2),
            StoryLine("별의 기록", "네 손에 모인 카드는 무기가 아니라 별자리들이 남긴 기억이다.", 2.8f, 2),
            StoryLine("운명", "기억을 잇고, 타락을 걷어내라. 첫 번째 어둠이 문 앞에 도착했다.", 2.8f, 1),
            StoryLine("제단의 밤", "하늘은 아직 무너지는 중이고, 너는 이제 그 균열 안으로 들어간다.", 2.8f, 1),
        };
    }

    private DialogueEntry[] CreatePartOneStory()
    {
        // 1부: 운명의 쇄도.
        // 첫 적을 쓰러뜨린 뒤, 플레이어가 본격적으로 전투의 흐름을 이해하는 구간입니다.
        return new DialogueEntry[]
        {
            StoryLine("영원한 그늘 도시", "쓰러진 적의 몸에서 검은 별가루가 모래처럼 흩어졌다.", 2.6f, 1),
            StoryLine("주인공", "사라졌는데도 무언가 남아 있어. 별빛이 아니라 기억 같은 것.", 2.8f, 2),
            StoryLine("달의 마나", "그 기억은 네 카드에 닿아 다음 별을 부르는 길이 된다.", 2.8f, 2),
            StoryLine("영원한 그늘 도시", "거리의 창문마다 꺼진 별이 비쳤고, 아무도 문을 열지 않았다.", 2.8f, 1),
            StoryLine("마을 사람", "누군가 별을 훔쳐 갔어요. 밤이 와도 소원을 빌 곳이 없어요.", 3.0f, 1),
            StoryLine("주인공", "별자리가 무너지면 사람의 마음도 이렇게 닫히는구나.", 2.8f, 0),
            StoryLine("별의 기록", "양자리의 불씨와 황소자리의 뿔은 원래 같은 문을 지키던 힘이다.", 3.0f, 2),
            StoryLine("별의 기록", "별들이 이어질 때, 카드는 단순한 한 장을 넘어 서로의 이름을 완성한다.", 3.0f, 2),
            StoryLine("도시의 심장", "폐허 아래에서 두 번째 울음이 깨어났다. 이번에는 하나가 아니다.", 2.8f, 1),
            StoryLine("운명", "그늘은 너를 시험하려고 더 많은 몸을 빌린다. 그러나 너도 혼자가 아니다.", 2.8f, 0),
        };
    }

    private DialogueEntry[] CreatePartTwoStory()
    {
        // 2부: 별자리의 타락.
        // 두 번째 적을 쓰러뜨린 뒤, 전갈자리 수호자와 맞붙기 전의 설명입니다.
        return new DialogueEntry[]
        {
            StoryLine("천갈궁(天蠍宮)", "검은 별가루가 잠긴 궁의 천장에는 전갈의 꼬리를 닮은 성도가 새겨져 있었다.", 2.8f, 0),
            StoryLine("별의 기록", "이곳은 13성좌가 처음 서로의 이름을 새긴 장소다.", 2.6f, 0),
            StoryLine("주인공", "그런데 이름이 긁혀 있어. 누군가 일부러 지운 것처럼.", 2.8f, 1),
            StoryLine("달의 마나", "전갈자리가 스스로의 문장을 찢었다. 독이 기억을 삼키기 전에.", 3.0f, 1),
            StoryLine("전갈자리", "찢은 게 아니다. 남기면 더 아팠기 때문에 버렸을 뿐이다.", 3.0f, 1),
            StoryLine("주인공", "너도 처음부터 적이었던 건 아니구나.", 2.6f, 2),
            StoryLine("전갈자리", "늦었다. 내 독은 이제 나의 말보다 먼저 움직인다.", 2.8f, 2),
            StoryLine("별의 기록", "전갈의 독은 몸이 아니라 별의 의지를 겨눈다. 버티는 마음부터 무너뜨린다.", 3.2f, 1),
            StoryLine("전갈자리", "네가 나를 정화할 수 있다면 증명해라. 실패한다면 너도 밤에 잠길 것이다.", 3.2f, 1),
            StoryLine("천갈궁(天蠍宮)", "궁의 중심 렌즈가 검은 달을 비추자, 하늘에 독빛의 원이 열렸다.", 2.8f, 2),
            StoryLine("운명", "구원해야 할 적이 길을 막고 있다. 칼보다 먼저 마음을 세워라.", 2.8f, 0),
        };
    }

    private DialogueEntry[] CreatePartThreeBeforeFinalBattleStory()
    {
        // 3부: 별자리들의 구원자, 최종전 직전.
        // 전갈을 쓰러뜨린 뒤 별의 대적자에게 가는 마지막 연결 스토리입니다.
        return new DialogueEntry[]
        {
            StoryLine("별자리 전투장", "전갈의 독빛이 사라지자, 발밑의 원형 성좌가 천천히 되살아났다.", 2.8f, 0),
            StoryLine("전갈자리", "나는 오래도록 독을 지켰다. 그것이 나의 죄인지, 마지막 의무인지 몰랐다.", 3.2f, 1),
            StoryLine("주인공", "이제 쉬어. 네 별은 다시 하늘로 돌아갈 수 있어.", 2.8f, 2),
            StoryLine("전갈자리", "조심해라. 별의 대적자는 훔친 빛으로만 싸우지 않는다.", 3.0f, 1),
            StoryLine("전갈자리", "그는 네가 잃어버릴 것을 먼저 보여 주고, 스스로 손을 놓게 만든다.", 3.2f, 1),
            StoryLine("달의 마나", "내 빛을 끝까지 쓰면 너에게 남는 것은 평범한 새벽뿐일지도 모른다.", 3.0f, 0),
            StoryLine("주인공", "평범한 새벽이면 충분해. 누군가는 다시 하늘을 올려다볼 수 있을 테니까.", 3.2f, 2),
            StoryLine("별의 기록", "13개의 이름이 한 번 더 이어진다. 잃어버린 별도, 지켜낸 별도 함께.", 3.2f, 0),
            StoryLine("별의 대적자", "오너라. 네가 사랑한 모든 빛을 내 어둠 안에 접어 넣겠다.", 3.0f, 1),
            StoryLine("운명", "최종 성역의 문이 열린다. 별의 대적자가 그 안에서 기다린다.", 2.8f, 1),
        };
    }

    private DialogueEntry[] CreateEndingStory()
    {
        // 최종 결말.
        // 별의 대적자를 쓰러뜨린 뒤 보여주는 엔딩입니다.
        return new DialogueEntry[]
        {
            StoryLine("최종 성역", "별의 대적자가 무너진 자리에는 검은 왕관 하나만 남았다.", 2.8f, 1),
            StoryLine("별의 대적자", "빛은 결국 사라진다. 네가 지킨 것도 언젠가는 너를 잊을 것이다.", 3.0f, 1),
            StoryLine("주인공", "그래도 괜찮아. 잊어도 다시 올려다볼 수 있으면 돼.", 2.8f, 2),
            StoryLine("달의 마나", "마지막 달빛을 열면, 네 안의 별자리 기억도 함께 흩어진다.", 3.0f, 0),
            StoryLine("주인공", "그 기억들이 하늘로 돌아간다면, 그걸로 충분해.", 2.8f, 2),
            StoryLine("별의 기록", "주인공은 모든 달의 마나를 밤하늘에 풀어 놓았다.", 2.8f, 0),
            StoryLine("별의 기록", "더럽혀진 별가루는 눈처럼 녹았고, 13성좌의 선이 다시 이어졌다.", 3.2f, 0),
            StoryLine("전갈자리", "고맙다. 이제 나의 독은 누구의 꿈도 물들이지 않을 것이다.", 3.0f, 2),
            StoryLine("새벽", "첫 빛이 올라오자, 사람들은 이유도 모른 채 창문을 열었다.", 2.8f, 0),
            StoryLine("평범한 일상", "주인공은 모든 힘과 기억을 잃고, 조용한 하루 속에서 눈을 떴다.", 3.2f, 0),
            StoryLine("주인공", "이상하네. 오늘 밤엔 꼭 하늘을 보고 싶어.", 2.8f, 2),
            StoryLine("끝", "밤하늘은 정화되었고, 13개의 별자리는 다시 영롱하게 빛났다.", 3.0f, 0),
        };
    }

    private DialogueEntry StoryLine(string speaker, string line, float waitAfterComplete, int paletteIndex)
    {
        // 반복되는 DialogueEntry 생성을 줄이기 위한 도우미 함수입니다.
        // paletteIndex만 바꿔도 대사의 분위기에 맞는 배경색이 달라집니다.
        Color topColor;
        Color bottomColor;

        switch (paletteIndex)
        {
            case 1:
                topColor = new Color(0.05f, 0.015f, 0.04f);
                bottomColor = new Color(0.20f, 0.04f, 0.06f);
                break;
            case 2:
                topColor = new Color(0.015f, 0.06f, 0.10f);
                bottomColor = new Color(0.02f, 0.15f, 0.18f);
                break;
            default:
                topColor = new Color(0.02f, 0.03f, 0.08f);
                bottomColor = new Color(0.10f, 0.07f, 0.20f);
                break;
        }

        return new DialogueEntry(speaker, line, topColor, bottomColor, storyBuildSegmentIndex, GetSpeakerKind(speaker), waitAfterComplete);
    }

    private DialogueSpeakerKind GetSpeakerKind(string speaker)
    {
        if (speaker == "주인공") return DialogueSpeakerKind.Hero;
        if (speaker == "마을 사람") return DialogueSpeakerKind.Villager;
        if (speaker.Contains("전갈자리") || speaker.Contains("대적자") || speaker.Contains("추방된 별")) return DialogueSpeakerKind.Boss;
        if (speaker.Contains("마나") || speaker.Contains("기록") || speaker.Contains("운명") || speaker.Contains("별하늘")) return DialogueSpeakerKind.Mystic;

        return DialogueSpeakerKind.Narration;
    }

    private void BuildDialogueUI()
    {
        // 사용자가 지정한 한글 TMP SDF 폰트를 먼저 불러옵니다.
        // 이 폰트는 Assets/Scene/Hakgyoansim Byeolbichhaneul TTF B SDF.asset 파일입니다.
        // startstory 씬의 기존 TMP 텍스트도 같은 guid의 폰트를 쓰고 있어서, 자동 생성 대화창도 글꼴이 통일됩니다.
        dialogueFontAsset = LoadDialogueFontAsset();

        canvas = FindFirstObjectByType<Canvas>();
        if (canvas == null)
        {
            GameObject canvasObject = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;

            CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.matchWidthOrHeight = 0.5f;
        }

        Transform root = CreateUIObject("Limbus Style Dialogue", canvas.transform, typeof(Image), typeof(Button)).transform;
        Stretch(root.GetComponent<RectTransform>());
        touchButton = root.GetComponent<Button>();
        touchButton.transition = Selectable.Transition.None;
        touchButton.onClick.RemoveAllListeners();
        touchButton.onClick.AddListener(OnTouchDialogue);

        // root의 Image는 투명하지만 raycastTarget은 켜져 있어서 화면 전체 터치를 받을 수 있습니다.
        Image rootImage = root.GetComponent<Image>();
        rootImage.color = new Color(0f, 0f, 0f, 0f);
        rootImage.raycastTarget = true;

        backgroundImage = CreateFullScreenImage(root, "Story Background", new Color(0.02f, 0.03f, 0.08f, 1f));
        backgroundImage.transform.SetAsFirstSibling();

        dimImage = CreateFullScreenImage(root, "Background Dim", new Color(0f, 0f, 0f, 0.26f));
        dimImage.transform.SetSiblingIndex(1);

        CreateSpeakerCutsceneLayer(root);

        Transform dialogueBox = CreatePanel(root, "Dialogue Box", new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0f, 116f), new Vector2(-140f, 230f));
        dialogueBoxRoot = dialogueBox.GetComponent<RectTransform>();
        dialogueBoxImage = dialogueBox.GetComponent<Image>();
        dialogueBoxImage.color = new Color(0.015f, 0.017f, 0.024f, 0.92f);

        Transform portraitFrame = CreatePanel(dialogueBox, "Speaker Portrait Frame", new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(108f, 10f), new Vector2(132f, 154f));
        portraitFrameImage = portraitFrame.GetComponent<Image>();
        portraitFrameImage.color = new Color(0.08f, 0.13f, 0.22f, 0.95f);

        GameObject portraitObject = CreateUIObject("Speaker Portrait", portraitFrame, typeof(Image));
        RectTransform portraitRect = portraitObject.GetComponent<RectTransform>();
        portraitRect.anchorMin = Vector2.zero;
        portraitRect.anchorMax = Vector2.one;
        portraitRect.offsetMin = new Vector2(8f, 8f);
        portraitRect.offsetMax = new Vector2(-8f, -8f);
        portraitImage = portraitObject.GetComponent<Image>();
        portraitImage.preserveAspect = true;
        portraitImage.raycastTarget = false;

        Transform speakerPlate = CreatePanel(dialogueBox, "Speaker Plate", new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(300f, -6f), new Vector2(320f, 58f));
        speakerPlateImage = speakerPlate.GetComponent<Image>();
        speakerPlateImage.color = new Color(0.12f, 0.03f, 0.035f, 0.96f);

        speakerText = CreateTMPText(speakerPlate, "Speaker", "???", 28, TextAlignmentOptions.Center, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        bodyText = CreateTMPText(dialogueBox, "Body", "", 34, TextAlignmentOptions.TopLeft, Vector2.zero, Vector2.one, new Vector2(0f, -22f), new Vector2(-140f, -76f));
        RectTransform bodyRect = bodyText.GetComponent<RectTransform>();
        bodyRect.offsetMin = new Vector2(196f, 34f);
        bodyRect.offsetMax = new Vector2(-54f, -70f);

        continueText = CreateTMPText(dialogueBox, "Continue", "TOUCH", 20, TextAlignmentOptions.Center, new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(-88f, 36f), new Vector2(110f, 34f));
        continueText.alpha = 0f;

        CreateStoryControlButtons(root);
    }

    private void CreateSpeakerCutsceneLayer(Transform root)
    {
        GameObject cutsceneObject = CreateUIObject("Speaker Dialogue Cutscene", root, typeof(CanvasGroup));
        speakerCutsceneRoot = cutsceneObject.GetComponent<RectTransform>();
        speakerCutsceneRoot.anchorMin = new Vector2(0.42f, 0.22f);
        speakerCutsceneRoot.anchorMax = new Vector2(1.03f, 1.04f);
        speakerCutsceneRoot.offsetMin = Vector2.zero;
        speakerCutsceneRoot.offsetMax = Vector2.zero;
        speakerCutsceneRoot.anchoredPosition = new Vector2(-88f, -18f);

        speakerCutsceneCanvasGroup = cutsceneObject.GetComponent<CanvasGroup>();
        speakerCutsceneCanvasGroup.alpha = 0f;
        speakerCutsceneCanvasGroup.interactable = false;
        speakerCutsceneCanvasGroup.blocksRaycasts = false;

        GameObject imageObject = CreateUIObject("Hero Cutscene Image", cutsceneObject.transform, typeof(Image));
        RectTransform imageRect = imageObject.GetComponent<RectTransform>();
        imageRect.anchorMin = Vector2.zero;
        imageRect.anchorMax = Vector2.one;
        imageRect.offsetMin = Vector2.zero;
        imageRect.offsetMax = Vector2.zero;

        speakerCutsceneImage = imageObject.GetComponent<Image>();
        speakerCutsceneImage.sprite = LoadSpriteFromResources("DialoguePortraits/Optimized/HeroCutscene");
        speakerCutsceneImage.preserveAspect = true;
        speakerCutsceneImage.raycastTarget = false;
        speakerCutsceneImage.color = Color.white;

        cutsceneObject.SetActive(false);
    }

    private void CreateStoryControlButtons(Transform root)
    {
        GameObject controlsObject = CreateUIObject("Story Controls", root, typeof(HorizontalLayoutGroup));
        RectTransform rect = controlsObject.GetComponent<RectTransform>();
        storyControlsRoot = rect;
        rect.anchorMin = new Vector2(1f, 1f);
        rect.anchorMax = new Vector2(1f, 1f);
        rect.pivot = new Vector2(1f, 1f);
        rect.anchoredPosition = new Vector2(-42f, -34f);
        rect.sizeDelta = new Vector2(300f, 56f);

        HorizontalLayoutGroup layout = controlsObject.GetComponent<HorizontalLayoutGroup>();
        layout.spacing = 12f;
        layout.padding = new RectOffset(0, 0, 0, 0);
        layout.childAlignment = TextAnchor.MiddleRight;
        layout.childControlWidth = true;
        layout.childControlHeight = true;
        layout.childForceExpandWidth = false;
        layout.childForceExpandHeight = false;

        CreateStoryControlButton(controlsObject.transform, "Start Battle Button", "시작", OnStartFromStory, new Color(0.16f, 0.075f, 0.035f, 0.94f));
        CreateStoryControlButton(controlsObject.transform, "Exit Story Button", "나가기", OnExitStory, new Color(0.035f, 0.055f, 0.09f, 0.94f));
    }

    private Button CreateStoryControlButton(Transform parent, string objectName, string label, UnityEngine.Events.UnityAction action, Color backgroundColor)
    {
        GameObject buttonObject = CreateUIObject(objectName, parent, typeof(Image), typeof(Button), typeof(LayoutElement));
        RectTransform rect = buttonObject.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(140f, 52f);

        LayoutElement layout = buttonObject.GetComponent<LayoutElement>();
        layout.preferredWidth = 140f;
        layout.preferredHeight = 52f;

        Image image = buttonObject.GetComponent<Image>();
        image.color = backgroundColor;
        image.raycastTarget = true;

        Button button = buttonObject.GetComponent<Button>();
        button.transition = Selectable.Transition.ColorTint;
        ColorBlock colors = button.colors;
        colors.normalColor = Color.white;
        colors.highlightedColor = new Color(1.15f, 1.15f, 1.15f, 1f);
        colors.pressedColor = new Color(0.78f, 0.78f, 0.78f, 1f);
        colors.selectedColor = Color.white;
        colors.colorMultiplier = 1f;
        button.colors = colors;
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(action);

        TMP_Text labelText = CreateTMPText(buttonObject.transform, objectName + " Label", label, 24, TextAlignmentOptions.Center, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        labelText.fontStyle = FontStyles.Bold;
        labelText.color = new Color(0.96f, 0.97f, 1f);

        return button;
    }

    private void ShowEntry(int index)
    {
        if (index >= entries.Length)
        {
            EndDialogue();
            return;
        }

        currentIndex = index;
        DialogueEntry entry = entries[currentIndex];

        speakerText.text = entry.speaker;
        continueText.alpha = 0f;
        isWaitingForAutoAdvance = false;

        ApplyDialogueStyle(entry);
        ApplyBackground(entry);
        ApplySpeakerCutscene(entry);

        if (typingCoroutine != null) StopCoroutine(typingCoroutine);
        if (autoAdvanceCoroutine != null) StopCoroutine(autoAdvanceCoroutine);
        typingCoroutine = StartCoroutine(TypeLine(entry.line));
    }

    private IEnumerator TypeLine(string line)
    {
        isTyping = true;
        bodyText.text = line;
        bodyText.maxVisibleCharacters = 0;
        WaitForSeconds characterDelay = new WaitForSeconds(characterInterval);

        for (int i = 0; i < line.Length; i++)
        {
            bodyText.maxVisibleCharacters = i + 1;
            yield return characterDelay;
        }

        CompleteCurrentLine();
    }

    private void CompleteCurrentLine()
    {
        // 현재 문장을 즉시 완성하는 함수입니다.
        // 타이핑 도중 터치했을 때도 이 함수가 호출됩니다.
        if (typingCoroutine != null)
        {
            StopCoroutine(typingCoroutine);
            typingCoroutine = null;
        }

        isTyping = false;
        bodyText.text = entries[currentIndex].line;
        bodyText.maxVisibleCharacters = int.MaxValue;
        continueText.alpha = 1f;

        if (!isWaitingForAutoAdvance)
        {
            float delay = (entries[currentIndex].waitAfterComplete > 0f ? entries[currentIndex].waitAfterComplete : defaultAutoAdvanceDelay) + autoAdvanceExtraDelay;
            autoAdvanceCoroutine = StartCoroutine(AutoAdvanceAfterDelay(delay));
        }
    }

    private IEnumerator AutoAdvanceAfterDelay(float delay)
    {
        isWaitingForAutoAdvance = true;
        yield return new WaitForSeconds(delay);
        isWaitingForAutoAdvance = false;
        AdvanceToNextEntry();
    }

    private void OnTouchDialogue()
    {
        // 터치/클릭의 동작은 현재 상태에 따라 달라집니다.
        // 1. 글자가 아직 타이핑 중이면: 문장을 즉시 끝까지 보여줍니다.
        // 2. 문장이 이미 끝났으면: 자동 진행을 기다리지 않고 다음 대사로 넘어갑니다.
        // 3. 엔딩 크레딧 중이면: 메인 화면으로 돌아갑니다.
        // Update 입력과 UI Button 입력이 같은 클릭을 동시에 받을 수 있어 짧게 한 번만 처리합니다.
        if (Time.unscaledTime - lastTouchHandledTime < TouchDebounceSeconds) return;
        lastTouchHandledTime = Time.unscaledTime;

        if (endingCreditsPlaying)
        {
            FinishEndingSequence();
            return;
        }

        if (entries == null || entries.Length == 0) return;

        if (isTyping)
        {
            CompleteCurrentLine();
            return;
        }

        AdvanceToNextEntry();
    }

    private void AdvanceToNextEntry()
    {
        if (autoAdvanceCoroutine != null)
        {
            StopCoroutine(autoAdvanceCoroutine);
            autoAdvanceCoroutine = null;
        }

        ShowEntry(currentIndex + 1);
    }

    private void OnStartFromStory()
    {
        StopDialogueCoroutines();

        if (StoryBattleFlow.IsFullStoryMode || StoryBattleFlow.IsFinalStory)
        {
            StoryBattleFlow.BattleStageIndex = 0;
            StoryBattleFlow.StorySegmentIndex = 0;
        }

        StoryBattleFlow.LoadCurrentBattleStage();
    }

    private void OnExitStory()
    {
        StopDialogueCoroutines();
        StoryBattleFlow.LoadInterfaceAfterEnding();
    }

    private void StopDialogueCoroutines()
    {
        if (typingCoroutine != null)
        {
            StopCoroutine(typingCoroutine);
            typingCoroutine = null;
        }

        if (autoAdvanceCoroutine != null)
        {
            StopCoroutine(autoAdvanceCoroutine);
            autoAdvanceCoroutine = null;
        }
    }

    private void ApplySpeakerCutscene(DialogueEntry entry)
    {
        if (speakerCutsceneRoot == null || speakerCutsceneImage == null || speakerCutsceneCanvasGroup == null) return;

        Sprite sprite = LoadDialogueCutsceneSprite(entry);
        speakerCutsceneRoot.DOKill();
        speakerCutsceneCanvasGroup.DOKill();

        if (sprite == null)
        {
            speakerCutsceneCanvasGroup.alpha = 0f;
            speakerCutsceneRoot.gameObject.SetActive(false);
            return;
        }

        Vector2 startPosition;
        Vector2 endPosition;
        Vector3 startScale;
        ConfigureSpeakerCutsceneLayout(entry, out startPosition, out endPosition, out startScale);

        speakerCutsceneImage.sprite = sprite;
        speakerCutsceneImage.color = Color.white;
        speakerCutsceneRoot.gameObject.SetActive(true);
        speakerCutsceneRoot.anchoredPosition = startPosition;
        speakerCutsceneRoot.localScale = startScale;
        speakerCutsceneCanvasGroup.alpha = 0f;

        // 말하는 인물마다 화면 위쪽 컷인으로 살짝 들어오게 해서 대화 장면이 더 또렷하게 느껴지게 합니다.
        speakerCutsceneCanvasGroup.DOFade(0.96f, 0.22f).SetEase(Ease.OutQuad);
        speakerCutsceneRoot.DOAnchorPos(endPosition, 0.28f).SetEase(Ease.OutCubic);
        speakerCutsceneRoot.DOScale(Vector3.one, 0.28f).SetEase(Ease.OutBack);
    }

    private Sprite LoadDialogueCutsceneSprite(DialogueEntry entry)
    {
        // 나레이션은 인물이 없는 장면 설명이라 컷인을 숨깁니다.
        // 그 외 화자는 기존 대화 초상화를 크게 띄우고, 주인공만 별도 전신 컷씬 그림을 우선 사용합니다.
        if (entry.speakerKind == DialogueSpeakerKind.Narration) return null;

        if (entry.speakerKind == DialogueSpeakerKind.Hero)
        {
            return LoadSpriteFromResources("DialoguePortraits/Optimized/HeroCutscene") ??
                   LoadSpriteFromResources("DialoguePortraits/Optimized/Hero") ??
                   CreateGeneratedPortraitSprite(entry.speakerKind);
        }

        return LoadDialoguePortraitSprite(entry);
    }

    private void ConfigureSpeakerCutsceneLayout(DialogueEntry entry, out Vector2 startPosition, out Vector2 endPosition, out Vector3 startScale)
    {
        // 주인공은 오른쪽, 다른 주요 인물은 왼쪽이나 중앙 쪽으로 배치해서
        // 같은 컷인 방식이어도 누가 말하는지 화면 구도가 바로 갈리게 합니다.
        switch (entry.speakerKind)
        {
            case DialogueSpeakerKind.Hero:
                speakerCutsceneRoot.anchorMin = new Vector2(0.42f, 0.20f);
                speakerCutsceneRoot.anchorMax = new Vector2(1.03f, 1.04f);
                startPosition = new Vector2(-56f, -8f);
                endPosition = new Vector2(-96f, -14f);
                startScale = Vector3.one * 0.98f;
                return;
            case DialogueSpeakerKind.Boss:
                speakerCutsceneRoot.anchorMin = new Vector2(-0.02f, 0.22f);
                speakerCutsceneRoot.anchorMax = new Vector2(0.54f, 0.96f);
                startPosition = new Vector2(-42f, -16f);
                endPosition = new Vector2(28f, -16f);
                startScale = Vector3.one * 0.94f;
                return;
            case DialogueSpeakerKind.Villager:
                speakerCutsceneRoot.anchorMin = new Vector2(0.02f, 0.24f);
                speakerCutsceneRoot.anchorMax = new Vector2(0.46f, 0.92f);
                startPosition = new Vector2(-34f, -10f);
                endPosition = new Vector2(34f, -10f);
                startScale = Vector3.one * 0.94f;
                return;
            case DialogueSpeakerKind.Mystic:
                speakerCutsceneRoot.anchorMin = new Vector2(0.08f, 0.26f);
                speakerCutsceneRoot.anchorMax = new Vector2(0.52f, 0.96f);
                startPosition = new Vector2(-28f, 4f);
                endPosition = new Vector2(42f, 4f);
                startScale = Vector3.one * 0.95f;
                return;
            default:
                speakerCutsceneRoot.anchorMin = new Vector2(0.42f, 0.22f);
                speakerCutsceneRoot.anchorMax = new Vector2(1.03f, 1.04f);
                startPosition = new Vector2(-56f, -8f);
                endPosition = new Vector2(-96f, -14f);
                startScale = Vector3.one * 0.98f;
                return;
        }
    }

    private void ApplyDialogueStyle(DialogueEntry entry)
    {
        if (dialogueBoxImage == null || speakerPlateImage == null || portraitFrameImage == null || portraitImage == null) return;

        Color boxColor;
        Color speakerColor;
        Color frameColor;
        Color portraitTint;

        switch (entry.speakerKind)
        {
            case DialogueSpeakerKind.Hero:
                boxColor = new Color(0.012f, 0.032f, 0.075f, 0.94f);
                speakerColor = new Color(0.05f, 0.18f, 0.34f, 0.98f);
                frameColor = new Color(0.16f, 0.28f, 0.46f, 0.96f);
                portraitTint = Color.white;
                break;
            case DialogueSpeakerKind.Villager:
                boxColor = new Color(0.045f, 0.035f, 0.024f, 0.94f);
                speakerColor = new Color(0.22f, 0.14f, 0.065f, 0.98f);
                frameColor = new Color(0.34f, 0.24f, 0.12f, 0.96f);
                portraitTint = Color.white;
                break;
            case DialogueSpeakerKind.Boss:
                boxColor = new Color(0.045f, 0.008f, 0.024f, 0.95f);
                speakerColor = new Color(0.32f, 0.02f, 0.07f, 0.99f);
                frameColor = new Color(0.46f, 0.04f, 0.18f, 0.98f);
                portraitTint = Color.white;
                break;
            case DialogueSpeakerKind.Mystic:
                boxColor = new Color(0.018f, 0.016f, 0.062f, 0.94f);
                speakerColor = new Color(0.12f, 0.075f, 0.28f, 0.98f);
                frameColor = new Color(0.24f, 0.18f, 0.46f, 0.96f);
                portraitTint = Color.white;
                break;
            default:
                boxColor = new Color(0.015f, 0.017f, 0.024f, 0.92f);
                speakerColor = new Color(0.12f, 0.03f, 0.035f, 0.96f);
                frameColor = new Color(0.08f, 0.13f, 0.22f, 0.95f);
                portraitTint = Color.white;
                break;
        }

        dialogueBoxImage.color = boxColor;
        speakerPlateImage.color = speakerColor;
        portraitFrameImage.color = frameColor;
        portraitImage.sprite = LoadDialoguePortraitSprite(entry);
        portraitImage.color = portraitTint;
    }

    private Sprite LoadDialoguePortraitSprite(DialogueEntry entry)
    {
        if (entry.speakerKind == DialogueSpeakerKind.Hero)
        {
            return LoadSpriteFromResources("DialoguePortraits/Optimized/Hero") ?? CreateGeneratedPortraitSprite(entry.speakerKind);
        }

        if (entry.speakerKind == DialogueSpeakerKind.Villager)
        {
            return LoadSpriteFromResources("DialoguePortraits/Optimized/Villager") ?? CreateGeneratedPortraitSprite(entry.speakerKind);
        }

        if (entry.speakerKind == DialogueSpeakerKind.Boss)
        {
            if (entry.speaker.Contains("전갈자리"))
            {
                return LoadSpriteFromResources("DialoguePortraits/Optimized/FallenScorpio") ?? CreateGeneratedPortraitSprite(entry.speakerKind);
            }

            if (entry.speaker.Contains("대적자") || entry.speaker.Contains("추방된 별"))
            {
                return LoadSpriteFromResources("DialoguePortraits/Optimized/StarAdversary") ?? CreateGeneratedPortraitSprite(entry.speakerKind);
            }
        }

        if (entry.speakerKind == DialogueSpeakerKind.Mystic)
        {
            if (entry.speaker.Contains("마나"))
            {
                return LoadSpriteFromResources("DialoguePortraits/Optimized/MoonMana") ?? CreateGeneratedPortraitSprite(entry.speakerKind);
            }

            if (entry.speaker.Contains("운명"))
            {
                return LoadSpriteFromResources("DialoguePortraits/Optimized/Fate") ?? CreateGeneratedPortraitSprite(entry.speakerKind);
            }

            return LoadSpriteFromResources("DialoguePortraits/Optimized/StarRecord") ?? CreateGeneratedPortraitSprite(entry.speakerKind);
        }

        if (entry.speakerKind == DialogueSpeakerKind.Narration)
        {
            return LoadSpriteFromResources("StoryBackgrounds/" + GetStoryBackgroundResourceName(entry.backgroundIndex)) ?? CreateGeneratedPortraitSprite(entry.speakerKind);
        }

        return CreateGeneratedPortraitSprite(entry.speakerKind);
    }

    private Sprite LoadSpriteFromResources(string resourcePath)
    {
        if (dialoguePortraitCache.TryGetValue(resourcePath, out Sprite cachedSprite))
        {
            return cachedSprite;
        }

        Texture2D texture = Resources.Load<Texture2D>(resourcePath);
        if (texture == null)
        {
            dialoguePortraitCache[resourcePath] = null;
            return null;
        }

        Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
        dialoguePortraitCache[resourcePath] = sprite;
        return sprite;
    }

    private Sprite CreateGeneratedPortraitSprite(DialogueSpeakerKind speakerKind)
    {
        if (generatedPortraitCache.TryGetValue(speakerKind, out Sprite cachedSprite))
        {
            return cachedSprite;
        }

        int size = 96;
        Texture2D texture = new Texture2D(size, size);
        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                Vector2 point = new Vector2(x, y);
                float distance = Vector2.Distance(point, center);
                bool outerGlow = distance < 45f && distance > 39f;
                bool head = Vector2.Distance(point, new Vector2(center.x, 58f)) < 16f;
                bool body = Mathf.Abs(x - center.x) < 25f && y > 16f && y < 43f;
                bool shoulder = Vector2.Distance(point, new Vector2(center.x, 24f)) < 30f && y < 31f;
                bool star = (Mathf.Abs(x - 72f) < 2f && y > 63f && y < 83f) || (Mathf.Abs(y - 73f) < 2f && x > 62f && x < 82f);

                float alpha = 0f;
                if (outerGlow) alpha = 0.55f;
                if (head || body || shoulder) alpha = 0.95f;
                if (star) alpha = 1f;

                texture.SetPixel(x, y, alpha > 0f ? new Color(1f, 1f, 1f, alpha) : Color.clear);
            }
        }

        texture.Apply();
        Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f));
        generatedPortraitCache[speakerKind] = sprite;
        return sprite;
    }

    private void ApplyBackground(DialogueEntry entry)
    {
        // 이야기 장면에 맞는 배경 일러스트가 있으면 우선 사용합니다.
        Sprite storyBackground = LoadStoryBackgroundSprite(entry.backgroundIndex);
        if (storyBackground != null)
        {
            backgroundImage.sprite = storyBackground;
            backgroundImage.color = Color.white;
            return;
        }

        // 배경 이미지가 누락되어도 스토리가 깨지지 않도록 그라데이션으로 fallback합니다.
        backgroundImage.sprite = GetGradientBackgroundSprite(entry.topColor, entry.bottomColor);
        backgroundImage.color = Color.white;
    }

    private Sprite GetGradientBackgroundSprite(Color top, Color bottom)
    {
        string key = ColorUtility.ToHtmlStringRGBA(top) + "_" + ColorUtility.ToHtmlStringRGBA(bottom);
        if (gradientBackgroundCache.TryGetValue(key, out Sprite cachedSprite))
        {
            return cachedSprite;
        }

        Texture2D texture = CreateGradientTexture(top, bottom);
        Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f));
        gradientBackgroundCache[key] = sprite;
        return sprite;
    }

    private Sprite LoadStoryBackgroundSprite(int backgroundIndex)
    {
        if (storyBackgroundCache.TryGetValue(backgroundIndex, out Sprite cachedSprite))
        {
            return cachedSprite;
        }

        string resourceName = GetStoryBackgroundResourceName(backgroundIndex);
        Texture2D texture = Resources.Load<Texture2D>("StoryBackgrounds/" + resourceName);
        if (texture == null)
        {
            storyBackgroundCache[backgroundIndex] = null;
            return null;
        }

        Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f));
        storyBackgroundCache[backgroundIndex] = sprite;
        return sprite;
    }

    private string GetStoryBackgroundResourceName(int backgroundIndex)
    {
        switch (backgroundIndex)
        {
            case 1:
                return "StoryCity";
            case 2:
                return "StoryScorpioPalace";
            case 3:
                return "StoryArena";
            case 4:
                return "StoryEnding";
            default:
                return "StoryPrologue";
        }
    }

    private void BeginEndingSequence()
    {
        // 마지막 스토리 뒤에는 바로 메뉴로 돌아가지 않고 엔딩 크레딧을 보여줍니다.
        // 기존 대화 UI를 통째로 갈아엎지 않고 같은 startstory 씬 위에 오버레이만 얹는 방식이라 씬 흐름이 단순합니다.
        if (endingSequenceActive) return;

        StopDialogueCoroutines();
        SetDialogueChromeVisible(false);
        EnsureEndingSequenceUI();

        endingSequenceActive = true;
        endingCreditsPlaying = false;

        if (backgroundImage != null)
        {
            backgroundImage.sprite = LoadSpriteFromResources("StoryBackgrounds/StoryEnding") ?? backgroundImage.sprite;
            backgroundImage.color = Color.white;
        }

        if (dimImage != null)
        {
            dimImage.color = new Color(0f, 0f, 0f, 0.58f);
        }

        endingSequenceRoot.SetActive(true);
        endingSequenceCanvasGroup.alpha = 0f;

        if (endingSequenceCoroutine != null)
        {
            StopCoroutine(endingSequenceCoroutine);
        }

        endingSequenceCoroutine = StartCoroutine(PlayEndingCreditsSequence());
    }

    private IEnumerator PlayEndingCreditsSequence()
    {
        yield return FadeEndingOverlay(0f, 1f, 0.8f);

        endingCreditsPlaying = true;
        endingCreditsViewportRoot.SetActive(true);

        endingCreditsText.text = GetEndingCreditText();
        endingCreditsText.maxVisibleCharacters = int.MaxValue;

        float startY = -940f;
        float endY = 1060f;
        float duration = 22f;
        float elapsed = 0f;

        while (elapsed < duration && endingCreditsPlaying)
        {
            float t = Mathf.Clamp01(elapsed / duration);
            float eased = Mathf.SmoothStep(0f, 1f, t);
            endingCreditsRect.anchoredPosition = new Vector2(0f, Mathf.Lerp(startY, endY, eased));
            elapsed += Time.deltaTime;
            yield return null;
        }

        if (endingCreditsPlaying)
        {
            FinishEndingSequence();
        }
    }

    private IEnumerator FadeEndingOverlay(float from, float to, float duration)
    {
        float elapsed = 0f;
        while (elapsed < duration)
        {
            float t = Mathf.Clamp01(elapsed / duration);
            endingSequenceCanvasGroup.alpha = Mathf.Lerp(from, to, Mathf.SmoothStep(0f, 1f, t));
            elapsed += Time.deltaTime;
            yield return null;
        }

        endingSequenceCanvasGroup.alpha = to;
    }

    private void FinishEndingSequence()
    {
        if (!endingSequenceActive) return;

        if (endingSequenceCoroutine != null)
        {
            StopCoroutine(endingSequenceCoroutine);
            endingSequenceCoroutine = null;
        }

        endingSequenceActive = false;
        endingCreditsPlaying = false;
        StoryBattleFlow.LoadInterfaceAfterEnding();
    }

    private void EnsureEndingSequenceUI()
    {
        if (endingSequenceRoot != null) return;

        Transform parent = touchButton != null ? touchButton.transform : canvas.transform;
        endingSequenceRoot = CreateUIObject("Ending Sequence", parent, typeof(CanvasGroup));
        Stretch(endingSequenceRoot.GetComponent<RectTransform>());
        endingSequenceCanvasGroup = endingSequenceRoot.GetComponent<CanvasGroup>();
        endingSequenceCanvasGroup.interactable = false;
        endingSequenceCanvasGroup.blocksRaycasts = false;

        Image softShade = CreateFullScreenImage(endingSequenceRoot.transform, "Ending Soft Shade", new Color(0f, 0f, 0f, 0.24f));
        softShade.raycastTarget = false;

        endingCreditsViewportRoot = CreateUIObject("Ending Credits Viewport", endingSequenceRoot.transform, typeof(RectMask2D));
        RectTransform viewportRect = endingCreditsViewportRoot.GetComponent<RectTransform>();
        viewportRect.anchorMin = new Vector2(0.16f, 0.08f);
        viewportRect.anchorMax = new Vector2(0.84f, 0.92f);
        viewportRect.offsetMin = Vector2.zero;
        viewportRect.offsetMax = Vector2.zero;

        endingCreditsText = CreateTMPText(endingCreditsViewportRoot.transform, "Ending Credits Text", "", 34, TextAlignmentOptions.Center, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), Vector2.zero, new Vector2(1100f, 1550f));
        endingCreditsRect = endingCreditsText.GetComponent<RectTransform>();
        endingCreditsText.color = new Color(0.95f, 0.97f, 1f);
        endingCreditsText.fontStyle = FontStyles.Bold;
        endingCreditsText.lineSpacing = 18f;
        endingCreditsText.textWrappingMode = TextWrappingModes.Normal;

        endingSequenceRoot.SetActive(false);
    }

    private string GetEndingCreditText()
    {
        return
            "<size=56>13성좌 카드 배틀</size>\n\n" +
            "<size=34>ENDING CREDITS</size>\n\n\n" +
            "기획\n플레이어\n\n" +
            "전투 디자인\n13성좌의 기억\n\n" +
            "스토리\n별의 기록\n\n" +
            "캐릭터\n달빛 아래 깨어난 주인공\n\n" +
            "적과 보스\n공허의 울음꾼\n탁한 별가루 집행자\n타락한 황도13궁 전갈\n별의 대적자\n\n" +
            "음악\nCelestial Whispering Veils\nWhispers of the Santa Claus\nTriumph of the Unknown\n\n" +
            "스페셜 Thanks\n마지막 별까지 이어 준 당신\n\n\n" +
            "밤하늘은 다시 이어졌고\n그 빛은 평범한 하루에도 남았다.";
    }

    private void SetDialogueChromeVisible(bool visible)
    {
        if (dialogueBoxRoot != null)
        {
            dialogueBoxRoot.gameObject.SetActive(visible);
        }

        if (storyControlsRoot != null)
        {
            storyControlsRoot.gameObject.SetActive(visible);
        }

        if (!visible && speakerCutsceneRoot != null)
        {
            speakerCutsceneRoot.DOKill();
            speakerCutsceneRoot.gameObject.SetActive(false);
        }

        if (continueText != null)
        {
            continueText.alpha = 0f;
        }
    }

    private void EndDialogue()
    {
        // 모든 대사가 끝났을 때 다음 씬으로 이동합니다.
        // 0~3번 스토리는 전투 사이에 나오는 이야기이므로 BattleScene으로 돌아갑니다.
        // 4번 스토리는 엔딩이므로 크레딧을 본 뒤 intface 씬으로 돌아갑니다.
        if (StoryBattleFlow.IsFullStoryMode || StoryBattleFlow.IsFinalStory)
        {
            BeginEndingSequence();
        }
        else
        {
            StoryBattleFlow.LoadCurrentBattleStage();
        }
    }

    private void EnsureEventSystem()
    {
        if (FindFirstObjectByType<EventSystem>() != null) return;
        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
    }

    private Texture2D CreateGradientTexture(Color top, Color bottom)
    {
        int width = 16;
        int height = 256;
        Texture2D texture = new Texture2D(width, height);

        for (int y = 0; y < height; y++)
        {
            float t = y / (float)(height - 1);
            Color color = Color.Lerp(bottom, top, t);
            for (int x = 0; x < width; x++)
            {
                texture.SetPixel(x, y, color);
            }
        }

        texture.Apply();
        return texture;
    }

    private Image CreateFullScreenImage(Transform parent, string objectName, Color color)
    {
        GameObject go = CreateUIObject(objectName, parent, typeof(Image));
        Stretch(go.GetComponent<RectTransform>());
        Image image = go.GetComponent<Image>();
        image.color = color;
        image.raycastTarget = false;
        return image;
    }

    private Transform CreatePanel(Transform parent, string objectName, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
    {
        GameObject go = CreateUIObject(objectName, parent, typeof(Image));
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = sizeDelta;
        return go.transform;
    }

    private TMP_Text CreateTMPText(Transform parent, string objectName, string value, int size, TextAlignmentOptions alignment, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPosition, Vector2 sizeDelta)
    {
        GameObject go = CreateUIObject(objectName, parent, typeof(TextMeshProUGUI));
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = sizeDelta;

        TMP_Text text = go.GetComponent<TMP_Text>();
        text.text = value;
        if (dialogueFontAsset != null) text.font = dialogueFontAsset;
        text.fontSize = size;
        text.alignment = alignment;
        text.color = Color.white;
        text.textWrappingMode = TextWrappingModes.Normal;
        text.raycastTarget = false;
        ReadableTextStyle.Apply(text);
        return text;
    }

    private TMP_FontAsset LoadDialogueFontAsset()
    {
        // 빌드본에서는 UnityEditor.AssetDatabase를 사용할 수 없습니다.
        // 그래서 Resources/Fonts의 한글 TTF를 기반으로 TMP 폰트를 런타임 생성합니다.
        return ReadableTextStyle.GetReadableTMPFont();
    }

    private GameObject CreateUIObject(string objectName, Transform parent, params System.Type[] components)
    {
        System.Type[] allComponents = new System.Type[components.Length + 2];
        allComponents[0] = typeof(RectTransform);
        allComponents[1] = typeof(CanvasRenderer);
        for (int i = 0; i < components.Length; i++)
        {
            allComponents[i + 2] = components[i];
        }

        GameObject go = new GameObject(objectName, allComponents);
        go.transform.SetParent(parent, false);
        return go;
    }

    private void Stretch(RectTransform rect)
    {
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }
}
