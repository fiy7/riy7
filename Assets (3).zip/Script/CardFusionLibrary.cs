using UnityEngine;

public static class CardFusionLibrary
{
    public const string FusionRuleIntro = "같은 플레이어 턴에 앞 카드 -> 뒤 카드 순서로 바로 쓰면, 뒤 카드 기본 효과가 끝난 직후 연성 보너스가 발동합니다.";

    private static bool hasPreviousCard;
    private static CardDate.CardAbility previousAbility;
    private static string previousCardName;

    public static void ResetTurn()
    {
        hasPreviousCard = false;
        previousCardName = string.Empty;
    }

    public static void ResolveAfterCard(CardDate currentCard)
    {
        if (currentCard == null) return;
        if (!hasPreviousCard) return;
        if (BattleManager.Instance == null || BattleManager.Instance.IsBattleEnded) return;

        TryTriggerFusion(previousAbility, currentCard.ability);
    }

    public static void RecordCard(CardDate currentCard)
    {
        if (currentCard == null) return;

        hasPreviousCard = true;
        previousAbility = currentCard.ability;
        previousCardName = currentCard.cardName;
    }

    public static string GetFusionHint(CardDate.CardAbility ability)
    {
        switch (ability)
        {
            case CardDate.CardAbility.AriesStrike:
                return "양자리 -> 황소자리: 성각돌진, 선택한 적 14 피해 + 수면 1턴.";
            case CardDate.CardAbility.TaurusCharge:
                return "황소자리 -> 쌍둥이자리: 철벽쌍성, 방어막 16 + 다음 공격 1.25배.";
            case CardDate.CardAbility.GeminiShield:
                return "쌍둥이자리 -> 게자리: 거울해일, 모든 적 10 피해 + 방어막 10.";
            case CardDate.CardAbility.CancerCrush:
                return "게자리 -> 사자자리: 왕관집게, 모든 적 12 피해 + 다음 공격 1.3배.";
            case CardDate.CardAbility.LeoEcho:
                return "사자자리 -> 처녀자리: 백야의 포효, 선택한 적 16 피해 + 피해 제한/정화.";
            case CardDate.CardAbility.VirgoVeil:
                return "처녀자리 -> 천칭자리: 정화저울, 체력 5 회복 + 공격 버프 1중첩.";
            case CardDate.CardAbility.LibraBalance:
                return "천칭자리 -> 전갈자리: 독의 균형, 선택한 적 8 피해 + 독 6 피해 3턴.";
            case CardDate.CardAbility.ScorpioPoison:
                return "전갈자리 -> 사수자리: 천독궁, 모든 적 16 피해 + 전체 풍화 2턴.";
            case CardDate.CardAbility.SagittariusUltimate:
                return "사수자리 -> 염소자리: 별산맥 낙성, 모든 적 18 피해 + 염소 중첩 1.";
            case CardDate.CardAbility.CapricornStack:
                return "염소자리 -> 물병자리: 산맥수맥, 모든 적 10 피해 + 기력 2 회복.";
            case CardDate.CardAbility.AquariusEnergy:
                return "물병자리 -> 물고기자리: 치유성류, 체력 12 회복 + 다음 공격 1.8배.";
            case CardDate.CardAbility.PiscesEmpower:
                return "물고기자리 -> 양자리: 새벽점화, 선택한 적 18 피해 + 수면 1턴.";
            default:
                return "연성 없음.";
        }
    }

    public static string BuildFusionGuideText()
    {
        return
            "연성 목록\n" +
            GetFusionHint(CardDate.CardAbility.AriesStrike) + "\n" +
            GetFusionHint(CardDate.CardAbility.TaurusCharge) + "\n" +
            GetFusionHint(CardDate.CardAbility.GeminiShield) + "\n" +
            GetFusionHint(CardDate.CardAbility.CancerCrush) + "\n" +
            GetFusionHint(CardDate.CardAbility.LeoEcho) + "\n" +
            GetFusionHint(CardDate.CardAbility.VirgoVeil) + "\n" +
            GetFusionHint(CardDate.CardAbility.LibraBalance) + "\n" +
            GetFusionHint(CardDate.CardAbility.ScorpioPoison) + "\n" +
            GetFusionHint(CardDate.CardAbility.SagittariusUltimate) + "\n" +
            GetFusionHint(CardDate.CardAbility.CapricornStack) + "\n" +
            GetFusionHint(CardDate.CardAbility.AquariusEnergy) + "\n" +
            GetFusionHint(CardDate.CardAbility.PiscesEmpower);
    }

    private static bool TryTriggerFusion(CardDate.CardAbility first, CardDate.CardAbility second)
    {
        BattleManager battle = BattleManager.Instance;
        if (battle == null) return false;

        if (first == CardDate.CardAbility.AriesStrike && second == CardDate.CardAbility.TaurusCharge)
        {
            battle.ApplySleepToEnemy(1);
            battle.DealDamageToEnemy(14f);
            Announce("성각돌진", "선택한 적 14 피해 + 수면 1턴");
            return true;
        }

        if (first == CardDate.CardAbility.TaurusCharge && second == CardDate.CardAbility.GeminiShield)
        {
            battle.AddShield(16f);
            battle.EmpowerNextAttack(1.25f);
            Announce("철벽쌍성", "방어막 16 + 다음 공격 1.25배");
            return true;
        }

        if (first == CardDate.CardAbility.GeminiShield && second == CardDate.CardAbility.CancerCrush)
        {
            battle.AddShield(10f);
            battle.DealDamageToAllEnemies(10f);
            Announce("거울해일", "모든 적 10 피해 + 방어막 10");
            return true;
        }

        if (first == CardDate.CardAbility.CancerCrush && second == CardDate.CardAbility.LeoEcho)
        {
            battle.DealDamageToAllEnemies(12f);
            battle.EmpowerNextAttack(1.3f);
            Announce("왕관집게", "모든 적 12 피해 + 다음 공격 1.3배");
            return true;
        }

        if (first == CardDate.CardAbility.LeoEcho && second == CardDate.CardAbility.VirgoVeil)
        {
            battle.DealDamageToEnemy(16f);
            battle.ActivateVirgoVeil(5f);
            Announce("백야의 포효", "선택한 적 16 피해 + 피해 제한/정화");
            return true;
        }

        if (first == CardDate.CardAbility.VirgoVeil && second == CardDate.CardAbility.LibraBalance)
        {
            battle.HealPlayer(5f);
            battle.AddBalanceBuff(1, 2);
            Announce("정화저울", "체력 5 회복 + 공격 버프 1중첩");
            return true;
        }

        if (first == CardDate.CardAbility.LibraBalance && second == CardDate.CardAbility.ScorpioPoison)
        {
            battle.DealDamageToEnemy(8f);
            battle.ApplyPoisonToEnemy(6f, 3);
            Announce("독의 균형", "선택한 적 8 피해 + 독 6 피해 3턴");
            return true;
        }

        if (first == CardDate.CardAbility.ScorpioPoison && second == CardDate.CardAbility.SagittariusUltimate)
        {
            battle.ApplyWeatheringToAllEnemies(2);
            battle.DealDamageToAllEnemies(16f);
            Announce("천독궁", "모든 적 16 피해 + 전체 풍화 2턴");
            return true;
        }

        if (first == CardDate.CardAbility.SagittariusUltimate && second == CardDate.CardAbility.CapricornStack)
        {
            battle.AddCapricornStack(3);
            battle.DealDamageToAllEnemies(18f);
            Announce("별산맥 낙성", "모든 적 18 피해 + 염소 중첩 1");
            return true;
        }

        if (first == CardDate.CardAbility.CapricornStack && second == CardDate.CardAbility.AquariusEnergy)
        {
            battle.DealDamageToAllEnemies(10f);
            battle.GainEnergy(2);
            Announce("산맥수맥", "모든 적 10 피해 + 기력 2 회복");
            return true;
        }

        if (first == CardDate.CardAbility.AquariusEnergy && second == CardDate.CardAbility.PiscesEmpower)
        {
            battle.HealPlayer(12f);
            battle.EmpowerNextAttack(1.8f);
            Announce("치유성류", "체력 12 회복 + 다음 공격 1.8배");
            return true;
        }

        if (first == CardDate.CardAbility.PiscesEmpower && second == CardDate.CardAbility.AriesStrike)
        {
            battle.ApplySleepToEnemy(1);
            battle.DealDamageToEnemy(18f);
            Announce("새벽점화", "선택한 적 18 피해 + 수면 1턴");
            return true;
        }

        return false;
    }

    private static void Announce(string fusionName, string effectText)
    {
        string previousText = string.IsNullOrEmpty(previousCardName) ? "직전 카드" : previousCardName;
        string message = $"연성: {fusionName}\n{previousText}의 별빛이 이어졌습니다.\n{effectText}";
        Debug.Log(message);

        if (UIManager.Instance != null && BattleManager.Instance != null && !BattleManager.Instance.IsBattleEnded)
        {
            UIManager.Instance.ShowTurnNotice(message, 2.8f);
        }
    }
}
