using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// 씬 이동 버튼용 컴포넌트입니다.
// 이 파일은 현재 클래스명이 SceneChanger로 되어 있습니다.
// Unity에서 MonoBehaviour를 안정적으로 붙이려면 파일명과 클래스명을 맞추는 것이 좋으므로,
// 나중에 정리할 때는 SceneManager.cs / SceneChanger.cs의 클래스명을 서로 맞춰 주세요.
//
// 초심자용 핵심 개념:
// - Debug.Log는 Unity Console에 메시지를 출력합니다.
// - 버튼이 제대로 눌렸는지 확인할 때 유용합니다.
// - 같은 씬을 두 번 LoadScene하면 불필요한 호출이므로, 실제 완성 단계에서는 한 번만 남기는 것이 좋습니다.
public class SceneChanger : MonoBehaviour
{
    private void Start()
    {
        WireStoryButton();
    }

    public void GoToStartStory()
    {
        // intface의 시작 버튼을 눌렀을 때 호출됩니다.
        // 진행도를 0부/첫 전투로 초기화하고 startstory 씬으로 이동합니다.
        // 이전 코드처럼 같은 씬을 두 번 LoadScene하지 않게 한 번만 호출합니다.
        StoryBattleFlow.LoadIntroStory();
        Debug.Log("시작 버튼: 0부 스토리를 시작합니다."); // 콘솔창에 찍힙니다.
    }

    public void GoToStartStroy()
    {
        // startstroy처럼 철자를 잘못 적어 연결해도 같은 기능이 실행되도록 만든 별칭 함수입니다.
        // 실제 씬 파일 이름은 startstory이므로 내부에서는 GoToStartStory를 다시 호출합니다.
        GoToStartStory();
    }

    public void GoToFullStory()
    {
        // 이야기 버튼에서는 전투로 이어지지 않고 0부부터 엔딩까지 감상합니다.
        StoryBattleFlow.LoadFullStory();
        Debug.Log("이야기 버튼: 전체 스토리를 봅니다.");
    }

    public void GoToFullStroy()
    {
        // Stroy 오타로 연결해도 전체 이야기 버튼이 동작하도록 둔 별칭입니다.
        GoToFullStory();
    }

    // 다른 씬 이름을 매개변수로 받아 범용적으로 쓸 수 있는 함수입니다.
    // Build Settings에 등록된 씬 이름과 정확히 일치해야 정상적으로 이동합니다.
    public void ChangeScene(string sceneName)
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(sceneName);
    }

    private void WireStoryButton()
    {
        // 기존 intface 씬의 story 버튼에 클릭 이벤트가 비어 있어도 런타임에서 연결합니다.
        GameObject storyObject = GameObject.Find("story");
        if (storyObject == null) return;

        Button storyButton = storyObject.GetComponent<Button>();
        if (storyButton == null) return;

        storyButton.onClick.RemoveListener(GoToFullStory);
        storyButton.onClick.AddListener(GoToFullStory);
    }
}
