using UnityEngine;
using UnityEngine.UI;
using TMPro;
using DG.Tweening;
using System.Collections.Generic;
using System.Collections;

// 전투 화면의 UI 표시만 담당하는 관리자입니다.
//
// BattleManager가 HP/기력/달 게이지 같은 "실제 값"을 가지고 있고,
// UIManager는 그 값을 화면의 Text, Slider, Gem 이미지에 반영합니다.
//
// 중요한 설계:
// - 전투 규칙을 여기서 계산하지 않습니다.
// - UIManager는 "보여주기"만 합니다.
// - BattleSceneBootstrap이 런타임으로 만든 UI 오브젝트를 ConfigureRuntimeUI로 넘겨주면,
//   이후 BattleManager가 Update... 함수를 호출해 UI를 갱신합니다.
//
// 초심자용 핵심 개념:
// - Slider는 HP바처럼 0~1 사이 비율을 보여주기에 좋습니다.
// - Text는 숫자와 안내 문구를 화면에 보여줍니다.
// - Image는 구슬, 배경, 카드 그림 같은 UI 이미지를 보여줍니다.
// - Pool은 미리 만들어 둔 오브젝트 목록입니다. 기력/달 구슬을 매번 새로 만들지 않고 재사용합니다.
//
// Update... 함수들의 뜻:
// - UpdateEnergyUI: 현재 기력 숫자와 기력 구슬을 갱신합니다.
// - UpdateMoonGaugeUI: 달 게이지 퍼센트와 달 구슬을 갱신합니다.
// - UpdateTurnCountUI: 현재 몇 턴인지 표시합니다.
// - UpdateEnemyHP / UpdatePlayerHP: HP바와 HP 숫자를 갱신합니다.
public class UIManager : MonoBehaviour
{
    private struct DeathCutsceneProfile
    {
        public string title;
        public string[] lines;
        public string prompt;
        public Color backdropColor;
        public Color haloColor;
        public Color heroTint;
        public Color shardColor;
        public Vector2 heroEndPosition;
        public float heroRotation;
        public float backdropAlpha;
        public float haloAlpha;
        public float heroAlpha;
        public int shardCount;

        public DeathCutsceneProfile(string title, string[] lines, string prompt, Color backdropColor, Color haloColor, Color heroTint, Color shardColor, Vector2 heroEndPosition, float heroRotation, float backdropAlpha, float haloAlpha, float heroAlpha, int shardCount)
        {
            this.title = title;
            this.lines = lines;
            this.prompt = prompt;
            this.backdropColor = backdropColor;
            this.haloColor = haloColor;
            this.heroTint = heroTint;
            this.shardColor = shardColor;
            this.heroEndPosition = heroEndPosition;
            this.heroRotation = heroRotation;
            this.backdropAlpha = backdropAlpha;
            this.haloAlpha = haloAlpha;
            this.heroAlpha = heroAlpha;
            this.shardCount = shardCount;
        }
    }

    public static UIManager Instance;
    [Header("Card Full Description")]
    [SerializeField] private GameObject cardDescriptionPanel;
    [SerializeField] private Text cardDescriptionText;
    
    [Header("Energy UI (기력 텍스트)")]
    [SerializeField] private Text energyText;

    [Header("Moon Gauge UI (달의 기운 텍스트)")]
    [SerializeField] private Text moonPercentText;

    [Header("Turn UI (현재 턴 텍스트)")]
    [SerializeField] private Text turnCountText;

    [Header("Enemy HP UI")]
    [SerializeField] private Slider enemyHPSlider;
    [SerializeField] private Text enemyHPText;
    [SerializeField] private Slider[] enemyHPSliders;
    [SerializeField] private Text[] enemyHPTexts;

    [Header("Player HP UI")]
    [SerializeField] private Slider playerHPSlider;
    [SerializeField] private Text playerHPText;

    [Header("Gem Appearance (구슬 상태별 스프라이트)")]
    [SerializeField] private Sprite activeGemSprite;   // 검은색처럼 꽉 찬 구슬 이미지
    [SerializeField] private Sprite inactiveGemSprite; // 흰색처럼 비어있는 구슬 이미지

    [Header("Screen Effects")]
    [SerializeField] private GameObject gameOverPanel;
    [SerializeField] private Text turnNotifyText;
    private Coroutine gameOverRoutine;
    private RectTransform gameOverContentRoot;
    private CanvasGroup gameOverContentGroup;
    private CanvasGroup gameOverButtonGroup;
    private Image gameOverBackdrop;
    private Image gameOverHeroImage;
    private Image gameOverHaloImage;
    private Text gameOverTitleText;
    private Text gameOverBodyText;
    private Text gameOverPromptText;
    private Button gameOverRetryButton;
    private Button gameOverExitButton;
    private readonly List<Image> gameOverShardImages = new List<Image>();
    private static Sprite softCircleSprite;
    private static Sprite cutsceneHeroSprite;

    [Header("Card Tooltip")]
    [SerializeField] private GameObject cardTooltipPanel;
    [SerializeField] private Text cardTooltipText;

    [Header("Energy UI (오브젝트 풀링 변수)")]
    [SerializeField] private GameObject energyGemPrefab;
    [SerializeField] private Transform energyGemParent;
    private List<Image> energyGemPool = new List<Image>();

    [Header("Moon Gauge (오브젝트 풀링 변수)")]
    [SerializeField] private GameObject moonGemPrefab;
    [SerializeField] private Transform moonGemParent;
    private List<Image> moonGemPool = new List<Image>(); // 달의 기운도 똑같이 구슬 개별 리스트로 관리합니다!
    private int lastEnergyValue = int.MinValue;
    private int lastEnergyPoolCount = int.MinValue;
    private int lastMoonActiveGems = int.MinValue;
    private int lastMoonPercent = int.MinValue;
    private int lastMoonPoolCount = int.MinValue;
    private GameObject tutorialPanel;
    private CanvasGroup tutorialCanvasGroup;
    private Text tutorialTitleText;
    private Text tutorialBodyText;
    private Text tutorialProgressText;
    private Button tutorialNextButton;
    private Button tutorialCloseButton;
    private string[] tutorialSteps;
    private int tutorialStepIndex;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public void ShowCardFullDescription(CardDate data)
    {
        if (cardDescriptionPanel == null) return;
        if (cardDescriptionText == null) return;
        if (data == null) return;
        cardDescriptionPanel.SetActive(true);

        ReadableTextStyle.Apply(cardDescriptionText);
        cardDescriptionText.text = $"{data.cardName}\n\n비용: {data.cost}\n위력: {data.power:F0}\n\n{data.description}";
    }

    public void HideCardFullDescription()
    {
        if (cardDescriptionPanel == null) return;
        cardDescriptionPanel.SetActive(false);
    }

    public void ConfigureRuntimeUI(
        Text energy,
        Text moonPercent,
        Text turnCount,
        Slider enemySlider,
        Text enemyText,
        Slider playerSlider,
        Text playerText,
        Text turnText,
        GameObject gameOver,
        GameObject tooltipPanel,
        Text tooltipText,
        GameObject energyGem,
        Transform energyParent,
        GameObject moonGem,
        Transform moonParent,
        Sprite activeSprite,
        Sprite inactiveSprite)
    {
        // BattleSceneBootstrap이 자동 생성한 UI 컴포넌트들을 이 매니저에 연결합니다.
        // 이렇게 하면 씬에 직접 UI를 배치하지 않아도 코드만으로 전투 UI를 구성할 수 있습니다.
        // 함수 인자가 많은 이유는 전투 화면의 각 UI 조각이 런타임에 만들어지고,
        // 그 조각들을 UIManager가 나중에 다시 갱신할 수 있도록 참조로 보관해야 하기 때문입니다.
        energyText = energy;
        moonPercentText = moonPercent;
        turnCountText = turnCount;
        enemyHPSlider = enemySlider;
        enemyHPText = enemyText;
        playerHPSlider = playerSlider;
        playerHPText = playerText;
        turnNotifyText = turnText;
        gameOverPanel = gameOver;
        cardTooltipPanel = tooltipPanel;
        cardTooltipText = tooltipText;
        energyGemPrefab = energyGem;
        energyGemParent = energyParent;
        moonGemPrefab = moonGem;
        moonGemParent = moonParent;
        activeGemSprite = activeSprite;
        inactiveGemSprite = inactiveSprite;

        ApplyReadableTextReferences();
    }

    public void ConfigureEnemyPartyUI(Slider[] enemySliders, Text[] enemyTexts)
    {
        enemyHPSliders = enemySliders;
        enemyHPTexts = enemyTexts;

        if (enemyHPSliders != null && enemyHPSliders.Length > 0)
        {
            enemyHPSlider = enemyHPSliders[0];
        }

        if (enemyHPTexts != null && enemyHPTexts.Length > 0)
        {
            enemyHPText = enemyHPTexts[0];
        }

        ApplyReadableTextReferences();
    }

    private void ApplyReadableTextReferences()
    {
        ReadableTextStyle.Apply(energyText);
        ReadableTextStyle.Apply(moonPercentText);
        ReadableTextStyle.Apply(turnCountText);
        ReadableTextStyle.Apply(enemyHPText);
        ReadableTextStyle.Apply(playerHPText);
        ReadableTextStyle.Apply(turnNotifyText);
        ReadableTextStyle.Apply(cardTooltipText);
        ReadableTextStyle.Apply(cardDescriptionText);

        if (enemyHPTexts == null) return;
        for (int i = 0; i < enemyHPTexts.Length; i++)
        {
            ReadableTextStyle.Apply(enemyHPTexts[i]);
        }
    }

    // 1. 게임 시작 시 기력 구슬 5개, 달의 기운 구슬 5개를 각각 독립적으로 생성합니다.
    public void InitAllPools(int maxEnergy, int maxMoonSteps)
    {
        // 기력 구슬 생성 파트
        foreach (var gem in energyGemPool) if (gem != null) Destroy(gem.gameObject);
        energyGemPool.Clear();
        for (int i = 0; i < maxEnergy; i++)
        {
            Image image = CreateGem(energyGemPrefab, energyGemParent);
            if (image != null) energyGemPool.Add(image);
        }

        // 달의 기운 구슬 생성 파트 (5칸 독립 구슬 오브젝트 생성)
        foreach (var gem in moonGemPool) if (gem != null) Destroy(gem.gameObject);
        moonGemPool.Clear();
        for (int i = 0; i < maxMoonSteps; i++)
        {
            Image image = CreateGem(moonGemPrefab, moonGemParent);
            if (image != null) moonGemPool.Add(image);
        }

        InvalidateGemCache();
    }

    // 2. 기력 변경 시 개별 구슬 이미지 스왑 (그림처럼 작동)
    public void UpdateEnergyUI(int currentEnergy)
    {
        int poolCount = energyGemPool.Count;
        if (currentEnergy == lastEnergyValue && poolCount == lastEnergyPoolCount) return;

        // 기력은 숫자 텍스트와 구슬 이미지를 동시에 갱신합니다.
        // i가 현재 기력보다 작으면 켜진 구슬, 아니면 꺼진 구슬을 보여줍니다.
        for (int i = 0; i < poolCount; i++)
        {
            if (i < currentEnergy) energyGemPool[i].sprite = activeGemSprite;    // 기력이 차있으면 찬 구슬
            else energyGemPool[i].sprite = inactiveGemSprite;  // 기력을 썼으면 안 찬 구슬
        }

        if (energyText != null) energyText.text = $"{currentEnergy} / {poolCount}";
        lastEnergyValue = currentEnergy;
        lastEnergyPoolCount = poolCount;
    }

    // 3. 달의 기운 변경 시 개별 구슬 이미지 스왑 (0~100 수치를 5개의 구슬 칸으로 환산)
    public void UpdateMoonGaugeUI(float currentMoon, float maxMoon)
    {
        int poolCount = moonGemPool.Count;
        float ratio = maxMoon > 0f ? Mathf.Clamp01(currentMoon / maxMoon) : 0f;
        
        // 0~100% 수치를 기반으로 불이 켜져야 할 구슬 개수(0~5개)를 정수로 계산합니다.
        // 예: 0~19% = 0개, 20~39% = 1개, 40~59% = 2개 ... 100% = 5개
        int activeMoonGems = Mathf.Clamp(Mathf.FloorToInt(ratio * poolCount), 0, poolCount);
        int percent = Mathf.RoundToInt(ratio * 100f);
        if (activeMoonGems == lastMoonActiveGems && percent == lastMoonPercent && poolCount == lastMoonPoolCount) return;

        for (int i = 0; i < poolCount; i++)
        {
            if (i < activeMoonGems) moonGemPool[i].sprite = activeGemSprite;    // 활성화된 개수 안쪽은 찬 구슬
            else moonGemPool[i].sprite = inactiveGemSprite;  // 나머지는 안 찬 빈 구슬
        }

        if (moonPercentText != null) moonPercentText.text = $"{percent}%";
        lastMoonActiveGems = activeMoonGems;
        lastMoonPercent = percent;
        lastMoonPoolCount = poolCount;
    }

    private void InvalidateGemCache()
    {
        lastEnergyValue = int.MinValue;
        lastEnergyPoolCount = int.MinValue;
        lastMoonActiveGems = int.MinValue;
        lastMoonPercent = int.MinValue;
        lastMoonPoolCount = int.MinValue;
    }

    public void UpdateTurnCountUI(int turnCount)
    {
        // 턴 수는 BattleManager가 계산하고 UIManager는 텍스트로 보여주기만 합니다.
        // Mathf.Max를 쓰는 이유는 혹시 0 이하 값이 들어와도 화면에는 최소 1턴처럼 보이게 하기 위해서입니다.
        if (turnCountText != null) turnCountText.text = $"턴 {Mathf.Max(1, turnCount)}";
    }

    // 4. 적 HP UI 업데이트
    public void UpdateEnemyHP(float current, float max)
    {
        float ratio = max > 0f ? current / max : 0f;
        if (enemyHPSlider != null) enemyHPSlider.value = ratio;
        if (enemyHPText != null) enemyHPText.text = $"{current:F0} / {max:F0}";
    }

    public void UpdateEnemyPartyHP(float[] currents, float[] maxes, bool[] aliveStates, int activeIndex)
    {
        if (enemyHPSliders == null || enemyHPTexts == null)
        {
            int safeActiveIndex = Mathf.Max(0, activeIndex);
            UpdateEnemyHP(
                currents != null && currents.Length > safeActiveIndex ? currents[safeActiveIndex] : 0f,
                maxes != null && maxes.Length > safeActiveIndex ? maxes[safeActiveIndex] : 1f);
            return;
        }

        int count = Mathf.Min(enemyHPSliders.Length, enemyHPTexts.Length);
        for (int i = 0; i < count; i++)
        {
            float max = maxes != null && i < maxes.Length ? maxes[i] : 0f;
            float current = currents != null && i < currents.Length ? currents[i] : 0f;
            bool isAlive = aliveStates != null && i < aliveStates.Length && aliveStates[i];
            bool hasEnemy = max > 0f;

            if (enemyHPSliders[i] != null)
            {
                enemyHPSliders[i].gameObject.SetActive(hasEnemy);
                enemyHPSliders[i].value = max > 0f ? current / max : 0f;
            }

            if (enemyHPTexts[i] != null)
            {
                enemyHPTexts[i].gameObject.SetActive(hasEnemy);
                string marker = i == activeIndex && isAlive ? " >" : "";
                enemyHPTexts[i].text = isAlive ? $"{current:F0} / {max:F0}{marker}" : "정화됨";
            }
        }
    }

    public void UpdatePlayerHP(float current, float max, float shield)
    {
        // 플레이어 HP 텍스트는 방어막이 있을 때만 +방어막을 추가로 표시합니다.
        // 예: "120 / 150 +18"
        if (playerHPSlider != null) playerHPSlider.value = current / max;
        if (playerHPText != null)
        {
            playerHPText.text = shield > 0f ? $"{current:F0} / {max:F0} +{shield:F0}" : $"{current:F0} / {max:F0}";
        }
    }

    // 5. 턴 시작 알림 연출
    public void ShowTurnNotice(string message)
    {
        // 대부분의 짧은 전투 알림은 1.5초만 보여 줍니다.
        // 예: "플레이어 턴!", "합 승리!" 같은 빠른 정보입니다.
        ShowTurnNotice(message, 1.5f);
    }

    public void ShowTurnNotice(string message, float visibleSeconds)
    {
        if (turnNotifyText != null)
        {
            // visibleSeconds를 매개변수로 받은 이유:
            // 튜토리얼처럼 긴 설명은 1.5초면 읽기 어렵고,
            // 짧은 전투 알림은 오래 남아 있으면 화면을 가립니다.
            // 그래서 같은 알림 UI를 쓰되, 상황마다 표시 시간을 다르게 정할 수 있게 했습니다.
            turnNotifyText.text = message;
            turnNotifyText.gameObject.SetActive(true);
            CancelInvoke(nameof(HideTurnNotice));
            Invoke(nameof(HideTurnNotice), Mathf.Max(0.5f, visibleSeconds));
        }
    }

    private void HideTurnNotice()
    {
        if (turnNotifyText != null) turnNotifyText.gameObject.SetActive(false);
    }

    public void ShowBattleTutorialSequence()
    {
        // 첫 전투에서 플레이어가 반드시 알아야 할 조작을 한 단계씩 보여줍니다.
        // ShowTurnNotice처럼 자동으로 사라지는 문구가 아니라, 사용자가 다음 버튼을 눌러 확인하는 안내입니다.
        EnsureTutorialLayout();
        tutorialSteps = new[]
        {
            "목표\n적의 HP를 0으로 만들면 전투에서 승리합니다.\n루나리스의 HP가 0이 되면 패배 컷씬이 나오고, 다시 도전으로 같은 전투를 바로 재시작할 수 있습니다.",
            "기력\n화면 위쪽의 왼쪽 숫자가 현재 기력입니다.\n플레이어 턴이 시작될 때 기력을 3 얻고, 최대 7까지 저장됩니다.\n카드는 왼쪽 위 비용만큼 기력을 소비합니다.",
            "카드 읽는 법\n카드 위쪽 숫자는 비용, 아래쪽 숫자는 위력입니다.\n공격 카드는 적에게 피해를 주고, 방어/회복/버프 카드는 루나리스를 지키거나 다음 공격을 강화합니다.",
            "타겟 선택\n적이 여러 마리라면 먼저 때릴 적을 정해야 합니다.\n마우스/터치로 적을 누르거나, 좌우 방향키 또는 A/D로 타겟을 바꿀 수 있습니다.",
            "공격하기\n쓸 카드를 클릭하면 선택한 적에게 카드 효과가 발동합니다.\n기력이 부족한 카드는 사용할 수 없고, 공격 후에는 달의 기운이 차오릅니다.",
            "턴 종료\n더 쓸 카드가 없거나 적 행동을 보고 싶으면 오른쪽 아래 턴 종료 버튼을 누릅니다.\n턴을 넘기면 적이 행동하고, 이후 다시 플레이어 턴이 돌아옵니다.",
            "방어와 위험 상태\n쌍둥이자리는 방어막을 만들고, 처녀자리는 큰 피해를 제한하며 위험한 독성 상태를 정리합니다.\n전갈 보스의 천무독은 스택이 쌓이면 즉사하므로 처녀자리로 지우는 타이밍이 중요합니다.",
            "연성\n같은 플레이어 턴에 특정 카드 두 장을 순서대로 쓰면 연성 보너스가 발동합니다.\n예: 양자리 다음 황소자리를 바로 쓰면 더 강한 공격과 수면 효과가 이어집니다.\n자세한 조합은 오른쪽 위 성좌 버튼에서 확인할 수 있습니다.",
            "궁극기\n달의 기운이 100%가 되면 사수자리 같은 강한 카드가 드로우 후보에 들어옵니다.\n궁극기는 여러 적을 한 번에 때릴 수 있으니, 적이 많거나 보스전에서 결정타로 쓰면 좋습니다."
        };

        tutorialStepIndex = 0;
        tutorialPanel.SetActive(true);
        tutorialPanel.transform.SetAsLastSibling();
        tutorialCanvasGroup.alpha = 0f;
        tutorialCanvasGroup.DOFade(1f, 0.18f).SetEase(Ease.OutQuad);
        ShowTutorialStep();
    }

    private void EnsureTutorialLayout()
    {
        if (tutorialPanel != null) return;

        Canvas canvas = FindFirstObjectByType<Canvas>();
        if (canvas == null) return;

        tutorialPanel = GetOrCreateChild(canvas.transform, "Battle Tutorial Panel", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(CanvasGroup));
        RectTransform panelRect = tutorialPanel.GetComponent<RectTransform>();
        panelRect.anchorMin = new Vector2(0.5f, 0.5f);
        panelRect.anchorMax = new Vector2(0.5f, 0.5f);
        panelRect.anchoredPosition = new Vector2(0f, 58f);
        panelRect.sizeDelta = new Vector2(820f, 430f);

        Image panelImage = tutorialPanel.GetComponent<Image>();
        CelestialUiAssets.ApplyWindow(panelImage);
        panelImage.raycastTarget = true;

        tutorialCanvasGroup = tutorialPanel.GetComponent<CanvasGroup>();
        tutorialCanvasGroup.interactable = true;
        tutorialCanvasGroup.blocksRaycasts = true;

        tutorialTitleText = CreateCutsceneText(tutorialPanel.transform, "Title", "전투 튜토리얼", 34, new Vector2(0.5f, 1f), new Vector2(0f, -48f), new Vector2(740f, 54f));
        tutorialBodyText = CreateCutsceneText(tutorialPanel.transform, "Body", "", 24, new Vector2(0.5f, 0.5f), new Vector2(0f, 18f), new Vector2(700f, 220f));
        tutorialBodyText.alignment = TextAnchor.MiddleLeft;
        tutorialProgressText = CreateCutsceneText(tutorialPanel.transform, "Progress", "", 18, new Vector2(0.5f, 0f), new Vector2(0f, 102f), new Vector2(260f, 36f));

        GameObject buttonRow = GetOrCreateChild(tutorialPanel.transform, "Buttons", typeof(RectTransform), typeof(HorizontalLayoutGroup));
        RectTransform rowRect = buttonRow.GetComponent<RectTransform>();
        rowRect.anchorMin = new Vector2(0.5f, 0f);
        rowRect.anchorMax = new Vector2(0.5f, 0f);
        rowRect.anchoredPosition = new Vector2(0f, 48f);
        rowRect.sizeDelta = new Vector2(540f, 58f);

        HorizontalLayoutGroup rowLayout = buttonRow.GetComponent<HorizontalLayoutGroup>();
        rowLayout.childAlignment = TextAnchor.MiddleCenter;
        rowLayout.spacing = 20f;
        rowLayout.childForceExpandWidth = false;
        rowLayout.childForceExpandHeight = false;

        tutorialCloseButton = CreateCutsceneButton(buttonRow.transform, "Close Button", "닫기");
        tutorialCloseButton.onClick.RemoveAllListeners();
        tutorialCloseButton.onClick.AddListener(HideTutorialPanel);

        tutorialNextButton = CreateCutsceneButton(buttonRow.transform, "Next Button", "다음");
        tutorialNextButton.onClick.RemoveAllListeners();
        tutorialNextButton.onClick.AddListener(AdvanceTutorialStep);

        tutorialPanel.SetActive(false);
    }

    private void ShowTutorialStep()
    {
        if (tutorialSteps == null || tutorialSteps.Length == 0) return;

        tutorialStepIndex = Mathf.Clamp(tutorialStepIndex, 0, tutorialSteps.Length - 1);
        tutorialBodyText.text = tutorialSteps[tutorialStepIndex];
        tutorialProgressText.text = $"{tutorialStepIndex + 1} / {tutorialSteps.Length}";

        Text nextLabel = tutorialNextButton != null ? tutorialNextButton.GetComponentInChildren<Text>() : null;
        if (nextLabel != null)
        {
            nextLabel.text = tutorialStepIndex >= tutorialSteps.Length - 1 ? "시작" : "다음";
        }
    }

    private void AdvanceTutorialStep()
    {
        if (tutorialSteps == null || tutorialSteps.Length == 0)
        {
            HideTutorialPanel();
            return;
        }

        if (tutorialStepIndex >= tutorialSteps.Length - 1)
        {
            HideTutorialPanel();
            return;
        }

        tutorialStepIndex++;
        ShowTutorialStep();
    }

    private void HideTutorialPanel()
    {
        if (tutorialPanel == null) return;

        tutorialCanvasGroup.DOKill();
        tutorialCanvasGroup.DOFade(0f, 0.12f).SetEase(Ease.OutQuad).OnComplete(() => tutorialPanel.SetActive(false));
    }

    public void HideGameOver()
    {
        if (gameOverRoutine != null)
        {
            StopCoroutine(gameOverRoutine);
            gameOverRoutine = null;
        }

        if (gameOverPanel == null) return;

        gameOverPanel.transform.DOKill();
        if (gameOverContentRoot != null) gameOverContentRoot.DOKill();
        if (gameOverContentGroup != null) gameOverContentGroup.DOKill();
        if (gameOverButtonGroup != null) gameOverButtonGroup.DOKill();
        if (gameOverBackdrop != null) gameOverBackdrop.DOKill();
        if (gameOverHeroImage != null) gameOverHeroImage.DOKill();
        if (gameOverHaloImage != null) gameOverHaloImage.DOKill();
        if (gameOverTitleText != null) gameOverTitleText.DOKill();
        if (gameOverBodyText != null) gameOverBodyText.DOKill();
        if (gameOverPromptText != null) gameOverPromptText.DOKill();

        SetGameOverButtonsVisible(false);
        gameOverPanel.SetActive(false);
    }

    // 6. 게임 오버 패널 활성화
    public void ShowGameOver(bool isWin)
    {
        ShowGameOver(isWin, BattleManager.EnemyKind.VoidHowler);
    }

    public void ShowGameOver(bool isWin, BattleManager.EnemyKind enemyKind)
    {
        if (gameOverPanel == null) return;

        gameOverPanel.SetActive(true);
        gameOverPanel.transform.SetAsLastSibling();
        EnsureGameOverCutsceneLayout();

        if (gameOverRoutine != null)
        {
            StopCoroutine(gameOverRoutine);
        }

        gameOverRoutine = StartCoroutine(isWin ? PlayVictoryCutscene() : PlayDeathCutscene(enemyKind));
    }

    private IEnumerator PlayDeathCutscene(BattleManager.EnemyKind enemyKind)
    {
        DeathCutsceneProfile profile = GetDeathCutsceneProfile(enemyKind);
        PrepareGameOverCutscene(profile.title);
        SetGameOverButtonsVisible(false);

        gameOverBackdrop.color = WithAlpha(profile.backdropColor, 0f);
        gameOverHaloImage.color = WithAlpha(profile.haloColor, 0f);
        gameOverHeroImage.color = WithAlpha(profile.heroTint, 0f);

        gameOverBackdrop.DOFade(profile.backdropAlpha, 0.45f).SetEase(Ease.OutQuad);
        gameOverContentGroup.DOFade(1f, 0.35f).SetEase(Ease.OutQuad);
        gameOverHaloImage.DOFade(profile.haloAlpha, 0.55f).SetEase(Ease.OutQuad);
        gameOverHeroImage.DOFade(profile.heroAlpha, 0.45f).SetEase(Ease.OutQuad);
        gameOverHeroImage.rectTransform.DOAnchorPos(profile.heroEndPosition, 1.1f).SetEase(Ease.OutCubic);
        gameOverHeroImage.rectTransform.DORotate(new Vector3(0f, 0f, profile.heroRotation), 0.8f).SetEase(Ease.OutQuad);
        SpawnGameOverShards(profile.shardColor, profile.shardCount);

        yield return new WaitForSeconds(0.45f);
        gameOverTitleText.DOFade(1f, 0.35f).SetEase(Ease.OutQuad);

        yield return new WaitForSeconds(0.35f);
        for (int i = 0; i < profile.lines.Length; i++)
        {
            gameOverBodyText.DOKill();
            gameOverBodyText.text = profile.lines[i];
            SetGraphicAlpha(gameOverBodyText, 0f);
            gameOverBodyText.DOFade(1f, 0.2f).SetEase(Ease.OutQuad);
            yield return new WaitForSeconds(i == profile.lines.Length - 1 ? 1.15f : 1.35f);
            if (i < profile.lines.Length - 1)
            {
                gameOverBodyText.DOFade(0f, 0.18f).SetEase(Ease.OutQuad);
                yield return new WaitForSeconds(0.18f);
            }
        }

        gameOverPromptText.text = profile.prompt;
        gameOverPromptText.DOFade(1f, 0.28f).SetEase(Ease.OutQuad);
        yield return new WaitForSeconds(0.12f);
        SetGameOverButtonsVisible(true);
        gameOverButtonGroup.DOFade(1f, 0.25f).SetEase(Ease.OutQuad);
    }

    private IEnumerator PlayVictoryCutscene()
    {
        PrepareGameOverCutscene("별자리가 정화되었습니다");
        gameOverBodyText.text = "흩어졌던 13성좌의 선이 다시 밤하늘에 이어집니다.";
        gameOverPromptText.text = "다음 이야기가 열립니다.";
        SetGameOverButtonsVisible(false);

        gameOverBackdrop.DOFade(0.72f, 0.35f).SetEase(Ease.OutQuad);
        gameOverContentGroup.DOFade(1f, 0.35f).SetEase(Ease.OutQuad);
        gameOverHaloImage.DOFade(0.36f, 0.45f).SetEase(Ease.OutQuad);
        gameOverHeroImage.DOFade(0.2f, 0.45f).SetEase(Ease.OutQuad);
        gameOverTitleText.DOFade(1f, 0.35f).SetEase(Ease.OutQuad);
        gameOverBodyText.DOFade(1f, 0.35f).SetEase(Ease.OutQuad);
        gameOverPromptText.DOFade(1f, 0.35f).SetEase(Ease.OutQuad);
        SpawnGameOverShards(new Color(0.72f, 0.9f, 1f, 1f), 24);
        yield return null;
    }

    private DeathCutsceneProfile GetDeathCutsceneProfile(BattleManager.EnemyKind enemyKind)
    {
        switch (enemyKind)
        {
            case BattleManager.EnemyKind.StarDustExecutor:
                return new DeathCutsceneProfile(
                    "별가루의 판결",
                    new[]
                    {
                        "탁한 창끝이 별빛의 결을 가르고, 루나리스의 숨이 차갑게 흩어진다.",
                        "집행자들의 방진은 흔들리지 않았다. 정화라는 이름 아래 모든 망설임을 지웠다.",
                        "바닥에 남은 은빛 가루가 아직 꺼지지 않은 별맥을 조용히 감싼다."
                    },
                    "다시 판결의 틈을 열겠습니까?",
                    new Color(0.01f, 0.025f, 0.05f, 1f),
                    new Color(0.55f, 0.78f, 1f, 1f),
                    new Color(0.7f, 0.86f, 1f, 1f),
                    new Color(0.72f, 0.88f, 1f, 1f),
                    new Vector2(-18f, 8f),
                    -3.5f,
                    0.9f,
                    0.34f,
                    0.28f,
                    30);
            case BattleManager.EnemyKind.FallenScorpio:
                return new DeathCutsceneProfile(
                    "천무독의 완성",
                    new[]
                    {
                        "전갈의 독이 별맥을 타고 오른다. 심장은 한 박자 늦게, 그리고 아주 깊게 멎는다.",
                        "천갈궁의 검은 궁륭 아래서 루나리스의 이름이 보랏빛 안개로 풀어진다.",
                        "그러나 독이 삼키지 못한 작은 별 하나가 손바닥 안에서 아직 떨고 있다."
                    },
                    "독의 밤을 다시 가르겠습니까?",
                    new Color(0.035f, 0.005f, 0.045f, 1f),
                    new Color(0.92f, 0.22f, 0.78f, 1f),
                    new Color(0.9f, 0.55f, 1f, 1f),
                    new Color(1f, 0.38f, 0.9f, 1f),
                    new Vector2(22f, 4f),
                    -9f,
                    0.92f,
                    0.4f,
                    0.34f,
                    34);
            case BattleManager.EnemyKind.StarAdversary:
                return new DeathCutsceneProfile(
                    "별핵 아래 꺼진 이름",
                    new[]
                    {
                        "하늘 한가운데 열린 별핵이 숨을 들이마시자, 전장의 모든 소리가 사라진다.",
                        "루나리스는 무릎을 꿇고도 시선을 내리지 않았다. 마지막 빛은 대적자의 그림자에 닿았다.",
                        "무너진 별자리 사이로 아주 먼 새벽이 느리게 되돌아오고 있다."
                    },
                    "마지막 별핵에 다시 닿겠습니까?",
                    new Color(0.002f, 0.01f, 0.035f, 1f),
                    new Color(0.22f, 0.86f, 1f, 1f),
                    new Color(0.6f, 0.92f, 1f, 1f),
                    new Color(0.42f, 0.9f, 1f, 1f),
                    new Vector2(0f, 18f),
                    4.5f,
                    0.94f,
                    0.48f,
                    0.24f,
                    42);
            default:
                return new DeathCutsceneProfile(
                    "공허의 울음이 삼킨 밤",
                    new[]
                    {
                        "공허의 울음이 겹겹이 몰려와 루나리스의 별선을 물어뜯는다.",
                        "작은 숨 하나가 어둠 속으로 밀려나고, 손끝의 별빛이 희미하게 흩어진다.",
                        "무리의 울음 너머로 아직 돌아오라는 별의 목소리가 남아 있다."
                    },
                    "다시 밤의 틈으로 들어가겠습니까?",
                    new Color(0.005f, 0.018f, 0.032f, 1f),
                    new Color(0.28f, 0.7f, 0.82f, 1f),
                    new Color(0.68f, 0.9f, 1f, 1f),
                    new Color(0.38f, 0.78f, 0.88f, 1f),
                    new Vector2(-24f, 10f),
                    -6f,
                    0.88f,
                    0.28f,
                    0.3f,
                    24);
        }
    }

    private void PrepareGameOverCutscene(string title)
    {
        gameOverPanel.transform.DOKill();
        gameOverContentRoot.DOKill();
        gameOverContentGroup.DOKill();
        gameOverHaloImage.DOKill();
        gameOverHeroImage.DOKill();
        gameOverTitleText.DOKill();
        gameOverBodyText.DOKill();
        gameOverPromptText.DOKill();
        gameOverButtonGroup.DOKill();

        gameOverBackdrop.color = new Color(0f, 0f, 0f, 0f);
        gameOverContentGroup.alpha = 0f;
        gameOverTitleText.text = title;
        gameOverBodyText.text = string.Empty;
        gameOverPromptText.text = string.Empty;

        SetGraphicAlpha(gameOverHaloImage, 0f);
        SetGraphicAlpha(gameOverHeroImage, 0f);
        SetGraphicAlpha(gameOverTitleText, 0f);
        SetGraphicAlpha(gameOverBodyText, 0f);
        SetGraphicAlpha(gameOverPromptText, 0f);
        gameOverHeroImage.rectTransform.anchoredPosition = new Vector2(0f, -18f);
        gameOverHeroImage.rectTransform.rotation = Quaternion.identity;
    }

    private void EnsureGameOverCutsceneLayout()
    {
        if (gameOverPanel == null) return;

        TMP_Text legacyText = gameOverPanel.GetComponentInChildren<TMP_Text>(true);
        if (legacyText != null)
        {
            legacyText.gameObject.SetActive(false);
        }

        gameOverBackdrop = gameOverPanel.GetComponent<Image>();
        if (gameOverBackdrop == null) gameOverBackdrop = gameOverPanel.AddComponent<Image>();
        gameOverBackdrop.raycastTarget = true;

        GameObject rootObject = GetOrCreateChild(gameOverPanel.transform, "Defeat Cutscene Root", typeof(RectTransform), typeof(CanvasGroup));
        gameOverContentRoot = rootObject.GetComponent<RectTransform>();
        Stretch(gameOverContentRoot);
        gameOverContentGroup = rootObject.GetComponent<CanvasGroup>();
        gameOverContentGroup.interactable = true;
        gameOverContentGroup.blocksRaycasts = true;

        gameOverHaloImage = CreateCutsceneImage(gameOverContentRoot, "Fading Star Halo", new Vector2(0.5f, 0.5f), new Vector2(0f, 38f), new Vector2(900f, 900f));
        gameOverHaloImage.sprite = CreateSoftCircleSprite();
        gameOverHaloImage.color = new Color(0.48f, 0.86f, 1f, 0f);
        gameOverHaloImage.raycastTarget = false;

        gameOverHeroImage = CreateCutsceneImage(gameOverContentRoot, "Fallen Hero Silhouette", new Vector2(0.5f, 0.5f), new Vector2(0f, -18f), new Vector2(370f, 510f));
        gameOverHeroImage.sprite = LoadCutsceneHeroSprite();
        gameOverHeroImage.preserveAspect = true;
        gameOverHeroImage.color = new Color(0.82f, 0.92f, 1f, 0f);
        gameOverHeroImage.raycastTarget = false;

        gameOverTitleText = CreateCutsceneText(gameOverContentRoot, "Cutscene Title", string.Empty, 48, new Vector2(0.5f, 0.5f), new Vector2(0f, 210f), new Vector2(920f, 86f));
        gameOverBodyText = CreateCutsceneText(gameOverContentRoot, "Cutscene Body", string.Empty, 28, new Vector2(0.5f, 0.5f), new Vector2(0f, 42f), new Vector2(960f, 150f));
        gameOverPromptText = CreateCutsceneText(gameOverContentRoot, "Cutscene Prompt", string.Empty, 26, new Vector2(0.5f, 0.5f), new Vector2(0f, -112f), new Vector2(760f, 64f));

        GameObject buttonRow = GetOrCreateChild(gameOverContentRoot, "Cutscene Buttons", typeof(RectTransform), typeof(CanvasGroup), typeof(HorizontalLayoutGroup));
        RectTransform rowRect = buttonRow.GetComponent<RectTransform>();
        rowRect.anchorMin = new Vector2(0.5f, 0.5f);
        rowRect.anchorMax = new Vector2(0.5f, 0.5f);
        rowRect.anchoredPosition = new Vector2(0f, -218f);
        rowRect.sizeDelta = new Vector2(600f, 70f);
        HorizontalLayoutGroup rowLayout = buttonRow.GetComponent<HorizontalLayoutGroup>();
        rowLayout.childAlignment = TextAnchor.MiddleCenter;
        rowLayout.spacing = 24f;
        rowLayout.childForceExpandWidth = false;
        rowLayout.childForceExpandHeight = false;
        gameOverButtonGroup = buttonRow.GetComponent<CanvasGroup>();

        gameOverRetryButton = CreateCutsceneButton(buttonRow.transform, "Retry Button", "다시 도전");
        gameOverRetryButton.onClick.RemoveAllListeners();
        gameOverRetryButton.onClick.AddListener(OnRetryFromGameOver);

        gameOverExitButton = CreateCutsceneButton(buttonRow.transform, "Exit Button", "성좌문으로");
        gameOverExitButton.onClick.RemoveAllListeners();
        gameOverExitButton.onClick.AddListener(OnExitFromGameOver);
    }

    private Image CreateCutsceneImage(Transform parent, string objectName, Vector2 anchor, Vector2 anchoredPosition, Vector2 size)
    {
        GameObject imageObject = GetOrCreateChild(parent, objectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        RectTransform rect = imageObject.GetComponent<RectTransform>();
        rect.anchorMin = anchor;
        rect.anchorMax = anchor;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = size;
        return imageObject.GetComponent<Image>();
    }

    private Text CreateCutsceneText(Transform parent, string objectName, string value, int fontSize, Vector2 anchor, Vector2 anchoredPosition, Vector2 size)
    {
        GameObject textObject = GetOrCreateChild(parent, objectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        RectTransform rect = textObject.GetComponent<RectTransform>();
        rect.anchorMin = anchor;
        rect.anchorMax = anchor;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = size;

        Text text = textObject.GetComponent<Text>();
        text.text = value;
        text.fontSize = fontSize;
        text.alignment = TextAnchor.MiddleCenter;
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Overflow;
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 16;
        text.resizeTextMaxSize = fontSize;
        text.lineSpacing = 1.08f;
        text.raycastTarget = false;
        ReadableTextStyle.Apply(text);
        return text;
    }

    private Button CreateCutsceneButton(Transform parent, string objectName, string label)
    {
        GameObject buttonObject = GetOrCreateChild(parent, objectName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(LayoutElement));
        RectTransform rect = buttonObject.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(250f, 58f);

        LayoutElement layout = buttonObject.GetComponent<LayoutElement>();
        layout.preferredWidth = 250f;
        layout.preferredHeight = 58f;

        Image image = buttonObject.GetComponent<Image>();
        CelestialUiAssets.ApplyButton(image);
        Button button = buttonObject.GetComponent<Button>();
        CelestialUiAssets.ConfigureButton(button, image);

        Text labelText = CreateCutsceneText(buttonObject.transform, "Label", label, 24, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(230f, 52f));
        labelText.raycastTarget = false;
        return button;
    }

    private void SpawnGameOverShards(Color shardColor, int shardCount)
    {
        int safeShardCount = Mathf.Clamp(shardCount, 8, 48);
        for (int i = 0; i < safeShardCount; i++)
        {
            Image shard = GetGameOverShard(i);
            RectTransform rect = shard.rectTransform;
            rect.DOKill();
            shard.DOKill();
            shard.gameObject.SetActive(true);

            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = new Vector2(Random.Range(-760f, 760f), Random.Range(-250f, 300f));
            rect.sizeDelta = Vector2.one * Random.Range(5f, 13f);
            rect.localScale = Vector3.one * Random.Range(0.7f, 1.35f);
            shard.sprite = CreateSoftCircleSprite();
            shard.color = WithAlpha(shardColor, Random.Range(0.28f, 0.82f));

            Vector2 drift = new Vector2(Random.Range(-42f, 42f), Random.Range(52f, 148f));
            float duration = Random.Range(1.1f, 1.85f);
            Sequence sequence = DOTween.Sequence();
            sequence.AppendInterval(Random.Range(0f, 0.35f));
            sequence.Append(rect.DOAnchorPos(rect.anchoredPosition + drift, duration).SetEase(Ease.OutCubic));
            sequence.Join(rect.DOScale(Vector3.one * Random.Range(0.1f, 0.35f), duration));
            sequence.Join(shard.DOFade(0f, duration));
        }

        for (int i = safeShardCount; i < gameOverShardImages.Count; i++)
        {
            if (gameOverShardImages[i] != null)
            {
                gameOverShardImages[i].gameObject.SetActive(false);
            }
        }
    }

    private Image GetGameOverShard(int index)
    {
        while (gameOverShardImages.Count <= index)
        {
            GameObject shardObject = GetOrCreateChild(gameOverContentRoot, $"Fading Star {gameOverShardImages.Count + 1}", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            Image image = shardObject.GetComponent<Image>();
            image.raycastTarget = false;
            gameOverShardImages.Add(image);
        }

        return gameOverShardImages[index];
    }

    private void SetGameOverButtonsVisible(bool isVisible)
    {
        if (gameOverButtonGroup == null) return;

        gameOverButtonGroup.alpha = isVisible ? gameOverButtonGroup.alpha : 0f;
        gameOverButtonGroup.interactable = isVisible;
        gameOverButtonGroup.blocksRaycasts = isVisible;
    }

    private void OnRetryFromGameOver()
    {
        Time.timeScale = 1f;
        if (BattleManager.Instance != null)
        {
            BattleManager.Instance.RestartCurrentBattleFromGameOver();
            return;
        }

        StoryBattleFlow.LoadCurrentBattleStage();
    }

    private void OnExitFromGameOver()
    {
        Time.timeScale = 1f;
        StoryBattleFlow.LoadInterfaceAfterEnding();
    }

    private GameObject GetOrCreateChild(Transform parent, string objectName, params System.Type[] components)
    {
        Transform existing = parent.Find(objectName);
        GameObject target = existing != null ? existing.gameObject : new GameObject(objectName, components);
        if (existing == null)
        {
            target.transform.SetParent(parent, false);
        }

        foreach (System.Type componentType in components)
        {
            if (target.GetComponent(componentType) == null)
            {
                target.AddComponent(componentType);
            }
        }

        return target;
    }

    private void Stretch(RectTransform rect)
    {
        if (rect == null) return;

        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }

    private void SetGraphicAlpha(Graphic graphic, float alpha)
    {
        if (graphic == null) return;

        Color color = graphic.color;
        color.a = alpha;
        graphic.color = color;
    }

    private Color WithAlpha(Color color, float alpha)
    {
        color.a = alpha;
        return color;
    }

    private Sprite LoadCutsceneHeroSprite()
    {
        if (cutsceneHeroSprite != null) return cutsceneHeroSprite;

        Texture2D texture = Resources.Load<Texture2D>("Characters/PlayerHeroFemale");
        if (texture == null) return null;

        cutsceneHeroSprite = Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
        return cutsceneHeroSprite;
    }

    private Sprite CreateSoftCircleSprite()
    {
        if (softCircleSprite != null) return softCircleSprite;

        int size = 128;
        Texture2D texture = new Texture2D(size, size);
        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        float radius = size * 0.48f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float distance = Vector2.Distance(new Vector2(x, y), center);
                float alpha = Mathf.Clamp01(1f - distance / radius);
                alpha *= alpha;
                texture.SetPixel(x, y, alpha > 0f ? new Color(1f, 1f, 1f, alpha) : Color.clear);
            }
        }

        texture.Apply();
        softCircleSprite = Sprite.Create(texture, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f));
        return softCircleSprite;
    }

    public void ShowCardTooltip(CardDate data, Vector3 cardWorldPosition)
    {
        if (cardTooltipPanel == null || cardTooltipText == null || data == null) return;

        cardTooltipText.text = BuildTooltipText(data);
        cardTooltipPanel.SetActive(true);
        cardTooltipPanel.transform.SetAsLastSibling();

        RectTransform rect = cardTooltipPanel.GetComponent<RectTransform>();
        if (rect != null)
        {
            rect.position = cardWorldPosition + new Vector3(0f, 330f, 0f);
        }
    }

    public void HideCardTooltip()
    {
        if (cardTooltipPanel != null)
        {
            cardTooltipPanel.SetActive(false);
        }
    }

    private string BuildTooltipText(CardDate data)
    {
        // 카드 툴팁에 들어갈 문자열을 한 곳에서 조립합니다.
        // 나중에 카드 타입을 한글로 바꾸거나 추가 수치를 보여주고 싶으면 여기만 고치면 됩니다.
        string typeText = GetCardTypeLabel(data.type);
        string body = string.IsNullOrWhiteSpace(data.description) ? "설명이 아직 없습니다." : data.description;
        return $"{data.cardName}\n비용 {data.cost} / {typeText}\n{body}";
    }

    private string GetCardTypeLabel(CardDate.CardType type)
    {
        switch (type)
        {
            case CardDate.CardType.Attack:
                return "공격";
            case CardDate.CardType.Defense:
                return "방어";
            case CardDate.CardType.Buff:
                return "강화";
            case CardDate.CardType.Energy:
                return "기력";
            case CardDate.CardType.Ultimate:
                return "필살";
            default:
                return "카드";
        }
    }

    private Image CreateGem(GameObject prefab, Transform parent)
    {
        if (parent == null) return null;

        GameObject go;
        if (prefab != null)
        {
            go = Instantiate(prefab, parent);
            go.SetActive(true);
        }
        else
        {
            go = new GameObject("Gem", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(parent, false);
            RectTransform rect = go.GetComponent<RectTransform>();
            rect.sizeDelta = new Vector2(22f, 22f);
        }

        return go.GetComponent<Image>();
    }
}
