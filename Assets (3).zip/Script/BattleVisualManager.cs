using DG.Tweening;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// 전투 화면의 시각 연출만 담당합니다.
// 실제 피해 계산은 BattleManager가 하고, 이 파일은 이동/흔들림/타격 이펙트만 보여줍니다.
//
// BattleVisualManager가 하는 일:
// - 플레이어/적 공격 시 앵커를 흔들거나 앞으로 움직입니다.
// - 적 이름, 적 이미지, 적 배경을 현재 적 종류에 맞게 바꿉니다.
// - 피해/회복/방어막/기력 숫자를 화면에 띄웁니다.
// - 풍화 바람, 별무리 유성우 같은 간단한 런타임 이펙트를 만듭니다.
//
// 중요한 점:
// 이 파일은 HP를 깎거나 기력을 바꾸지 않습니다.
// "무슨 일이 일어났는지 보여주는 코드"만 모아둔 연출 전용 클래스입니다.
//
// 초심자용 핵심 개념:
// - RectTransform은 UI 오브젝트의 위치와 크기를 다루는 컴포넌트입니다.
// - Image는 UI에 그림이나 색을 보여주는 컴포넌트입니다.
// - Text는 UI에 글자를 보여주는 컴포넌트입니다.
// - DOTween의 Sequence는 여러 애니메이션을 순서대로 이어 붙이는 도구입니다.
// - DOKill은 이전에 걸려 있던 애니메이션을 멈춥니다. 같은 대상에 모션이 겹치는 것을 줄여 줍니다.
//
// 이 파일에서 자주 보이는 패턴:
// 1. GameObject를 만든다.
// 2. RectTransform/Image/Text 같은 컴포넌트를 붙인다.
// 3. 위치, 크기, 색, 텍스트를 설정한다.
// 4. DOTween으로 이동/흔들림/페이드 애니메이션을 준다.
// 5. 애니메이션이 끝나면 Destroy로 임시 이펙트를 삭제한다.
public class BattleVisualManager : MonoBehaviour
{
    public static BattleVisualManager Instance;

    [SerializeField] private RectTransform playerAnchor;
    [SerializeField] private RectTransform enemyAnchor;
    [SerializeField] private Image enemyImage;
    [SerializeField] private Text enemyNameText;
    [SerializeField] private RectTransform[] enemyAnchors;
    [SerializeField] private Image[] enemyImages;
    [SerializeField] private Text[] enemyNameTexts;
    [SerializeField] private Image battlefieldBackground;
    [SerializeField] private Transform effectParent;

    private Image playerImage;
    private static Material bossEnemyMaterial;
    private BattleManager.EnemyKind currentEnemyKind;
    private int activeEnemyIndex;
    private int visibleEnemyCount = 1;
    private static readonly Dictionary<BattleManager.EnemyKind, Sprite> backgroundSpriteCache = new Dictionary<BattleManager.EnemyKind, Sprite>();
    private static readonly Dictionary<BattleManager.EnemyKind, Sprite> enemySpriteCache = new Dictionary<BattleManager.EnemyKind, Sprite>();
    private readonly Dictionary<string, Queue<GameObject>> effectPools = new Dictionary<string, Queue<GameObject>>();
    private static Sprite playerSprite;
    private static Sprite[] playerIdleSprites;
    private static Sprite[] playerAttackSprites;
    private static Sprite heroCardSprite;
    private static Sprite meteorSprite;
    private static Sprite circleSprite;
    private Vector2 playerBasePosition;
    private Vector3 playerBaseScale = Vector3.one;
    private Sequence playerIdleSequence;

    private void Awake()
    {
        // BattleManager에서 BattleVisualManager.Instance로 연출을 호출하기 위한 싱글톤입니다.
        if (Instance == null) Instance = this;
        else
        {
            Destroy(gameObject);
        }
    }

    public void Configure(RectTransform player, RectTransform enemy, Image enemyVisual, Text enemyName, Image background, Transform effects)
    {
        // BattleSceneBootstrap이 자동 생성한 플레이어/적 위치와 이펙트 부모를 연결합니다.
        // 이 연결이 끝나야 공격 모션, 피해 숫자, 배경 교체가 올바른 위치에서 작동합니다.
        Configure(player, new[] { enemy }, new[] { enemyVisual }, new[] { enemyName }, background, effects);
    }

    public void Configure(RectTransform player, RectTransform[] enemies, Image[] enemyVisuals, Text[] enemyNames, Image background, Transform effects)
    {
        playerAnchor = player;
        playerImage = playerAnchor != null ? playerAnchor.GetComponent<Image>() : null;
        enemyAnchors = enemies;
        enemyImages = enemyVisuals;
        enemyNameTexts = enemyNames;
        enemyAnchor = GetEnemyAnchor(0);
        enemyImage = GetEnemyImage(0);
        enemyNameText = GetEnemyNameText(0);
        battlefieldBackground = background;
        effectParent = effects;
        if (playerAnchor != null)
        {
            playerBasePosition = playerAnchor.anchoredPosition;
            playerBaseScale = Vector3.one;
            playerAnchor.localScale = playerBaseScale;
            playerAnchor.localRotation = Quaternion.identity;
        }

        SetPlayerImage();
    }

    public void SetEnemyVisual(BattleManager.EnemyKind enemyKind, string enemyName)
    {
        // 새 적이 등장할 때 한 번에 갱신해야 하는 시각 요소입니다.
        // 이름, 적 이미지, 배경이 서로 다른 함수로 나뉘어 있지만,
        // BattleManager에서는 이 함수 하나만 호출하면 됩니다.
        SetEnemyPartyVisuals(enemyKind, 1, enemyName);
    }

    public void SetEnemyPartyVisuals(BattleManager.EnemyKind enemyKind, int enemyCount, string enemyName)
    {
        currentEnemyKind = enemyKind;
        visibleEnemyCount = Mathf.Clamp(enemyCount, 1, enemyAnchors != null ? enemyAnchors.Length : 1);

        for (int i = 0; i < (enemyAnchors != null ? enemyAnchors.Length : 0); i++)
        {
            RectTransform anchor = enemyAnchors[i];
            if (anchor == null) continue;

            bool isVisible = i < visibleEnemyCount;
            anchor.gameObject.SetActive(isVisible);
            if (!isVisible) continue;

            anchor.DOKill();
            anchor.sizeDelta = GetEnemyActorSize(enemyKind, i);
            anchor.localRotation = Quaternion.identity;

            Text nameText = GetEnemyNameText(i);
            if (nameText != null)
            {
                nameText.text = visibleEnemyCount > 1 ? $"{enemyName} {i + 1}/{visibleEnemyCount}" : enemyName;
            }

            SetEnemyImage(GetEnemyImage(i), enemyKind);
            anchor.localScale = Vector3.one;
        }

        SetBattlefieldBackground(enemyKind);
        SetActiveEnemyIndex(0);
    }

    public void SetEnemyName(string enemyName)
    {
        // 새 적이 등장할 때 적 이름 텍스트를 바꿉니다.
        if (enemyNameText != null)
        {
            enemyNameText.text = enemyName;
        }
    }

    public void SetActiveEnemyIndex(int index)
    {
        // 일반 적은 선택된 대상이 살짝 커져서 "지금 때릴 대상"이 보이게 합니다.
        // 보스는 크기 자체가 연출의 일부라서 선택/피격 때 커지면 어색합니다.
        // 그래서 실제 크기 계산은 GetEnemyRestScale에 모아 두고, 보스는 고정 크기를 반환하게 합니다.
        int safeIndex = Mathf.Clamp(index, 0, Mathf.Max(0, visibleEnemyCount - 1));
        activeEnemyIndex = safeIndex;
        enemyAnchor = GetEnemyAnchor(safeIndex);
        enemyImage = GetEnemyImage(safeIndex);
        enemyNameText = GetEnemyNameText(safeIndex);

        if (enemyAnchors == null) return;

        for (int i = 0; i < enemyAnchors.Length; i++)
        {
            RectTransform anchor = enemyAnchors[i];
            if (anchor == null || !anchor.gameObject.activeSelf) continue;

            anchor.localScale = GetEnemyRestScale(i);
        }
    }

    public void ResetPlayerVisualState()
    {
        if (playerAnchor == null) return;

        StopPlayerIdleMotion(false);
        playerAnchor.DOKill();
        playerAnchor.anchoredPosition = playerBasePosition;
        playerAnchor.localScale = playerBaseScale;
        playerAnchor.localRotation = Quaternion.identity;

        if (playerImage != null)
        {
            playerImage.DOKill();
            playerImage.color = Color.white;
        }

        SetPlayerSprite(LoadPlayerSprite());
        StartPlayerIdleMotion();
    }

    private Vector2 GetEnemyActorSize(BattleManager.EnemyKind enemyKind, int index)
    {
        if (enemyKind == BattleManager.EnemyKind.FallenScorpio) return new Vector2(330f, 385f);
        if (enemyKind == BattleManager.EnemyKind.StarAdversary) return new Vector2(360f, 415f);

        return index == 1 ? new Vector2(220f, 245f) : new Vector2(190f, 215f);
    }

    private float GetEnemyBaseScale(BattleManager.EnemyKind enemyKind)
    {
        if (enemyKind == BattleManager.EnemyKind.FallenScorpio) return 1.18f;
        if (enemyKind == BattleManager.EnemyKind.StarAdversary) return 1.24f;

        return 1f;
    }

    public void SetEnemyAlive(int index, bool isAlive)
    {
        RectTransform anchor = GetEnemyAnchor(index);
        Image image = GetEnemyImage(index);
        if (anchor == null || image == null) return;

        image.DOKill();
        if (isAlive)
        {
            image.color = new Color(1f, 1f, 1f, 1f);
            float baseScale = GetEnemyBaseScale(currentEnemyKind);
            anchor.localScale = new Vector3(baseScale, baseScale, 1f);
            return;
        }

        image.color = new Color(0.45f, 0.45f, 0.48f, 0.32f);
        float defeatedScale = GetEnemyBaseScale(currentEnemyKind) * 0.86f;
        anchor.localScale = new Vector3(defeatedScale, defeatedScale, 1f);
    }

    private void SetBattlefieldBackground(BattleManager.EnemyKind enemyKind)
    {
        // Resources/BattleBackgrounds 폴더에서 enum 이름과 같은 이미지를 찾습니다.
        // 예: EnemyKind.VoidHowler -> Resources/BattleBackgrounds/VoidHowler.png
        if (battlefieldBackground == null) return;

        Sprite backgroundSprite = LoadBackgroundSprite(enemyKind);
        if (backgroundSprite == null) return;

        battlefieldBackground.DOKill();
        battlefieldBackground.sprite = backgroundSprite;
        battlefieldBackground.color = new Color(1f, 1f, 1f, 0f);
        battlefieldBackground.DOFade(0.82f, 0.35f).SetEase(Ease.OutQuad);
    }

    private void SetEnemyImage(BattleManager.EnemyKind enemyKind)
    {
        SetEnemyImage(enemyImage, enemyKind);
    }

    private void SetEnemyImage(Image targetImage, BattleManager.EnemyKind enemyKind)
    {
        // Resources/BattleEnemies 폴더에서 enum 이름과 같은 적 이미지를 찾습니다.
        // 임시 이미지라도 파일명만 enum과 맞으면 자동으로 교체됩니다.
        if (targetImage == null) return;

        Sprite enemySprite = LoadEnemySprite(enemyKind);
        if (enemySprite == null) return;

        targetImage.DOKill();
        targetImage.sprite = enemySprite;
        targetImage.preserveAspect = true;
        targetImage.material = null;
        targetImage.color = new Color(1f, 1f, 1f, 0f);
        targetImage.DOFade(1f, 0.25f).SetEase(Ease.OutQuad);
    }

    private void ApplyEnemyShader(BattleManager.EnemyKind enemyKind)
    {
        ApplyEnemyShader(enemyImage, enemyKind);
    }

    private void ApplyEnemyShader(Image targetImage, BattleManager.EnemyKind enemyKind)
    {
        if (targetImage == null) return;

        if (!IsBossEnemy(enemyKind))
        {
            targetImage.material = null;
            return;
        }

        Material material = GetBossEnemyMaterial();
        if (material == null)
        {
            targetImage.material = null;
            return;
        }

        ConfigureBossShader(material, enemyKind);
        targetImage.material = material;
    }

    private bool IsBossEnemy(BattleManager.EnemyKind enemyKind)
    {
        return enemyKind == BattleManager.EnemyKind.FallenScorpio ||
               enemyKind == BattleManager.EnemyKind.StarAdversary;
    }

    private Material GetBossEnemyMaterial()
    {
        if (bossEnemyMaterial != null) return bossEnemyMaterial;

        Shader shader = Shader.Find("Custom/UI/BossStardustPulse");
        if (shader == null)
        {
            Debug.LogWarning("보스 쉐이더를 찾을 수 없습니다: Custom/UI/BossStardustPulse");
            return null;
        }

        bossEnemyMaterial = new Material(shader);
        bossEnemyMaterial.name = "Runtime Boss Stardust Material";
        return bossEnemyMaterial;
    }

    private void ConfigureBossShader(Material material, BattleManager.EnemyKind enemyKind)
    {
        if (enemyKind == BattleManager.EnemyKind.FallenScorpio)
        {
            material.SetColor("_GlowColor", new Color(1f, 0.25f, 0.75f, 1f));
            material.SetFloat("_PulseStrength", 0.72f);
            material.SetFloat("_PulseSpeed", 2.6f);
            material.SetFloat("_SweepStrength", 0.62f);
            material.SetFloat("_StarStrength", 0.55f);
            return;
        }

        material.SetColor("_GlowColor", new Color(0.25f, 0.86f, 1f, 1f));
        material.SetFloat("_PulseStrength", 0.95f);
        material.SetFloat("_PulseSpeed", 3.1f);
        material.SetFloat("_SweepStrength", 0.9f);
        material.SetFloat("_StarStrength", 0.82f);
    }

    private Sprite LoadBackgroundSprite(BattleManager.EnemyKind enemyKind)
    {
        if (backgroundSpriteCache.TryGetValue(enemyKind, out Sprite cachedSprite)) return cachedSprite;

        Texture2D texture = Resources.Load<Texture2D>($"BattleBackgrounds/{enemyKind}");
        if (texture == null)
        {
            Debug.LogWarning($"전투 배경을 찾을 수 없습니다: BattleBackgrounds/{enemyKind}");
            backgroundSpriteCache[enemyKind] = null;
            return null;
        }

        Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
        backgroundSpriteCache[enemyKind] = sprite;
        return sprite;
    }

    private Sprite LoadEnemySprite(BattleManager.EnemyKind enemyKind)
    {
        if (enemySpriteCache.TryGetValue(enemyKind, out Sprite cachedSprite)) return cachedSprite;

        Texture2D texture = Resources.Load<Texture2D>($"BattleEnemies/{enemyKind}");
        if (texture == null)
        {
            Debug.LogWarning($"에너미 이미지를 찾을 수 없습니다: BattleEnemies/{enemyKind}");
            enemySpriteCache[enemyKind] = null;
            return null;
        }

        Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
        enemySpriteCache[enemyKind] = sprite;
        return sprite;
    }

    private void SetPlayerImage()
    {
        if (playerImage == null) return;

        Sprite sprite = LoadPlayerSprite();
        if (sprite == null) return;

        playerImage.sprite = sprite;
        playerImage.preserveAspect = true;
        playerImage.raycastTarget = false;
        playerImage.color = Color.white;
        StartPlayerIdleMotion();
    }

    private Sprite LoadPlayerSprite()
    {
        if (playerSprite != null) return playerSprite;

        Sprite[] idleSprites = LoadPlayerIdleSprites();
        if (idleSprites.Length > 0)
        {
            playerSprite = idleSprites[0];
            return playerSprite;
        }

        Texture2D texture = Resources.Load<Texture2D>("Characters/PlayerHeroFemale");
        if (texture == null)
        {
            Debug.LogWarning("플레이어 이미지를 찾을 수 없습니다: Characters/PlayerHeroFemale");
            return null;
        }

        playerSprite = Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
        return playerSprite;
    }

    private Sprite[] LoadPlayerIdleSprites()
    {
        if (playerIdleSprites != null) return playerIdleSprites;

        playerIdleSprites = LoadPlayerFrameSprites("Characters/PlayerHeroIdle_", 2);
        return playerIdleSprites;
    }

    private Sprite[] LoadPlayerAttackSprites()
    {
        if (playerAttackSprites != null) return playerAttackSprites;

        playerAttackSprites = LoadPlayerFrameSprites("Characters/PlayerHeroAttack_", 5);
        return playerAttackSprites;
    }

    private Sprite[] LoadPlayerFrameSprites(string resourcePrefix, int frameCount)
    {
        List<Sprite> frames = new List<Sprite>();
        for (int i = 1; i <= frameCount; i++)
        {
            string resourcePath = resourcePrefix + i.ToString("00");
            Texture2D texture = Resources.Load<Texture2D>(resourcePath);
            if (texture == null) continue;

            frames.Add(Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f));
        }

        return frames.ToArray();
    }

    private void SetPlayerSprite(Sprite sprite)
    {
        if (playerImage == null || sprite == null) return;

        playerImage.sprite = sprite;
        playerImage.preserveAspect = true;
        playerImage.raycastTarget = false;
        playerImage.color = Color.white;
    }

    private Sprite GetFrameOrFallback(Sprite[] frames, int index)
    {
        if (frames != null && frames.Length > 0)
        {
            return frames[Mathf.Clamp(index, 0, frames.Length - 1)];
        }

        return LoadPlayerSprite();
    }

    private void StartPlayerIdleMotion()
    {
        if (playerAnchor == null || playerImage == null) return;

        StopPlayerIdleMotion(false);
        Sprite[] idleFrames = LoadPlayerIdleSprites();
        if (idleFrames.Length == 0) return;

        playerAnchor.anchoredPosition = playerBasePosition;
        playerAnchor.localScale = playerBaseScale;
        playerAnchor.localRotation = Quaternion.identity;
        SetPlayerSprite(idleFrames[0]);

        // 대기 모션은 프레임 2장과 작은 위아래 흔들림만 사용합니다.
        // 공격/피격 연출이 시작되면 StopPlayerIdleMotion으로 끊고, 끝난 뒤 다시 시작합니다.
        playerIdleSequence = DOTween.Sequence();
        playerIdleSequence.SetTarget(playerAnchor);
        playerIdleSequence.AppendCallback(() => SetPlayerSprite(idleFrames[0]));
        playerIdleSequence.Append(playerAnchor.DOAnchorPos(playerBasePosition + new Vector2(0f, 6f), 0.62f).SetEase(Ease.InOutSine));
        playerIdleSequence.AppendCallback(() => SetPlayerSprite(idleFrames[Mathf.Min(1, idleFrames.Length - 1)]));
        playerIdleSequence.Append(playerAnchor.DOAnchorPos(playerBasePosition, 0.62f).SetEase(Ease.InOutSine));
        playerIdleSequence.SetLoops(-1);
    }

    private void StopPlayerIdleMotion(bool resetToBase)
    {
        if (playerIdleSequence != null)
        {
            playerIdleSequence.Kill();
            playerIdleSequence = null;
        }

        if (!resetToBase || playerAnchor == null) return;

        playerAnchor.anchoredPosition = playerBasePosition;
        playerAnchor.localScale = playerBaseScale;
        playerAnchor.localRotation = Quaternion.identity;
    }

    public void PlayPlayerAttack()
    {
        PlayPlayerAttack(activeEnemyIndex);
    }

    public void PlayPlayerAttack(int enemyIndex)
    {
        // 플레이어가 공격할 때:
        // 루나리스 이미지가 앞으로 뛰어들고, 카드 잔상과 푸른 타격 이펙트를 날립니다.
        Color slashColor = new Color(0.4f, 0.9f, 1f, 0.9f);
        SetActiveEnemyIndex(enemyIndex);
        PlayHeroAttackMotion(GetEnemyAnchor(enemyIndex), slashColor);
    }

    public void PlayEnemyAttack()
    {
        PlayEnemyAttack(activeEnemyIndex);
    }

    public void PlayEnemyAttack(int enemyIndex)
    {
        // 일반 적은 앞으로 치고 들어오는 모션을 씁니다.
        // 보스는 몸집이 커서 앞으로 움직이면 화면을 덮고 크기가 변한 것처럼 보이므로,
        // 제자리에서 기운을 터뜨리는 별도 연출만 사용합니다.
        Color slashColor = new Color(1f, 0.28f, 0.35f, 0.9f);
        SetActiveEnemyIndex(enemyIndex);
        if (IsBossEnemy(currentEnemyKind))
        {
            PlayBossAttackMotion(GetEnemyAnchor(enemyIndex), playerAnchor, slashColor, 18f);
            return;
        }

        PlayAttackMotion(GetEnemyAnchor(enemyIndex), playerAnchor, new Vector2(-68f, 0f), slashColor, 18f);
    }

    private void PlayAttackMotion(RectTransform attacker, RectTransform target, Vector2 moveAmount, Color slashColor, float shakePower)
    {
        // 일반 적 공격 연출입니다.
        // attacker: 움직이는 쪽
        // target: 맞는 쪽
        // moveAmount: 공격자가 앞으로 나아갈 거리
        // 보스는 이 함수를 쓰지 않습니다. 보스가 이 이동/확대 연출을 쓰면 너무 크게 튀어나오기 때문입니다.
        if (attacker == null || target == null) return;

        attacker.DOKill();
        Vector2 originalPosition = attacker.anchoredPosition;

        Vector3 originalScale = GetActorRestScale(attacker);
        attacker.localScale = originalScale;

        Sequence sequence = DOTween.Sequence();
        sequence.Append(attacker.DOAnchorPos(originalPosition - moveAmount * 0.28f, 0.08f).SetEase(Ease.OutQuad));
        sequence.Join(attacker.DOScale(originalScale * 0.96f, 0.08f).SetEase(Ease.OutQuad));
        sequence.Append(attacker.DOAnchorPos(originalPosition + moveAmount * 1.15f, 0.1f).SetEase(Ease.InCubic));
        sequence.Join(attacker.DOScale(originalScale * 1.08f, 0.1f).SetEase(Ease.OutBack));
        sequence.AppendCallback(() =>
        {
            SpawnSlash(attacker.position, target.position, slashColor);
            SpawnImpactBurst(target.position, slashColor, false);
            PlayHitReaction(target, shakePower, false);
        });
        sequence.AppendInterval(0.035f);
        sequence.Append(attacker.DOAnchorPos(originalPosition, 0.18f).SetEase(Ease.OutBack));
        sequence.Join(attacker.DOScale(originalScale, 0.18f).SetEase(Ease.OutQuad));
    }

    private void PlayBossAttackMotion(RectTransform attacker, RectTransform target, Color slashColor, float shakePower)
    {
        // 보스 전용 공격 연출입니다.
        // 위치와 크기를 고정한 채 보스가 제자리에서 압박을 주고,
        // 실제 피격감은 플레이어 쪽 충격파와 흔들림으로 표현합니다.
        if (attacker == null || target == null) return;

        attacker.DOKill();
        attacker.localScale = GetActorRestScale(attacker);

        Sequence sequence = DOTween.Sequence();
        sequence.Append(attacker.DOShakeAnchorPos(0.18f, new Vector2(8f, 4f), 10, 70f));
        sequence.AppendCallback(() =>
        {
            SpawnSlash(attacker.position, target.position, slashColor);
            SpawnImpactBurst(target.position, slashColor, true);
            PlayHitReaction(target, shakePower, true);
        });
        sequence.AppendCallback(() => attacker.localScale = GetActorRestScale(attacker));
    }

    private void PlayHeroAttackMotion(RectTransform target, Color slashColor)
    {
        if (playerAnchor == null || target == null) return;

        StopPlayerIdleMotion(false);
        playerAnchor.DOKill();
        if (playerImage != null) playerImage.DOKill();
        target.DOKill();

        Sprite[] attackFrames = LoadPlayerAttackSprites();
        Vector2 originalPosition = playerBasePosition;
        Vector3 originalScale = playerBaseScale;
        playerAnchor.anchoredPosition = originalPosition;
        playerAnchor.localScale = originalScale;
        playerAnchor.localRotation = Quaternion.identity;
        SetPlayerSprite(GetFrameOrFallback(attackFrames, 0));

        Sequence sequence = DOTween.Sequence();
        sequence.AppendCallback(() => SetPlayerSprite(GetFrameOrFallback(attackFrames, 0)));
        sequence.Append(playerAnchor.DOAnchorPos(originalPosition + new Vector2(-32f, -4f), 0.07f).SetEase(Ease.OutQuad));
        sequence.Join(playerAnchor.DOScale(originalScale * 0.98f, 0.07f).SetEase(Ease.OutQuad));
        sequence.Join(playerAnchor.DORotate(new Vector3(0f, 0f, -5f), 0.07f).SetEase(Ease.OutQuad));
        sequence.AppendCallback(() => SetPlayerSprite(GetFrameOrFallback(attackFrames, 1)));
        sequence.Append(playerAnchor.DOAnchorPos(originalPosition + new Vector2(64f, 8f), 0.07f).SetEase(Ease.InQuad));
        sequence.Join(playerAnchor.DOScale(originalScale * 1.01f, 0.07f).SetEase(Ease.OutQuad));
        sequence.AppendCallback(() => SetPlayerSprite(GetFrameOrFallback(attackFrames, 2)));
        sequence.Append(playerAnchor.DOAnchorPos(originalPosition + new Vector2(148f, 18f), 0.08f).SetEase(Ease.InCubic));
        sequence.Join(playerAnchor.DOScale(originalScale * 1.03f, 0.08f).SetEase(Ease.OutQuad));
        sequence.Join(playerAnchor.DORotate(new Vector3(0f, 0f, 4f), 0.08f).SetEase(Ease.OutQuad));
        sequence.AppendCallback(() =>
        {
            SpawnHeroCardTrail(playerAnchor.position, target.position);
            SpawnSlash(playerAnchor.position, target.position, slashColor);
            SpawnSlash(playerAnchor.position + new Vector3(0f, 36f, 0f), target.position + new Vector3(0f, -20f, 0f), new Color(0.9f, 1f, 1f, 0.74f));
            SpawnImpactBurst(target.position, slashColor, true);
            PlayHitReaction(target, 24f, true);
        });
        sequence.AppendCallback(() => SetPlayerSprite(GetFrameOrFallback(attackFrames, 3)));
        sequence.Append(playerAnchor.DOAnchorPos(originalPosition + new Vector2(62f, 8f), 0.08f).SetEase(Ease.OutQuad));
        sequence.Join(playerAnchor.DOScale(originalScale, 0.08f).SetEase(Ease.OutQuad));
        sequence.AppendCallback(() => SetPlayerSprite(GetFrameOrFallback(attackFrames, 4)));
        sequence.Append(playerAnchor.DOAnchorPos(originalPosition, 0.18f).SetEase(Ease.OutBack));
        sequence.Join(playerAnchor.DORotate(Vector3.zero, 0.18f).SetEase(Ease.OutQuad));
        sequence.OnComplete(() =>
        {
            playerAnchor.anchoredPosition = originalPosition;
            playerAnchor.localScale = originalScale;
            playerAnchor.localRotation = Quaternion.identity;
            StartPlayerIdleMotion();
        });
    }

    public void PlayWeatheringTick()
    {
        PlayWeatheringTick(activeEnemyIndex);
    }

    public void PlayWeatheringTick(int enemyIndex)
    {
        RectTransform targetAnchor = GetEnemyAnchor(enemyIndex);
        if (targetAnchor == null) return;

        Vector3 center = targetAnchor.position;
        SpawnWindSlash(center + new Vector3(-90f, -38f, 0f), center + new Vector3(92f, 28f, 0f), 0.22f);
        SpawnWindSlash(center + new Vector3(-78f, 42f, 0f), center + new Vector3(86f, -18f, 0f), 0.28f);
        targetAnchor.DOShakeAnchorPos(0.22f, new Vector2(8f, 4f), 10, 70f);
    }

    public void PlayMeteorShower()
    {
        // 별무리 유성우 전용 연출입니다.
        // 실제 피해 4타는 BattleManager.UseStarClusterMeteorShower가 처리하고,
        // 이 함수는 유성 4개가 플레이어 주변에 떨어지는 화면 효과만 담당합니다.
        if (playerAnchor == null) return;

        StopPlayerIdleMotion(false);
        Vector3 target = playerAnchor.position;
        SpawnMeteor(target + new Vector3(-190f, 260f, 0f), target + new Vector3(-36f, 36f, 0f), 0.18f);
        SpawnMeteor(target + new Vector3(20f, 292f, 0f), target + new Vector3(24f, 48f, 0f), 0.28f);
        SpawnMeteor(target + new Vector3(180f, 250f, 0f), target + new Vector3(70f, 24f, 0f), 0.38f);
        SpawnMeteor(target + new Vector3(-80f, 330f, 0f), target + new Vector3(-4f, 18f, 0f), 0.48f);
        playerAnchor.DOShakeAnchorPos(0.86f, new Vector2(18f, 10f), 18, 90f).OnComplete(StartPlayerIdleMotion);
    }

    public void PlayPlayerDefeat()
    {
        if (playerAnchor == null) return;

        StopPlayerIdleMotion(false);
        playerAnchor.DOKill();
        if (playerImage != null) playerImage.DOKill();

        Vector2 originalPosition = playerBasePosition;
        Vector3 originalScale = playerBaseScale;
        playerAnchor.anchoredPosition = originalPosition;
        playerAnchor.localScale = originalScale;
        SpawnImpactBurst(playerAnchor.position, new Color(0.56f, 0.18f, 0.72f, 0.95f), true);

        Sequence sequence = DOTween.Sequence();
        sequence.Append(playerAnchor.DOShakeAnchorPos(0.34f, new Vector2(24f, 12f), 22, 90f));
        sequence.Append(playerAnchor.DOAnchorPos(originalPosition + new Vector2(-18f, -34f), 0.42f).SetEase(Ease.OutCubic));
        sequence.Join(playerAnchor.DORotate(new Vector3(0f, 0f, -11f), 0.42f).SetEase(Ease.OutQuad));
        sequence.Join(playerAnchor.DOScale(originalScale * 0.9f, 0.42f).SetEase(Ease.OutQuad));

        if (playerImage != null)
        {
            sequence.Join(playerImage.DOFade(0.45f, 0.42f).SetEase(Ease.OutQuad));
        }
    }

    public void ShowEnemyDamage(float damage)
    {
        ShowEnemyDamage(damage, activeEnemyIndex);
    }

    public void ShowEnemyDamage(float damage, int enemyIndex)
    {
        ShowDamageNumber(GetEnemyAnchor(enemyIndex), damage, new Color(1f, 0.28f, 0.22f, 1f));
    }

    public void ShowPlayerDamage(float damage)
    {
        ShowDamageNumber(playerAnchor, damage, new Color(1f, 0.86f, 0.2f, 1f));
    }

    public void ShowPlayerShield(float amount)
    {
        ShowStatusNumber(playerAnchor, amount, "+", new Color(0.72f, 0.74f, 0.78f, 1f));
    }

    public void ShowPlayerHeal(float amount)
    {
        ShowStatusNumber(playerAnchor, amount, "+", new Color(0.28f, 0.95f, 0.42f, 1f));
    }

    public void ShowEnergyGain(int amount)
    {
        ShowStatusNumber(playerAnchor, amount, "+", new Color(0.12f, 0.32f, 0.78f, 1f));
    }

    private void SpawnSlash(Vector3 from, Vector3 to, Color color)
    {
        // 실제 타격 이펙트 오브젝트를 만들고 DOTween으로 날려 보낸 뒤 삭제합니다.
        GameObject slash = GetEffectObject("HitSlash", "Hit Slash", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));

        RectTransform rect = slash.GetComponent<RectTransform>();
        rect.position = from;
        rect.sizeDelta = new Vector2(162f, 24f);
        rect.localScale = Vector3.one;

        Vector3 direction = to - from;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        rect.rotation = Quaternion.Euler(0f, 0f, angle);

        Image image = slash.GetComponent<Image>();
        image.color = color;

        Sequence sequence = DOTween.Sequence();
        sequence.Append(rect.DOMove(to, 0.18f).SetEase(Ease.OutCubic));
        sequence.Join(rect.DOScale(new Vector3(1.35f, 1.35f, 1f), 0.18f));
        sequence.Join(image.DOFade(0f, 0.18f));
        sequence.OnComplete(() => ReleaseEffectObject("HitSlash", slash));
    }

    private void SpawnHitImpact(Vector3 position, Color color)
    {
        GameObject impact = GetEffectObject("HitImpact", "Hit Impact", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));

        RectTransform rect = impact.GetComponent<RectTransform>();
        rect.position = position;
        rect.sizeDelta = new Vector2(48f, 48f);
        rect.localScale = Vector3.one * 0.45f;
        rect.rotation = Quaternion.identity;

        Image image = impact.GetComponent<Image>();
        image.sprite = CreateCircleSprite();
        image.color = new Color(color.r, color.g, color.b, 0.88f);
        image.raycastTarget = false;

        Sequence sequence = DOTween.Sequence();
        sequence.Append(rect.DOScale(new Vector3(3.2f, 3.2f, 1f), 0.18f).SetEase(Ease.OutCubic));
        sequence.Join(image.DOFade(0f, 0.18f));
        sequence.OnComplete(() => ReleaseEffectObject("HitImpact", impact));
    }

    private void SpawnImpactBurst(Vector3 position, Color color, bool heavy)
    {
        SpawnHitImpact(position, color);
        SpawnShockRing(position, color, heavy);
        SpawnImpactSparks(position, color, heavy ? 12 : 7);
    }

    private void PlayHitReaction(RectTransform target, float shakePower, bool heavy)
    {
        if (target == null) return;

        bool isPlayerTarget = target == playerAnchor;
        if (isPlayerTarget)
        {
            StopPlayerIdleMotion(false);
        }

        target.DOKill();
        Vector3 originalScale = GetActorRestScale(target);
        target.localScale = originalScale;
        bool lockScale = IsBossActor(target);
        float scalePunch = heavy ? 1.12f : 1.07f;
        Vector2 shake = heavy ? new Vector2(shakePower * 1.35f, shakePower * 0.72f) : new Vector2(shakePower * 1.08f, shakePower * 0.56f);

        Sequence sequence = DOTween.Sequence();
        if (lockScale)
        {
            // 보스는 맞을 때도 크기를 키우지 않습니다.
            // 대신 흔들림만 사용해서 "맞았다"는 반응을 보여줍니다.
            sequence.Append(target.DOShakeAnchorPos(heavy ? 0.28f : 0.2f, shake * 0.72f, heavy ? 18 : 12, 80f));
            sequence.AppendCallback(() => target.localScale = originalScale);
            return;
        }

        sequence.Append(target.DOScale(originalScale * scalePunch, 0.055f).SetEase(Ease.OutQuad));
        sequence.Join(target.DOShakeAnchorPos(heavy ? 0.34f : 0.24f, shake, heavy ? 22 : 16, 92f));
        sequence.Append(target.DOScale(originalScale, 0.16f).SetEase(Ease.OutBack));
        sequence.OnComplete(() =>
        {
            if (isPlayerTarget)
            {
                target.anchoredPosition = playerBasePosition;
                target.localScale = playerBaseScale;
                target.localRotation = Quaternion.identity;
                StartPlayerIdleMotion();
            }
        });
    }

    private Vector3 GetActorRestScale(RectTransform actor)
    {
        if (actor == null) return Vector3.one;
        if (actor == playerAnchor) return playerBaseScale;

        int enemyIndex = GetEnemyAnchorIndex(actor);
        if (enemyIndex >= 0)
        {
            return GetEnemyRestScale(enemyIndex);
        }

        return actor.localScale;
    }

    private Vector3 GetEnemyRestScale(int index)
    {
        // 전투 배우의 "정상 크기"를 계산합니다.
        // 일반 적은 선택된 대상만 살짝 크게 보이게 하고,
        // 보스는 선택/공격/피격과 무관하게 기본 크기를 유지합니다.
        Image slotImage = GetEnemyImage(index);
        bool isDefeatedSlot = slotImage != null && slotImage.color.a < 0.5f;
        float baseScale = GetEnemyBaseScale(currentEnemyKind);
        if (IsBossEnemy(currentEnemyKind) && !isDefeatedSlot)
        {
            return new Vector3(baseScale, baseScale, 1f);
        }

        float scale = isDefeatedSlot ? baseScale * 0.86f : baseScale * (index == activeEnemyIndex ? 1.08f : 0.94f);
        return new Vector3(scale, scale, 1f);
    }

    private bool IsBossActor(RectTransform actor)
    {
        return GetEnemyAnchorIndex(actor) >= 0 && IsBossEnemy(currentEnemyKind);
    }

    private int GetEnemyAnchorIndex(RectTransform actor)
    {
        if (enemyAnchors == null || actor == null) return -1;

        for (int i = 0; i < enemyAnchors.Length; i++)
        {
            if (enemyAnchors[i] == actor) return i;
        }

        return -1;
    }

    private void SpawnShockRing(Vector3 position, Color color, bool heavy)
    {
        GameObject ring = GetEffectObject("HitShockRing", "Hit Shock Ring", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));

        RectTransform rect = ring.GetComponent<RectTransform>();
        rect.position = position;
        rect.sizeDelta = new Vector2(64f, 64f);
        rect.localScale = Vector3.one * (heavy ? 0.34f : 0.28f);
        rect.rotation = Quaternion.identity;

        Image image = ring.GetComponent<Image>();
        image.sprite = CreateCircleSprite();
        image.color = new Color(color.r, color.g, color.b, heavy ? 0.42f : 0.32f);
        image.raycastTarget = false;

        float scale = heavy ? 5.6f : 4.4f;
        float duration = heavy ? 0.28f : 0.22f;
        Sequence sequence = DOTween.Sequence();
        sequence.Append(rect.DOScale(new Vector3(scale, scale, 1f), duration).SetEase(Ease.OutCubic));
        sequence.Join(image.DOFade(0f, duration));
        sequence.OnComplete(() => ReleaseEffectObject("HitShockRing", ring));
    }

    private void SpawnImpactSparks(Vector3 position, Color color, int count)
    {
        for (int i = 0; i < count; i++)
        {
            GameObject spark = GetEffectObject("HitSpark", "Hit Spark", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));

            RectTransform rect = spark.GetComponent<RectTransform>();
            rect.position = position;
            rect.sizeDelta = new Vector2(Random.Range(12f, 24f), Random.Range(4f, 8f));
            rect.localScale = Vector3.one;

            float angle = Random.Range(0f, 360f);
            Vector3 direction = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad), 0f);
            rect.rotation = Quaternion.Euler(0f, 0f, angle);

            Image image = spark.GetComponent<Image>();
            image.sprite = CreateCircleSprite();
            image.color = new Color(color.r, color.g, color.b, Random.Range(0.72f, 0.98f));
            image.raycastTarget = false;

            float distance = Random.Range(48f, 120f);
            float duration = Random.Range(0.18f, 0.34f);
            Sequence sequence = DOTween.Sequence();
            sequence.Append(rect.DOMove(position + direction * distance, duration).SetEase(Ease.OutCubic));
            sequence.Join(rect.DOScale(new Vector3(0.15f, 0.15f, 1f), duration));
            sequence.Join(image.DOFade(0f, duration));
            sequence.OnComplete(() => ReleaseEffectObject("HitSpark", spark));
        }
    }

    private void SpawnHeroCardTrail(Vector3 from, Vector3 to)
    {
        for (int i = 0; i < 3; i++)
        {
            GameObject card = GetEffectObject("HeroAttackCard", "Hero Attack Card", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));

            RectTransform rect = card.GetComponent<RectTransform>();
            rect.position = from + new Vector3(-12f, 34f - i * 28f, 0f);
            rect.sizeDelta = new Vector2(44f, 62f);
            rect.localScale = Vector3.one;
            rect.rotation = Quaternion.Euler(0f, 0f, -18f + i * 14f);

            Image image = card.GetComponent<Image>();
            image.sprite = CreateHeroCardSprite();
            image.color = new Color(0.72f, 0.92f, 1f, 0.92f);
            image.raycastTarget = false;

            Vector3 target = Vector3.Lerp(from, to, 0.84f) + new Vector3(0f, 24f - i * 20f, 0f);
            Sequence sequence = DOTween.Sequence();
            sequence.AppendInterval(i * 0.035f);
            sequence.Append(rect.DOMove(target, 0.18f).SetEase(Ease.OutCubic));
            sequence.Join(rect.DORotate(new Vector3(0f, 0f, 34f + i * 28f), 0.18f, RotateMode.FastBeyond360));
            sequence.Join(rect.DOScale(new Vector3(1.18f, 1.18f, 1f), 0.18f));
            sequence.Join(image.DOFade(0f, 0.18f));
            sequence.OnComplete(() => ReleaseEffectObject("HeroAttackCard", card));
        }
    }

    private Sprite CreateHeroCardSprite()
    {
        if (heroCardSprite != null) return heroCardSprite;

        int width = 44;
        int height = 64;
        Texture2D texture = new Texture2D(width, height);
        Vector2 center = new Vector2((width - 1) * 0.5f, (height - 1) * 0.5f);

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                bool border = x < 3 || x >= width - 3 || y < 3 || y >= height - 3;
                float vertical = y / (float)(height - 1);
                Color fill = Color.Lerp(new Color(0.08f, 0.12f, 0.32f, 0.92f), new Color(0.52f, 0.74f, 1f, 0.96f), vertical);
                Color color = border ? new Color(0.95f, 0.82f, 0.34f, 1f) : fill;

                float starDistance = Vector2.Distance(new Vector2(x, y), center);
                if (starDistance < 5f || (Mathf.Abs(x - center.x) < 2f && Mathf.Abs(y - center.y) < 11f) || (Mathf.Abs(y - center.y) < 2f && Mathf.Abs(x - center.x) < 11f))
                {
                    color = new Color(1f, 0.96f, 0.72f, 1f);
                }

                texture.SetPixel(x, y, color);
            }
        }

        texture.Apply();
        heroCardSprite = Sprite.Create(texture, new Rect(0f, 0f, width, height), new Vector2(0.5f, 0.5f));
        return heroCardSprite;
    }

    private void SpawnWindSlash(Vector3 from, Vector3 to, float duration)
    {
        GameObject wind = GetEffectObject("WeatheringWind", "Weathering Wind", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));

        RectTransform rect = wind.GetComponent<RectTransform>();
        rect.position = from;
        rect.sizeDelta = new Vector2(160f, 10f);
        rect.localScale = Vector3.one;

        Vector3 direction = to - from;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        rect.rotation = Quaternion.Euler(0f, 0f, angle);

        Image image = wind.GetComponent<Image>();
        image.color = new Color(0.6f, 1f, 0.95f, 0.74f);

        Sequence sequence = DOTween.Sequence();
        sequence.Append(rect.DOMove(to, duration).SetEase(Ease.OutCubic));
        sequence.Join(rect.DOScale(new Vector3(1.25f, 1.25f, 1f), duration));
        sequence.Join(image.DOFade(0f, duration));
        sequence.OnComplete(() => ReleaseEffectObject("WeatheringWind", wind));
    }

    private void SpawnMeteor(Vector3 from, Vector3 to, float delay)
    {
        // 유성 하나를 생성해 from 위치에서 to 위치로 떨어뜨립니다.
        // delay를 다르게 주면 4개의 유성이 동시에 떨어지지 않고 순차적으로 떨어져 보입니다.
        GameObject meteor = GetEffectObject("StarClusterMeteor", "Star Cluster Meteor", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));

        RectTransform rect = meteor.GetComponent<RectTransform>();
        rect.position = from;
        rect.sizeDelta = new Vector2(34f, 86f);
        rect.localScale = Vector3.one;

        Vector3 direction = to - from;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg + 90f;
        rect.rotation = Quaternion.Euler(0f, 0f, angle);

        Image image = meteor.GetComponent<Image>();
        image.sprite = CreateMeteorSprite();
        image.color = new Color(0.92f, 0.96f, 1f, 0f);
        image.raycastTarget = false;

        Sequence sequence = DOTween.Sequence();
        sequence.AppendInterval(delay);
        sequence.AppendCallback(() => image.color = new Color(0.92f, 0.96f, 1f, 0.95f));
        sequence.Append(rect.DOMove(to, 0.28f).SetEase(Ease.InCubic));
        sequence.Join(rect.DOScale(new Vector3(1.34f, 1.34f, 1f), 0.28f));
        sequence.AppendCallback(() => SpawnMeteorImpact(to));
        sequence.Join(image.DOFade(0f, 0.12f));
        sequence.OnComplete(() => ReleaseEffectObject("StarClusterMeteor", meteor));
    }

    private void SpawnMeteorImpact(Vector3 position)
    {
        GameObject impact = GetEffectObject("MeteorImpact", "Meteor Impact", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));

        RectTransform rect = impact.GetComponent<RectTransform>();
        rect.position = position;
        rect.sizeDelta = new Vector2(28f, 28f);
        rect.localScale = Vector3.one;

        Image image = impact.GetComponent<Image>();
        image.sprite = CreateCircleSprite();
        image.color = new Color(0.58f, 0.82f, 1f, 0.82f);
        image.raycastTarget = false;

        Sequence sequence = DOTween.Sequence();
        sequence.Append(rect.DOScale(new Vector3(4.2f, 4.2f, 1f), 0.22f).SetEase(Ease.OutCubic));
        sequence.Join(image.DOFade(0f, 0.22f));
        sequence.OnComplete(() => ReleaseEffectObject("MeteorImpact", impact));
    }

    private void ShowDamageNumber(RectTransform target, float damage, Color color)
    {
        // 피해 숫자는 대상 앵커 근처에서 위로 떠오르며 사라집니다.
        // damage 값은 BattleManager에서 이미 최종 계산된 실제 피해입니다.
        if (target == null) return;

        GameObject numberObject = GetEffectObject("DamageNumber", "Damage Number", typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));

        RectTransform rect = numberObject.GetComponent<RectTransform>();
        rect.position = target.position + new Vector3(Random.Range(-34f, 34f), 76f, 0f);
        rect.sizeDelta = new Vector2(190f, 70f);
        rect.localScale = Vector3.one;

        Text text = numberObject.GetComponent<Text>();
        text.text = damage > 0f ? $"-{damage:F0}" : "막음";
        text.font = GetBuiltinFont();
        text.fontSize = damage > 0f ? 52 : 34;
        text.fontStyle = FontStyle.Bold;
        text.alignment = TextAnchor.MiddleCenter;
        ReadableTextStyle.Apply(text);
        text.color = color;
        text.raycastTarget = false;

        Sequence sequence = DOTween.Sequence();
        rect.localScale = Vector3.one * 0.68f;
        sequence.Append(rect.DOScale(new Vector3(1.38f, 1.38f, 1f), 0.1f).SetEase(Ease.OutBack));
        sequence.Join(rect.DOMoveY(rect.position.y + 34f, 0.1f).SetEase(Ease.OutCubic));
        sequence.Append(rect.DOScale(Vector3.one, 0.12f).SetEase(Ease.OutQuad));
        sequence.Append(rect.DOMoveY(rect.position.y + 88f, 0.42f).SetEase(Ease.OutCubic));
        sequence.Join(text.DOFade(0f, 0.28f).SetDelay(0.12f));
        sequence.OnComplete(() => ReleaseEffectObject("DamageNumber", numberObject));
    }

    private void ShowStatusNumber(RectTransform target, float amount, string prefix, Color color)
    {
        if (target == null || amount <= 0f) return;

        GameObject numberObject = GetEffectObject("StatusNumber", "Status Number", typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));

        RectTransform rect = numberObject.GetComponent<RectTransform>();
        rect.position = target.position + new Vector3(Random.Range(-42f, 42f), 112f, 0f);
        rect.sizeDelta = new Vector2(210f, 70f);
        rect.localScale = Vector3.one;

        Text text = numberObject.GetComponent<Text>();
        text.text = $"{prefix}{amount:F0}";
        text.font = GetBuiltinFont();
        text.fontSize = 38;
        text.fontStyle = FontStyle.Bold;
        text.alignment = TextAnchor.MiddleCenter;
        text.color = color;
        text.raycastTarget = false;

        Sequence sequence = DOTween.Sequence();
        sequence.Append(rect.DOMoveY(rect.position.y + 62f, 0.56f).SetEase(Ease.OutCubic));
        sequence.Join(rect.DOScale(new Vector3(1.12f, 1.12f, 1f), 0.14f).SetEase(Ease.OutBack));
        sequence.Append(rect.DOScale(Vector3.one, 0.14f).SetEase(Ease.OutQuad));
        sequence.Join(text.DOFade(0f, 0.24f).SetDelay(0.18f));
        sequence.OnComplete(() => ReleaseEffectObject("StatusNumber", numberObject));
    }

    private GameObject GetEffectObject(string poolKey, string objectName, params System.Type[] components)
    {
        Transform parent = effectParent != null ? effectParent : transform;

        if (!effectPools.TryGetValue(poolKey, out Queue<GameObject> pool))
        {
            pool = new Queue<GameObject>();
            effectPools[poolKey] = pool;
        }

        while (pool.Count > 0)
        {
            GameObject pooled = pool.Dequeue();
            if (pooled == null) continue;

            pooled.transform.SetParent(parent, false);
            KillEffectTweens(pooled);
            pooled.SetActive(true);
            return pooled;
        }

        GameObject created = new GameObject(objectName, components);
        created.transform.SetParent(parent, false);
        return created;
    }

    private void ReleaseEffectObject(string poolKey, GameObject effectObject)
    {
        if (effectObject == null) return;

        KillEffectTweens(effectObject);
        effectObject.SetActive(false);

        if (!effectPools.TryGetValue(poolKey, out Queue<GameObject> pool))
        {
            pool = new Queue<GameObject>();
            effectPools[poolKey] = pool;
        }

        pool.Enqueue(effectObject);
    }

    private void KillEffectTweens(GameObject effectObject)
    {
        if (effectObject == null) return;

        effectObject.transform.DOKill();
        Graphic[] graphics = effectObject.GetComponentsInChildren<Graphic>(true);
        for (int i = 0; i < graphics.Length; i++)
        {
            if (graphics[i] != null)
            {
                graphics[i].DOKill();
            }
        }
    }

    private Sprite CreateMeteorSprite()
    {
        if (meteorSprite != null) return meteorSprite;

        // 별무리 유성우에 사용할 간단한 런타임 스프라이트를 코드로 만듭니다.
        // 별도의 PNG 파일 없이 Texture2D 픽셀을 직접 채워 꼬리 달린 유성 모양을 만듭니다.
        int width = 32;
        int height = 96;
        Texture2D texture = new Texture2D(width, height);
        Vector2 headCenter = new Vector2((width - 1) * 0.5f, height * 0.18f);

        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                float vertical = y / (float)(height - 1);
                float horizontal = Mathf.Abs(x - headCenter.x) / headCenter.x;
                float core = Mathf.Clamp01(1f - horizontal * 1.7f);
                float tail = Mathf.Clamp01(1f - vertical);
                float head = Mathf.Clamp01(1f - Vector2.Distance(new Vector2(x, y), headCenter) / 13f);
                float alpha = Mathf.Max(head, core * tail * 0.72f);
                Color color = Color.Lerp(new Color(0.18f, 0.42f, 1f, alpha), new Color(1f, 1f, 1f, alpha), head);
                texture.SetPixel(x, y, alpha > 0.03f ? color : Color.clear);
            }
        }

        texture.Apply();
        meteorSprite = Sprite.Create(texture, new Rect(0f, 0f, width, height), new Vector2(0.5f, 0.5f));
        return meteorSprite;
    }

    private Sprite CreateCircleSprite()
    {
        if (circleSprite != null) return circleSprite;

        int size = 64;
        Texture2D texture = new Texture2D(size, size);
        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        float radius = size * 0.48f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float distance = Vector2.Distance(new Vector2(x, y), center);
                float alpha = Mathf.Clamp01(1f - distance / radius);
                texture.SetPixel(x, y, alpha > 0f ? new Color(1f, 1f, 1f, alpha) : Color.clear);
            }
        }

        texture.Apply();
        circleSprite = Sprite.Create(texture, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f));
        return circleSprite;
    }

    private RectTransform GetEnemyAnchor(int index)
    {
        if (enemyAnchors != null && index >= 0 && index < enemyAnchors.Length && enemyAnchors[index] != null)
        {
            return enemyAnchors[index];
        }

        return enemyAnchor;
    }

    private Image GetEnemyImage(int index)
    {
        if (enemyImages != null && index >= 0 && index < enemyImages.Length && enemyImages[index] != null)
        {
            return enemyImages[index];
        }

        return enemyImage;
    }

    private Text GetEnemyNameText(int index)
    {
        if (enemyNameTexts != null && index >= 0 && index < enemyNameTexts.Length && enemyNameTexts[index] != null)
        {
            return enemyNameTexts[index];
        }

        return enemyNameText;
    }

    private Font GetBuiltinFont()
    {
        return ReadableTextStyle.GetReadableFont();
    }
}
