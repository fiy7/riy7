Shader "Custom/UI/BossStardustPulse"
{
    Properties
    {
        [PerRendererData] _MainTex ("Sprite Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)
        _GlowColor ("Glow Color", Color) = (0.35,0.85,1,1)
        _PulseStrength ("Pulse Strength", Range(0, 2)) = 0.65
        _PulseSpeed ("Pulse Speed", Range(0, 10)) = 2.2
        _SweepStrength ("Sweep Strength", Range(0, 2)) = 0.8
        _SweepSpeed ("Sweep Speed", Range(0, 10)) = 1.4
        _StarStrength ("Star Strength", Range(0, 2)) = 0.75

        [HideInInspector] _StencilComp ("Stencil Comparison", Float) = 8
        [HideInInspector] _Stencil ("Stencil ID", Float) = 0
        [HideInInspector] _StencilOp ("Stencil Operation", Float) = 0
        [HideInInspector] _StencilWriteMask ("Stencil Write Mask", Float) = 255
        [HideInInspector] _StencilReadMask ("Stencil Read Mask", Float) = 255
        [HideInInspector] _ColorMask ("Color Mask", Float) = 15
        [HideInInspector] [Toggle(UNITY_UI_ALPHACLIP)] _UseUIAlphaClip ("Use Alpha Clip", Float) = 0
    }

    SubShader
    {
        Tags
        {
            "Queue"="Transparent"
            "IgnoreProjector"="True"
            "RenderType"="Transparent"
            "PreviewType"="Plane"
            "CanUseSpriteAtlas"="True"
        }

        Stencil
        {
            Ref [_Stencil]
            Comp [_StencilComp]
            Pass [_StencilOp]
            ReadMask [_StencilReadMask]
            WriteMask [_StencilWriteMask]
        }

        Cull Off
        Lighting Off
        ZWrite Off
        ZTest [unity_GUIZTestMode]
        Blend SrcAlpha OneMinusSrcAlpha
        ColorMask [_ColorMask]

        Pass
        {
            Name "Default"

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 2.0

            #include "UnityCG.cginc"
            #include "UnityUI.cginc"

            #pragma multi_compile_local _ UNITY_UI_CLIP_RECT
            #pragma multi_compile_local _ UNITY_UI_ALPHACLIP

            struct appdata_t
            {
                float4 vertex : POSITION;
                fixed4 color : COLOR;
                float2 texcoord : TEXCOORD0;
            };

            struct v2f
            {
                float4 vertex : SV_POSITION;
                fixed4 color : COLOR;
                float2 uv : TEXCOORD0;
                float4 worldPosition : TEXCOORD1;
            };

            sampler2D _MainTex;
            fixed4 _Color;
            fixed4 _TextureSampleAdd;
            float4 _MainTex_ST;
            float4 _ClipRect;

            fixed4 _GlowColor;
            float _PulseStrength;
            float _PulseSpeed;
            float _SweepStrength;
            float _SweepSpeed;
            float _StarStrength;

            v2f vert(appdata_t v)
            {
                v2f o;
                o.worldPosition = v.vertex;
                o.vertex = UnityObjectToClipPos(v.vertex);
                o.uv = TRANSFORM_TEX(v.texcoord, _MainTex);
                o.color = v.color * _Color;
                return o;
            }

            fixed4 frag(v2f i) : SV_Target
            {
                fixed4 color = (tex2D(_MainTex, i.uv) + _TextureSampleAdd) * i.color;
                float alpha = color.a;

                float time = _Time.y;
                float pulse = 0.5 + 0.5 * sin(time * _PulseSpeed);
                float sweepLine = frac(i.uv.x + i.uv.y + time * _SweepSpeed);
                float sweep = smoothstep(0.90, 1.0, sweepLine) * _SweepStrength;

                float starA = sin((i.uv.x * 58.0 + i.uv.y * 31.0 + time * 2.1) * 6.28318);
                float starB = sin((i.uv.x * 19.0 - i.uv.y * 47.0 - time * 1.7) * 6.28318);
                float stars = smoothstep(0.92, 1.0, starA * starB) * _StarStrength;

                float edge = 1.0 - min(min(i.uv.x, 1.0 - i.uv.x), min(i.uv.y, 1.0 - i.uv.y)) * 2.0;
                float edgeGlow = smoothstep(0.35, 1.0, edge) * 0.45;

                float glow = pulse * _PulseStrength + sweep + stars + edgeGlow;
                color.rgb += _GlowColor.rgb * glow * alpha;
                color.rgb = lerp(color.rgb, color.rgb * _GlowColor.rgb * 1.35, sweep * alpha);
                color.a = alpha;

                #ifdef UNITY_UI_CLIP_RECT
                color.a *= UnityGet2DClipping(i.worldPosition.xy, _ClipRect);
                #endif

                #ifdef UNITY_UI_ALPHACLIP
                clip(color.a - 0.001);
                #endif

                return color;
            }
            ENDCG
        }
    }
}
